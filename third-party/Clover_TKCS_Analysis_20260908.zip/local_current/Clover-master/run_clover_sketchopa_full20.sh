#!/usr/bin/env bash
set -euo pipefail

COMMON_ARGS=(
  --partition_method IID
  --method FedAvg
  --batch_size 50
  --lr 0.1
  --epochs 30
  --client_num_in_total 100
  --frac 0.1
  --comm_round 20
  --C 1000000000
  --sigma 0
  --alpha 0.01
)

for DATASET in mnist fmnist; do
  for MODE in dense topk_plain topk_residual sketchopa_plain_cs sketchopa_secure sketchopa_secure_residual; do
    extra_alpha=(--alpha 0.01)
    if [[ "$MODE" == "dense" ]]; then
      extra_alpha=(--alpha 0)
    fi
    python Clover-main.py \
      "${COMMON_ARGS[@]}" \
      --dataset "${DATASET}" \
      --model lenet5 \
      --aggregation_mode "${MODE}" \
      "${extra_alpha[@]}" \
      --sketch_rows 5 \
      --sketch_bucket_factor 8 \
      --sketch_min_buckets 128 \
      --sketch_recover_k_mode active_union \
      --sketch_bucket_budget_mode active_union \
      --sketch_recovery_score plain_median \
      --committee_size 7 \
      --committee_threshold 5 \
      --shprg_backend opa_lwr_shprg
  done
done

for MODE in dense topk_plain topk_residual sketchopa_plain_cs sketchopa_secure sketchopa_secure_residual; do
  extra_alpha=(--alpha 0.01)
  if [[ "$MODE" == "dense" ]]; then
    extra_alpha=(--alpha 0)
  fi
  python Clover-main.py \
    "${COMMON_ARGS[@]}" \
    --dataset cifar10 \
    --model resnet18 \
    --aggregation_mode "${MODE}" \
    "${extra_alpha[@]}" \
    --sketch_rows 7 \
    --sketch_bucket_factor 16 \
    --sketch_min_buckets 256 \
    --sketch_recover_k_mode active_union \
    --sketch_bucket_budget_mode active_union \
    --sketch_recovery_score plain_median \
    --committee_size 7 \
    --committee_threshold 5 \
    --shprg_backend opa_lwr_shprg
done

