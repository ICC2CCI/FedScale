#!/usr/bin/env bash
set -euo pipefail

for ROWS in 3 5 7; do
  for BF in 4 8 16; do
    python Clover-main.py \
      --dataset fmnist \
      --model lenet5 \
      --partition_method IID \
      --method FedAvg \
      --batch_size 50 \
      --lr 0.1 \
      --epochs 30 \
      --client_num_in_total 100 \
      --frac 0.1 \
      --aggregation_mode sketchopa_plain_cs \
      --comm_round 20 \
      --C 1000000000 \
      --sigma 0 \
      --alpha 0.01 \
      --sketch_rows "${ROWS}" \
      --sketch_bucket_factor "${BF}" \
      --sketch_min_buckets 128 \
      --sketch_recover_k_mode active_union \
      --sketch_bucket_budget_mode active_union \
      --sketch_recovery_score plain_median
  done
done

