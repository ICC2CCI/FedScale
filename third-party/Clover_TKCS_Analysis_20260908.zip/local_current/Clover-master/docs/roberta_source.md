# RoBERTa-Large Phase 1 Source Record

## Upstream

- Repository: `https://github.com/alibaba/FederatedScope`
- Branch: `llm`
- Commit: `7f086944c57f85c7594bde44d4f6b981f0de6845`
- License: Apache License 2.0 (`LICENSE` in the pinned upstream tree)
- Local pinned checkout: supplied to the runner through `--federatedscope-root`

The runner checks `git rev-parse HEAD` and stops unless it matches the commit above.

## Native Capabilities Reused

FederatedScope-LLM natively provides:

- a standalone federated-learning framework and client trainer lifecycle;
- Hugging Face causal-language-model loading;
- PEFT/LoRA adapter construction;
- `AdapterModel`, whose default `state_dict()` returns only parameters with
  `requires_grad=True`;
- `LLMTrainer`, including AdamW construction, local epoch/batch execution,
  forward/backward/optimizer steps, gradient handling, and train-loss reporting;
- IID data splitting and shared-local-model execution patterns.

The pinned branch's built-in datasets are instruction/code/math datasets such
as Alpaca, Dolly, GSM8K, and CodeSearchNet. It does not natively provide GLUE
CoLA/MRPC sequence classification. Its model builder and PEFT helper also fix
the task type to causal language modeling.

## Minimal Phase 1 Adaptation

`experiments/phase1/roberta_worker.py` makes only the task-specific additions:

1. load `FacebookAI/roberta-large` with
   `AutoModelForSequenceClassification(num_labels=2)`;
2. attach PEFT LoRA with `TaskType.SEQ_CLS`, rank 8, alpha 32, and the
   attention `query`/`value` projections;
3. tokenize GLUE CoLA/MRPC at sequence length 128;
4. create one immutable IID-like partition with about 30 training examples per
   virtual client;
5. invoke the pinned FederatedScope `LLMTrainer` for each selected client;
6. pass the exact `AdapterModel.state_dict(return_trainable=True)` update to
   the shared Phase 1 Dense/Top-k/TKCS codec;
7. evaluate CoLA with MCC and accuracy, and MRPC with F1 and accuracy;
8. save fixed-schema diagnostics and resumable trainable-state checkpoints.

The adaptation does not copy the unlicensed `CERT-Lab/fedex-lora` code and does
not implement a second general-purpose federated trainer.

## Resolved Differences

The requested fixed settings are LoRA rank 8, alpha 32, AdamW at `1e-5`, 500
federated rounds, 20 clients per round, and about 30 samples per client. The
thin adapter uses one local epoch and batch size 8 because the selected
FederatedScope source does not publish a native GLUE recipe. These values are
recorded in every run's `resolved_config.yaml`; they must not be silently
changed between Dense, Top-k, and TKCS.

Language tasks use only the immutable native IID-like split. No artificial
Dirichlet split, secure aggregation, differential privacy, or cryptographic
protocol is enabled in Phase 1.
