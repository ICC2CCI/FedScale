#!/usr/bin/env bash
set -euo pipefail

DATASET="${DATASET:-fmnist}"
MODEL="${MODEL:-lenet5}"
ROUNDS="${ROUNDS:-20}"
RESULTS_DIR="${RESULTS_DIR:-results_sketchopa_lowcomm_sweep}"

COMMON_ARGS=(
  --dataset "${DATASET}"
  --model "${MODEL}"
  --partition_method IID
  --method FedAvg
  --batch_size 50
  --lr 0.1
  --epochs 30
  --client_num_in_total 100
  --frac 0.1
  --comm_round "${ROUNDS}"
  --C 1000000000
  --sigma 0
  --alpha 0.01
  --aggregation_mode sketchopa_plain_cs
  --sketch_recover_k_mode active_union
  --sketch_recovery_score plain_median
  --results_dir "${RESULTS_DIR}"
)

run_profile() {
  local profile="$1"
  shift
  echo "RUN ${DATASET} ${MODEL} ${profile}"
  python Clover-main.py "${COMMON_ARGS[@]}" --tag "${profile}" "$@"
}

run_profile below_dense_float32 \
  --sketch_rows 3 \
  --sketch_bucket_factor 1 \
  --sketch_min_buckets 16 \
  --sketch_bucket_budget_mode active_union \
  --sketch_transport_dtype float32 \
  --sketch_value_bytes 4

run_profile below_dense_float16 \
  --sketch_rows 3 \
  --sketch_bucket_factor 1 \
  --sketch_min_buckets 16 \
  --sketch_bucket_budget_mode active_union \
  --sketch_transport_dtype float16 \
  --sketch_value_bytes 2

run_profile near_topk_float16 \
  --sketch_rows 3 \
  --sketch_bucket_factor 1 \
  --sketch_min_buckets 8 \
  --sketch_bucket_budget_mode single_client \
  --sketch_transport_dtype float16 \
  --sketch_value_bytes 2

run_profile ultra_low_float16 \
  --sketch_rows 2 \
  --sketch_bucket_factor 1 \
  --sketch_min_buckets 8 \
  --sketch_bucket_budget_mode single_client \
  --sketch_transport_dtype float16 \
  --sketch_value_bytes 2

python scripts/collect_clover_sketchopa_results.py
