#!/usr/bin/env bash
set -euo pipefail

COMMON_ARGS=(
  --partition_method IID
  --method FedAvg
  --batch_size 50
  --lr 0.1
  --epochs 30
  --client_num_in_total 100
  --frac 0.1
  --comm_round 20
  --C 1000000000
  --sigma 0
  --alpha 0.01
  --aggregation_mode sketchopa_plain_cs
  --sketch_recover_k_mode active_union
  --sketch_recovery_score plain_median
  --results_dir results_sketchopa_clover_lowcomm20
)

run_case() {
  local dataset="$1"
  local model="$2"
  local profile="$3"
  shift 3
  echo "RUN ${dataset} ${model} ${profile}"
  python Clover-main.py \
    "${COMMON_ARGS[@]}" \
    --dataset "${dataset}" \
    --model "${model}" \
    --tag "${profile}" \
    "$@"
}

# Conservative low-communication profile:
# rows=3, bucket_factor=1, active-union buckets, float32 wire values.
# This should stay below Dense FL communication while preserving most of the
# high-quality active-union recovery behavior.
for DATASET in mnist fmnist; do
  run_case "${DATASET}" lenet5 below_dense_float32 \
    --sketch_rows 3 \
    --sketch_bucket_factor 1 \
    --sketch_min_buckets 16 \
    --sketch_bucket_budget_mode active_union \
    --sketch_transport_dtype float32 \
    --sketch_value_bytes 4
done

run_case cifar10 resnet18 below_dense_float32 \
  --sketch_rows 3 \
  --sketch_bucket_factor 1 \
  --sketch_min_buckets 16 \
  --sketch_bucket_budget_mode active_union \
  --sketch_transport_dtype float32 \
  --sketch_value_bytes 4

# Aggressive near-Top-k communication profile:
# single-client bucket budget plus float16 wire values. This can be close to
# or below Top-k communication, but accuracy must be checked before use.
for DATASET in mnist fmnist; do
  run_case "${DATASET}" lenet5 near_topk_float16 \
    --sketch_rows 3 \
    --sketch_bucket_factor 1 \
    --sketch_min_buckets 8 \
    --sketch_bucket_budget_mode single_client \
    --sketch_transport_dtype float16 \
    --sketch_value_bytes 2
done

run_case cifar10 resnet18 near_topk_float16 \
  --sketch_rows 3 \
  --sketch_bucket_factor 1 \
  --sketch_min_buckets 8 \
  --sketch_bucket_budget_mode single_client \
  --sketch_transport_dtype float16 \
  --sketch_value_bytes 2

python scripts/collect_clover_sketchopa_results.py
