import copy
from pathlib import Path
import sys

import torch
from torch import nn

sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from Clover_api.privacy.protected_support import classifier_groups, protected_topk, ServerAdam


def test_head_support_is_data_independent_and_budget_is_fixed():
    model = nn.Sequential(nn.Linear(4,8),nn.ReLU(),nn.Linear(8,2))
    raw = {k:torch.arange(1,v.numel()+1,dtype=torch.float32).reshape(v.shape) for k,v in model.state_dict().items()}
    groups = classifier_groups(model,raw)
    flipped = {k:v.flip(0)*(-7.) for k,v in raw.items()}
    a,ix_a,_,metrics = protected_topk(raw,groups,12,head_fraction=.5,round_idx=3)
    b,ix_b,_,_ = protected_topk(flipped,groups,12,head_fraction=.5,round_idx=3)
    head = torch.tensor([i for group in groups for i in group])
    assert torch.equal(ix_a[torch.isin(ix_a,head)],ix_b[torch.isin(ix_b,head)])
    assert len(ix_a) == len(ix_b) == 12 and metrics["head_selected"] == 6
    assert all(torch.equal(raw[k],a[k]+(raw[k]-a[k])) for k in raw)
    assert metrics["transmitted_nonzero_fraction"] == 1.


def test_private_support_coins_are_reproducible_without_changing_training_rng():
    raw = {"body":torch.ones(200),"head":torch.ones(20)}
    groups = [list(range(200,210)),list(range(210,220))]
    rng = torch.get_rng_state()
    _,a,history,_ = protected_topk(raw,groups,20,temperature=1.,seed=8)
    _,b,_,_ = protected_topk(raw,groups,20,temperature=1.,seed=8)
    _,c,_,_ = protected_topk(raw,groups,20,temperature=1.,seed=9)
    assert torch.equal(a,b) and not torch.equal(a,c)
    assert torch.equal(rng,torch.get_rng_state())
    _,next_ix,_,metrics = protected_topk(raw,groups,20,repeat_penalty=100.,previous=history,round_idx=1)
    assert not torch.isin(history,next_ix).any()
    assert metrics["support_repeat_fraction"] == 0.


def test_head_only_model_and_zero_update_have_finite_metrics():
    raw = {"head":torch.zeros(10)}
    out,ix,_,metrics = protected_topk(raw,[list(range(5)),list(range(5,10))],4)
    assert len(ix) == 4 and out["head"].count_nonzero() == 0
    assert all(torch.isfinite(torch.tensor(value)) for value in metrics.values())


def test_server_adam_matches_torch_and_restores_optimizer_state():
    ref = nn.Parameter(torch.tensor([2.,-3.]))
    opt = torch.optim.Adam([ref],lr=.01,betas=(.9,.99),eps=.001)
    server = ServerAdam(2,"cpu")
    global_model = ref.detach().clone()
    for step in range(4):
        update = torch.tensor([.1+step*.05,-.2])
        ref.grad = -update
        opt.step()
        delta = server.step({"weight":update})["weight"]
        global_model += delta
        assert torch.allclose(global_model,ref,atol=1e-6,rtol=0.)
        restored = ServerAdam(2,"cpu")
        restored.load_state_dict(copy.deepcopy(server.state_dict()))
    assert torch.equal(server.step({"weight":update})["weight"],restored.step({"weight":update})["weight"])


def test_default_checkpoint_extension_is_empty():
    from Clover_api.Clover.Clover_api import CloverAPI
    assert CloverAPI._checkpoint_extension_payload(None,1) == {}


def test_server_momentum_matches_torch_and_checkpoint_restores_missing_coordinate_history():
    from Clover_api.privacy.protected_support import ServerMomentum
    ref = nn.Parameter(torch.tensor([2.,-3.]))
    optimizer = torch.optim.SGD([ref],lr=5.,momentum=.9)
    server = ServerMomentum(2,'cpu',lr=5.,momentum=.9)
    global_model = ref.detach().clone()
    for update in (torch.tensor([.1,0.]),torch.tensor([0.,-.2]),torch.tensor([0.,0.]),torch.tensor([.03,-.01])):
        ref.grad = -update.clone()
        optimizer.step()
        before = update.clone()
        delta = server.step({'weight':update})['weight']
        global_model += delta
        torch.testing.assert_close(global_model,ref,atol=1e-6,rtol=0.)
        assert torch.equal(update,before)
    restored = ServerMomentum(2,'cpu',lr=5.,momentum=.9)
    restored.load_state_dict(copy.deepcopy(server.state_dict()))
    update = {'weight':torch.tensor([0.,.02])}
    assert torch.equal(server.step(update)['weight'],restored.step(update)['weight'])
