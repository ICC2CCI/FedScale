from __future__ import annotations

from pathlib import Path
import sys

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from Clover_api.SketchOPA.quant_transport import dequantize_transport, quantize_transport


def test_segmented_quant_dequant_keeps_lengths_and_ranges():
    segments = [
        (np.array([1.25, -2.5, 0.0]), "float32", None),
        (np.array([1.25, -2.5, 0.0]), "float16", None),
        (np.array([0.1, -0.2, 0.3]), "int16_public_scale", 0.01),
    ]
    recovered = []
    for segment, dtype, scale in segments:
        q = quantize_transport(segment, dtype, layer_scale=scale)
        d = dequantize_transport(q, dtype, layer_scale=scale)
        assert d.shape == segment.shape
        assert np.all(np.isfinite(d))
        recovered.append(d)
    concat = np.concatenate(recovered)
    assert concat.size == 9
    assert np.max(np.abs(recovered[-1] - segments[-1][0])) <= 0.01
