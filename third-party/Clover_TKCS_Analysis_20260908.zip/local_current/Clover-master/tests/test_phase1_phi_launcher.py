import importlib.util
import tempfile
from argparse import Namespace
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
MODULE_PATH = ROOT / "experiments" / "phase1" / "run_phi.py"
SPEC = importlib.util.spec_from_file_location("phase1_run_phi", MODULE_PATH)
MODULE = importlib.util.module_from_spec(SPEC)
assert SPEC.loader is not None
SPEC.loader.exec_module(MODULE)


def test_phi_stage_and_path_contract():
    assert MODULE.target_rounds("smoke") == 2
    assert MODULE.target_rounds("formal") == 15
    assert MODULE.target_rounds("formal", 30) == 30
    with tempfile.TemporaryDirectory() as tmp:
        args = Namespace(
            method="tkcs",
            stage="formal",
            output_root=Path(tmp),
            seed=1,
        )
        assert MODULE.run_dir(args).relative_to(Path(tmp)) == Path(
            "alpaca_gpt4/phi4_mini_dora/flowertune_native_iid/tkcs/rho_0.01/seed_1"
        )
        args.method = "topk_residual"
        assert MODULE.run_dir(args).relative_to(Path(tmp)) == Path(
            "alpaca_gpt4/phi4_mini_dora/flowertune_native_iid/topk_residual/rho_0.01/seed_1"
        )


def test_phi_explicit_formal_rounds_use_an_independent_namespace():
    with tempfile.TemporaryDirectory() as tmp:
        args = Namespace(
            method="dense",
            stage="formal",
            rounds=30,
            output_root=Path(tmp),
            seed=1,
        )
        assert MODULE.run_dir(args).relative_to(Path(tmp)) == Path(
            "alpaca_gpt4/phi4_mini_dora/flowertune_native_iid/rounds_30/dense/rho_1/seed_1"
        )


def test_phi_round_override_is_formal_only():
    try:
        MODULE.target_rounds("smoke", 30)
    except ValueError as error:
        assert "formal" in str(error)
    else:
        raise AssertionError("smoke round override must be rejected")


if __name__ == "__main__":
    test_phi_stage_and_path_contract()
    test_phi_explicit_formal_rounds_use_an_independent_namespace()
    test_phi_round_override_is_formal_only()
