import json
import sys
from pathlib import Path
from types import SimpleNamespace


ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from experiments.phase1.run_vision import build_command, load_matrix


def _args(dataset, distribution, method, stage):
    return SimpleNamespace(
        dataset=dataset,
        distribution=distribution,
        method=method,
        stage=stage,
        rounds=None,
        seed=1,
        python="python",
        gpu=0,
        data_root=Path("/data"),
        output_root=Path("/results"),
        source_sha256="0" * 64,
        resume=False,
        aps_probe_batch_size=32,
        aps_probe_interval=5,
        aps_protected_scope="classifier+last_block",
        aps_rho_max=0.5,
        aps_lambda_utility=1.0,
        aps_ema_beta_direction=0.9,
        aps_ema_beta_risk=0.9,
        aps_tau_cos=0.98,
        aps_tau_dist=0.10,
        aps_state_dtype="float16",
        aps_bisection_steps=10,
        aps_block_granularity="auto",
        dry_run=True,
    )


def test_formal_matrix_contains_exactly_30_vision_runs():
    matrix = load_matrix()
    assert len(matrix["datasets"]) * len(matrix["distributions"]) * len(matrix["methods"]) == 30
    assert matrix["datasets"]["cifar10"]["formal_rounds"] == 200
    assert matrix["datasets"]["cifar100"]["formal_rounds"] == 500
    assert matrix["datasets"]["tiny_imagenet"]["formal_rounds"] == 500


def test_combined_phase1_manifest_contains_exactly_39_formal_runs():
    vision = load_matrix()
    large = json.loads(
        (ROOT / "experiments" / "phase1" / "large_model_matrix.json").read_text(
            encoding="utf-8"
        )
    )
    vision_count = len(vision["datasets"]) * len(vision["distributions"]) * len(vision["methods"])
    roberta_count = len(large["roberta"]["tasks"]) * len(large["methods"])
    phi_count = len(large["methods"])
    assert (vision_count, roberta_count, phi_count) == (30, 6, 3)
    assert vision_count + roberta_count + phi_count == 39


def test_commands_bind_strict_k_plaintext_and_expected_residual_semantics():
    matrix = load_matrix()
    dense, _, _, _ = build_command(_args("mnist", "iid", "dense", "formal"), matrix)
    topk, _, _, _ = build_command(_args("mnist", "iid", "topk", "formal"), matrix)
    tkcs, _, _, _ = build_command(_args("mnist", "iid", "tkcs", "formal"), matrix)
    assert "--phase1_strict_k" in dense
    assert dense[dense.index("--sigma") + 1] == "0"
    assert dense[dense.index("--aggregation_mode") + 1] == "dense"
    assert topk[topk.index("--aggregation_mode") + 1] == "topk_plain"
    assert "--use_residual_topk" not in topk
    assert tkcs[tkcs.index("--aggregation_mode") + 1] == "sketchopa_plain_cs_residual"
    assert not any("secure" in token for token in tkcs)


def test_adaptive_extension_is_isolated_and_matched_to_residual_topk():
    matrix = load_matrix()
    baseline, baseline_dir, _, _ = build_command(
        _args("mnist", "iid", "topk_residual", "adaptive"), matrix
    )
    adaptive, adaptive_dir, _, _ = build_command(
        _args("mnist", "iid", "topk_aps", "adaptive"), matrix
    )
    assert baseline[baseline.index("--aggregation_mode") + 1] == "topk_residual"
    assert adaptive[adaptive.index("--aggregation_mode") + 1] == "topk_adaptive"
    assert "--use_residual_topk" in adaptive
    assert "--aps_enabled" in adaptive
    assert adaptive[adaptive.index("--alpha") + 1] == baseline[baseline.index("--alpha") + 1]
    assert not any(token.startswith("--sketch_") for token in adaptive)
    assert not any("secure" in token for token in adaptive)
    assert baseline_dir != adaptive_dir
    assert baseline[baseline.index("--epochs") + 1] == "30"
    assert "adaptive" in baseline_dir.parts


def test_smoke_is_isolated_and_lightweight_but_formal_keeps_original_training_config():
    matrix = load_matrix()
    smoke, smoke_dir, _, smoke_rounds = build_command(
        _args("cifar100", "iid", "tkcs", "smoke"), matrix
    )
    formal, formal_dir, _, formal_rounds = build_command(
        _args("cifar100", "iid", "tkcs", "formal"), matrix
    )
    assert smoke_rounds == 2
    assert smoke[smoke.index("--epochs") + 1] == "1"
    assert "gates" in smoke_dir.parts
    assert formal_rounds == 500
    assert formal[formal.index("--epochs") + 1] == "30"
    assert "gates" not in formal_dir.parts


def test_fmnist_non_iid_uses_stable_local_epoch_override_only_for_that_cell():
    matrix = load_matrix()
    fmnist_iid, _, _, _ = build_command(
        _args("fmnist", "iid", "dense", "formal"), matrix
    )
    fmnist_non_iid, _, _, _ = build_command(
        _args("fmnist", "dirichlet_beta1", "dense", "formal"), matrix
    )
    mnist_non_iid, _, _, _ = build_command(
        _args("mnist", "dirichlet_beta1", "dense", "formal"), matrix
    )
    assert fmnist_iid[fmnist_iid.index("--epochs") + 1] == "30"
    assert fmnist_non_iid[fmnist_non_iid.index("--epochs") + 1] == "5"
    assert mnist_non_iid[mnist_non_iid.index("--epochs") + 1] == "30"
    assert fmnist_non_iid[fmnist_non_iid.index("--lr") + 1] == "0.1"


if __name__ == "__main__":
    test_formal_matrix_contains_exactly_30_vision_runs()
    test_combined_phase1_manifest_contains_exactly_39_formal_runs()
    test_commands_bind_strict_k_plaintext_and_expected_residual_semantics()
    test_adaptive_extension_is_isolated_and_matched_to_residual_topk()
    test_smoke_is_isolated_and_lightweight_but_formal_keeps_original_training_config()
    test_fmnist_non_iid_uses_stable_local_epoch_override_only_for_that_cell()
