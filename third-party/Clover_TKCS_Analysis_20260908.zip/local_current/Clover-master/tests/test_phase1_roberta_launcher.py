import importlib.util
import ast
import sys
import tempfile
from argparse import Namespace
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
MODULE_PATH = ROOT / "experiments" / "phase1" / "run_roberta.py"
SPEC = importlib.util.spec_from_file_location("phase1_run_roberta", MODULE_PATH)
MODULE = importlib.util.module_from_spec(SPEC)
assert SPEC.loader is not None
SPEC.loader.exec_module(MODULE)


def _args(root, task="cola", method="dense", stage="formal"):
    return Namespace(
        task=task,
        method=method,
        stage=stage,
        output_root=Path(root),
        seed=1,
    )


def test_roberta_stage_and_path_contract():
    with tempfile.TemporaryDirectory() as tmp:
        args = _args(tmp)
        assert MODULE.stage_settings(args) == (500, 20)
        assert MODULE.run_dir(args).relative_to(Path(tmp)) == Path(
            "cola/roberta_large_lora/native_iid_like/dense/rho_1/seed_1"
        )
        smoke = _args(tmp, task="mrpc", method="tkcs", stage="smoke")
        assert MODULE.stage_settings(smoke) == (2, 2)
        assert "gates/smoke" in MODULE.run_dir(smoke).as_posix()
        residual = _args(tmp, task="mrpc", method="topk_residual", stage="formal")
        assert MODULE.run_dir(residual).relative_to(Path(tmp)) == Path(
            "mrpc/roberta_large_lora/native_iid_like/topk_residual/rho_0.01/seed_1"
        )


def test_roberta_feasibility_is_cola_only():
    with tempfile.TemporaryDirectory() as tmp:
        args = _args(tmp, task="mrpc", method="topk", stage="feasibility")
        try:
            MODULE.stage_settings(args)
        except ValueError as error:
            assert "CoLA" in str(error)
        else:
            raise AssertionError("MRPC feasibility must be rejected")


def test_roberta_worker_matches_federatedscope_llm_contract():
    worker_path = ROOT / "experiments" / "phase1" / "roberta_worker.py"
    source = worker_path.read_text(encoding="utf-8")
    tree = ast.parse(source)
    trainer_calls = [
        node
        for node in ast.walk(tree)
        if isinstance(node, ast.Call)
        and isinstance(node.func, ast.Name)
        and node.func.id == "get_trainer"
    ]
    assert len(trainer_calls) == 1
    assert any(keyword.arg == "monitor" for keyword in trainer_calls[0].keywords)
    assert '.rename_column("label", "labels")' in source
    assert 'batch["labels"]' in source
    assert 'data={"train": client_loader}' in source


if __name__ == "__main__":
    test_roberta_stage_and_path_contract()
    test_roberta_feasibility_is_cola_only()
    test_roberta_worker_matches_federatedscope_llm_contract()
