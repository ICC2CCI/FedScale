from Clover_api.SketchOPA.fixed_layout import build_fixed_public_layout
from Clover_api.SketchOPA.model_flatten import LayerSpec


def test_residual_flag_does_not_change_fixed_payload():
    specs = [
        LayerSpec("conv.weight", 0, 2048, (2048,)),
        LayerSpec("fc.weight", 2048, 4096, (2048,)),
    ]
    no_residual_layout = build_fixed_public_layout(
        layer_specs=specs,
        k_global=40,
        rows=5,
        budget_ratio=1.0,
        value_dtype="float16",
        allocation_strategy="uniform_param",
        min_buckets=1,
    )
    residual_layout = build_fixed_public_layout(
        layer_specs=specs,
        k_global=40,
        rows=5,
        budget_ratio=1.0,
        value_dtype="float16",
        allocation_strategy="uniform_param",
        min_buckets=1,
    )
    assert no_residual_layout.payload_bytes == residual_layout.payload_bytes
    assert no_residual_layout.layout_hash == residual_layout.layout_hash
