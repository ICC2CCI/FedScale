import tempfile
from pathlib import Path
from types import SimpleNamespace
import sys
import numpy as np
import torch

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from experiments.adaptive_privacy.run_aids_goal import sparse_gate, ExactWireRecorder, GoalGraphTrainer
from experiments.adaptive_privacy.goal_attacks import tied_average_precision, jac_scores, evaluate_features


def test_sparse_gate_bounds_actual_quantized_update():
    raw = {"weight": torch.tensor([1., .999, .1])}
    safe = {"weight": torch.tensor([.998, .999, .1])}
    before = raw["weight"].clone()
    chosen, sparse, indices, metrics = sparse_gate(raw, safe, 1, torch.device("cpu"))
    assert indices.tolist() == [0]
    assert metrics["sparse_gate_scale"] < 1
    assert metrics["sparse_gate_cosine"] >= .98
    assert metrics["sparse_gate_relative_distortion"] <= .1
    assert torch.equal(raw["weight"], before)
    residual = chosen["weight"]-sparse["weight"]
    assert torch.equal(residual+sparse["weight"], chosen["weight"])


def test_wire_recorder_contains_exact_transmitted_values_only():
    with tempfile.TemporaryDirectory() as tmp:
        args = SimpleNamespace(phase1_run_dir=tmp, privacy_trace_feature_bins=16, seed=11,
            dataset="aids", model="gcn_graph", aggregation_mode="topk_adaptive",
            phase1_partition_manifest={"partition_sha256":"a"*64}, partition_method="dir",
            partition_alpha=.5, phase1_source_sha256="b"*64, privacy_trace_target_class=0,
            update_transport_dtype="float16", topk_k=2, comm_round=1, federated_update_dim=10)
        recorder = ExactWireRecorder(args, [[10,0], [0,10]])
        state = torch.get_rng_state()
        recorder.record_client(0, np.array([8,2]), np.array([.123456,0.], dtype=np.float16))
        recorder.record_round(0, [0])
        with np.load(Path(tmp)/"topk_attack_trace/wire_00001.npz") as data:
            assert data["indices"].tolist() == [[8,2]]
            assert data["values"].dtype == np.float16
            assert not any(k in data for k in ("residual", "ema", "probe", "label"))
        assert torch.equal(state, torch.get_rng_state())


def test_average_precision_groups_ties_and_jac_is_exact():
    y = np.array([0, 1, 0, 1])
    assert tied_average_precision(y, np.ones(4)) == .5
    assert tied_average_precision(y, y) == 1.
    observed = [np.array([[1,2], [4,5]])]
    teacher = [np.array([[1,2], [2,3]])]
    assert np.allclose(jac_scores(observed, teacher), [[1., 1/3], [0., 0.]])


def test_stronger_attack_positive_control_constant_and_disjoint_split():
    labels = np.arange(60) % 2
    hist = np.c_[2+26*labels, 28-26*labels]
    x = np.eye(2)[labels]
    rows, audit = evaluate_features({"signal":x}, hist, np.ones((60,1)), np.arange(60), split_seeds=(1,))
    dominant = {r["control"]:r for r in rows if r["task"] == "dominant_label"}
    assert dominant["observed"]["balanced_accuracy"] == 1.
    assert dominant["constant"]["balanced_accuracy"] == .5
    assert dominant["constant"]["roc_auc_ovr_macro"] == .5
    for split in audit:
        if "fit_clients" in split:
            assert not set(split["fit_clients"]) & set(split["validation_clients"])
            assert not set(split["training_clients"]) & set(split["test_clients"])


def test_private_class_weights_equalize_class_loss_without_public_counts():
    args = SimpleNamespace(goal_config={"local_class_balance":True})
    batches = [SimpleNamespace(y=torch.tensor([0,0,0,1]))]
    weights = GoalGraphTrainer._training_weights(None,batches,torch.device("cpu"),args)
    assert torch.allclose(weights,torch.tensor([2/3,2.]))
    losses = torch.tensor([1.,1.,1.,3.])
    assert torch.isclose((losses*weights[batches[0].y]).mean(), torch.tensor(2.))
    args.goal_config = {}
    assert GoalGraphTrainer._training_weights(None,batches,torch.device("cpu"),args) is None


def test_fixed_loss_weights_do_not_read_client_histograms_and_validate_config():
    args = SimpleNamespace(goal_config={"fixed_class_weights":[4.,1.]})
    weights = GoalGraphTrainer._training_weights(None,None,torch.device("cpu"),args)
    assert torch.equal(weights,torch.tensor([4.,1.]))
    for config in ({"fixed_class_weights":[0.,1.]}, {"fixed_class_weights":[1.]},
                   {"fixed_class_weights":[1.,float("nan")]},
                   {"fixed_class_weights":[4.,1.],"local_class_balance":True}):
        args.goal_config = config
        try:
            GoalGraphTrainer._training_weights(None,None,torch.device("cpu"),args)
        except ValueError:
            pass
        else:
            raise AssertionError("invalid loss-weight configuration accepted")


def test_source_jac_union_differs_from_round_tagged_variant():
    from experiments.adaptive_privacy.olive_source_attack import union_jac
    observed = [np.array([[1]]),np.array([[2]])]
    teacher = [np.array([[2],[3]]),np.array([[1],[4]])]
    assert np.allclose(union_jac(observed,teacher),[[1.,0.]])
    assert np.allclose(jac_scores(observed,teacher),[[0.,0.]])


def test_source_exact_2means_matches_exhaustive_partitions_and_scaling():
    from experiments.adaptive_privacy.olive_source_attack import high_score_cluster
    rng = np.random.default_rng(317)
    for _ in range(30):
        row = rng.normal(size=7)
        inferred = high_score_cluster(row)
        def error(mask):
            return sum(np.sum((v-v.mean())**2) for v in (row[mask],row[~mask]))
        best = min(error(np.array([(bits >> i)&1 for i in range(len(row))],dtype=bool))
                   for bits in range(1,2**len(row)-1))
        assert np.isclose(error(inferred),best)
        assert np.array_equal(inferred,high_score_cluster(20*row+3))
        assert row[inferred].mean() > row[~inferred].mean()
    assert not high_score_cluster(np.ones(10)).any()
    assert high_score_cluster(np.array([0.,0.,0.,2.])).tolist() == [False,False,False,True]


def test_source_log_prob_and_prob_are_not_interchangeable_for_label_sets():
    from experiments.adaptive_privacy.olive_source_attack import high_score_cluster
    log_prob = np.log(np.array([.7,.2,.09,.01]))
    assert not np.array_equal(high_score_cluster(log_prob),high_score_cluster(np.exp(log_prob)))


def test_full_client_step_recovers_weighted_global_gradient():
    import copy
    from torch.nn import functional as F
    from torch_geometric.data import Data,Batch
    from experiments.adaptive_privacy.aids_vendor.gcn_graph_clf import GCNGraphClassifier
    torch.manual_seed(722)
    initial = GCNGraphClassifier(3,4,2,dropout=0.)
    graphs = [Data(x=torch.eye(3)*(i+1)/7,edge_index=torch.tensor([[0,1],[1,2]]),y=torch.tensor([i%2])) for i in range(7)]
    weights = torch.tensor([4.,1.])
    args = SimpleNamespace(goal_config={"fixed_class_weights":[4.,1.]},client_optimizer="sgd",lr=.1,momentum=0.,wd=0.,epochs=1)
    expected = copy.deepcopy(initial)
    optimizer = torch.optim.SGD(expected.parameters(),lr=.1)
    batch = Batch.from_data_list(graphs)
    loss = (F.cross_entropy(expected(batch),batch.y,reduction="none")*weights[batch.y]).mean()
    loss.backward()
    optimizer.step()
    updates = []
    for subset in (graphs[:2],graphs[2:]):
        local = copy.deepcopy(initial)
        trainer = GoalGraphTrainer(local,args,None)
        trainer.train([Batch.from_data_list(subset)],torch.device("cpu"),args,0)
        updates.append((len(subset),local.state_dict()))
    for name,value in expected.state_dict().items():
        aggregate = sum(n*state[name]/len(graphs) for n,state in updates)
        torch.testing.assert_close(aggregate,value,rtol=1e-5,atol=1e-7)


def test_source_teacher_preserves_global_model_gradients_rng_and_public_split():
    from experiments.adaptive_privacy.olive_source_attack import record_source_teacher
    from experiments.adaptive_privacy.aids_vendor.gcn_graph_clf import GCNGraphClassifier
    from torch_geometric.data import Data
    import json
    torch.manual_seed(4)
    model = GCNGraphClassifier(3,4,2).eval()
    for param in model.parameters():
        param.grad = torch.ones_like(param)
    before = {k:v.clone() for k,v in model.state_dict().items()}
    graphs = [Data(x=torch.eye(3),edge_index=torch.tensor([[0,1],[1,2]]),y=torch.tensor([i%2]),
                   original_graph_id=i) for i in range(16)]
    args = SimpleNamespace(seed=11,client_optimizer="adam",lr=.001,epochs=1,batch_size=4,topk_k=3)
    rng = torch.get_rng_state()
    with tempfile.TemporaryDirectory() as tmp:
        record_source_teacher(model,graphs,args,0,Path(tmp),torch.device("cpu"))
        record_source_teacher(model,graphs,args,0,Path(tmp),torch.device("cpu"))
        manifest = json.loads((Path(tmp)/"source_public_manifest.json").read_text())
        train = {i for group,split in zip(manifest["groups"],manifest["splits"]) if split == "train" for i in group}
        valid = {i for group,split in zip(manifest["groups"],manifest["splits"]) if split == "validation" for i in group}
        assert not train & valid and len(train|valid) == 16
    assert torch.equal(rng,torch.get_rng_state())
    assert not model.training
    assert all(torch.equal(before[k],v) for k,v in model.state_dict().items())
    assert all(torch.equal(p.grad,torch.ones_like(p)) for p in model.parameters())


def test_source_nn_positive_control_and_rng_isolation():
    from experiments.adaptive_privacy.olive_source_attack import fit_nn
    y = np.arange(40)%2
    x = torch.tensor(np.eye(2)[y],dtype=torch.float32)
    split = np.array(["train"]*30+["validation"]*10)
    before = torch.get_rng_state()
    score,history = fit_nn(x,y,split,x,hidden=16,epochs=50,lr=.1,seed=32)
    assert np.mean(score.argmax(1) == y) == 1.
    assert history[-1]["public_validation_balanced_accuracy"] == 1.
    assert torch.equal(before,torch.get_rng_state())
