import logging
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from Clover_api.data_preprocessing.fmnist.data_loader import partition_data as partition_fmnist
from Clover_api.data_preprocessing.mnist.data_loader import partition_data as partition_mnist


def main():
    logger = logging.getLogger("check_dir_partition")
    partition_mnist("data/datamnist", "dir", 10, 0.5, logger)
    partition_fmnist("data/datafmnist", "dir", 10, 0.5, logger)
    print("dir_partition_ok")


if __name__ == "__main__":
    main()
