import csv
import math
import sys
import tempfile
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from Clover_api.phase1.runtime import (
    append_csv_row,
    exact_topk_count,
    recovery_at_k,
    serialized_metadata_bytes,
    support_summary,
    timing_block_rows,
    truncate_csv_after_round,
)


def test_exact_topk_count_uses_ceil_only_when_requested():
    assert exact_topk_count(0.01, 431080, strict_ceil=True) == 4311
    assert exact_topk_count(0.01, 431080, strict_ceil=False) == 4310
    assert exact_topk_count(1.0, 17, strict_ceil=True) == 17
    assert exact_topk_count(0.0, 17, strict_ceil=True) == 0


def test_support_and_recovery_metrics_have_phase1_semantics():
    support = support_summary([{1, 3}, {3, 4}], 10)
    assert support["mean_client_support_size"] == 2.0
    assert support["union_support_size"] == 3
    assert math.isclose(support["union_support_density"], 0.3)
    recovered = recovery_at_k(
        np.asarray([4.0, 3.0, 0.0, 0.0]),
        np.asarray([4.0, 0.0, 2.0, 0.0]),
        2,
    )
    assert recovered["recall_at_k"] == 0.5
    assert recovered["precision_at_k"] == 0.5
    assert recovered["nmse"] > 0.0


def test_metadata_measurement_is_canonical_and_not_object_size():
    lhs = serialized_metadata_bytes({"b": 2, "a": 1})
    rhs = len(b'{"a":1,"b":2}')
    assert lhs == rhs


def test_resume_truncation_and_partial_timing_block():
    with tempfile.TemporaryDirectory() as tmp:
        path = Path(tmp) / "metrics.csv"
        for round_number in range(1, 4):
            append_csv_row(path, ["round", "value"], {"round": round_number, "value": round_number})
        assert truncate_csv_after_round(path, 2) == 2
        with path.open("r", newline="", encoding="utf-8") as handle:
            assert [int(row["round"]) for row in csv.DictReader(handle)] == [1, 2]

    rows = [
        {
            "round": value,
            "train_compute_sec": 1.0,
            "topk_sec": 0.1,
            "sketch_encode_sec": 0.2,
            "aggregation_sec": 0.3,
            "sketch_aggregate_sec": 0.4,
            "sketch_recover_sec": 0.5,
            "evaluation_sec": 0.6,
            "round_wall_sec": 3.0,
        }
        for value in range(1, 16)
    ]
    blocks = timing_block_rows(
        rows,
        dataset="phi",
        model="phi",
        distribution="native",
        method="dense",
        rho=1.0,
        seed=1,
    )
    assert [(row["start_round"], row["end_round"]) for row in blocks] == [(1, 10), (11, 15)]
    assert blocks[-1]["num_rounds"] == 5
    assert blocks[-1]["cumulative_wall_sec"] == 45.0


if __name__ == "__main__":
    test_exact_topk_count_uses_ceil_only_when_requested()
    test_support_and_recovery_metrics_have_phase1_semantics()
    test_metadata_measurement_is_canonical_and_not_object_size()
    test_resume_truncation_and_partial_timing_block()
