import json
import sys
import tempfile
from pathlib import Path
from types import SimpleNamespace

import torch

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from Clover_api.Clover.Clover_api import CloverAPI
from Clover_api.privacy.adaptive_privacy_stripping import (
    AdaptivePrivacyStripper,
    AdaptivePrivacyStrippingConfig,
)


class _ResidualAggregator:
    def __init__(self):
        self.residuals = {4: torch.tensor([1.0, -2.0])}

    @staticmethod
    def _mode_uses_residual():
        return True


def test_tkcs_checkpoint_persists_residual_shards_and_manifest():
    with tempfile.TemporaryDirectory() as tmp:
        root = Path(tmp)
        recorder = SimpleNamespace(
            checkpoint_dir=root / "checkpoints",
            latest_checkpoint_path=root / "checkpoints" / "latest_checkpoint.pt",
            residual_manifest_path=root / "checkpoints" / "residual_manifest.json",
            latest_checkpoint_meta_path=root / "checkpoints" / "latest_checkpoint_meta.json",
            checkpoint_events_path=root / "checkpoint_events.csv",
        )
        recorder.checkpoint_dir.mkdir(parents=True)

        api = object.__new__(CloverAPI)
        api.phase1_recorder = recorder
        api.phase1_residual_manifest = {}
        api.phase1_dirty_residual_clients = {4}
        api.sketchopa_aggregator = _ResidualAggregator()
        api.use_residual_topk = False
        api.topk_residuals = {}
        api.stat_info = {"global_test_acc": [0.5]}
        api.aggregation_mode = "sketchopa_plain_cs_residual"
        api.args = SimpleNamespace(
            dataset="mnist",
            model="lenet5",
            seed=1,
            federated_update_dim=2,
            topk_k=1,
            phase1_partition_manifest={"partition_sha256": "fixture-partition"},
        )

        api._save_phase1_checkpoint(
            round_idx=0,
            exper_index=0,
            global_weight={"weight": torch.tensor([3.0, 4.0])},
        )

        checkpoint = CloverAPI._phase1_torch_load(recorder.latest_checkpoint_path)
        manifest = json.loads(recorder.residual_manifest_path.read_text(encoding="utf-8"))
        residual_path = recorder.checkpoint_dir / manifest["4"]["path"]

        assert checkpoint["round_number"] == 1
        assert checkpoint["next_round"] == 1
        assert checkpoint["residual_manifest"] == manifest
        assert residual_path.is_file()
        assert torch.equal(CloverAPI._phase1_torch_load(residual_path), torch.tensor([1.0, -2.0]))
        assert not api.phase1_dirty_residual_clients


def test_checkpoint_persists_hash_bound_adaptive_privacy_state_shards():
    with tempfile.TemporaryDirectory() as tmp:
        root = Path(tmp)
        recorder = SimpleNamespace(
            checkpoint_dir=root / "checkpoint",
            latest_checkpoint_path=root / "checkpoint" / "latest.pt",
            residual_manifest_path=root / "checkpoint" / "residual_manifest.json",
            adaptive_privacy_state_manifest_path=(
                root / "checkpoint" / "adaptive_privacy_state_manifest.json"
            ),
            latest_checkpoint_meta_path=root / "checkpoint" / "latest_meta.json",
            checkpoint_events_path=root / "checkpoint" / "checkpoint_events.csv",
        )
        recorder.checkpoint_dir.mkdir(parents=True)
        model = torch.nn.Sequential()
        model.add_module("head", torch.nn.Linear(2, 2, bias=False))
        config = AdaptivePrivacyStrippingConfig(
            enabled=True,
            protected_scope="head",
            state_dtype="float32",
        )
        stripper = AdaptivePrivacyStripper(model, config, "cpu", 2)
        stripper.update_ema_state(
            {
                "classifier:head.weight:class_0": (torch.tensor([1.0, 0.0]),),
                "classifier:head.weight:class_1": (torch.tensor([0.0, 1.0]),),
            },
            {
                "classifier:head.weight:class_0": 0.5,
                "classifier:head.weight:class_1": 0.5,
            },
            round_idx=0,
        )

        api = object.__new__(CloverAPI)
        api.phase1_recorder = recorder
        api.phase1_residual_manifest = {}
        api.phase1_adaptive_privacy_state_manifest = {}
        api.phase1_dirty_residual_clients = set()
        api.phase1_dirty_adaptive_privacy_clients = {3}
        api.adaptive_privacy_strippers = {3: stripper}
        api.sketchopa_aggregator = None
        api.use_residual_topk = False
        api.topk_residuals = {}
        api.stat_info = {"global_test_acc": [0.5]}
        api.aggregation_mode = "topk_adaptive"
        api.args = SimpleNamespace(
            dataset="mnist",
            model="lenet5",
            seed=1,
            federated_update_dim=4,
            topk_k=1,
            phase1_partition_manifest={"partition_sha256": "fixture-partition"},
        )
        api._save_phase1_checkpoint(
            round_idx=0,
            exper_index=0,
            global_weight={"weight": torch.tensor([3.0, 4.0])},
        )
        checkpoint = CloverAPI._phase1_torch_load(recorder.latest_checkpoint_path)
        manifest = json.loads(
            recorder.adaptive_privacy_state_manifest_path.read_text(encoding="utf-8")
        )
        state_path = recorder.checkpoint_dir / manifest["3"]["path"]
        assert checkpoint["adaptive_privacy_state_manifest"] == manifest
        assert state_path.is_file()
        restored = AdaptivePrivacyStripper(model, config, "cpu", 2)
        restored.load_state_dict(CloverAPI._phase1_torch_load(state_path))
        assert restored.state_dict()["blocks"].keys() == stripper.state_dict()["blocks"].keys()
        assert not api.phase1_dirty_adaptive_privacy_clients


if __name__ == "__main__":
    test_tkcs_checkpoint_persists_residual_shards_and_manifest()
    test_checkpoint_persists_hash_bound_adaptive_privacy_state_shards()
