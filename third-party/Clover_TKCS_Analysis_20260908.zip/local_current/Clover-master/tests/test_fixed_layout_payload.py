from Clover_api.SketchOPA.fixed_layout import (
    build_fixed_public_layout,
    estimate_topk16_payload_bytes,
)
from Clover_api.SketchOPA.model_flatten import LayerSpec


def test_fixed_layout_payload_respects_topk16_budget():
    specs = [
        LayerSpec("a.weight", 0, 1000, (1000,)),
        LayerSpec("b.weight", 1000, 3000, (2000,)),
        LayerSpec("c.weight", 3000, 4310, (1310,)),
    ]
    layout = build_fixed_public_layout(
        layer_specs=specs,
        k_global=431,
        rows=5,
        budget_ratio=1.0,
        value_dtype="float16",
        allocation_strategy="uniform_param",
        min_buckets=1,
        dataset="mnist",
        model="lenet5",
    )
    assert layout.budget.target_payload_bytes == estimate_topk16_payload_bytes(431)
    assert layout.payload_bytes <= layout.budget.target_payload_bytes
    assert layout.payload_bytes == layout.budget.effective_payload_bytes
    assert sum(layer.buckets_per_row for layer in layout.layers) == layout.budget.total_buckets


def test_calibrated_strategy_falls_back_without_stats():
    specs = [
        LayerSpec("a.weight", 0, 100, (100,)),
        LayerSpec("b.weight", 100, 200, (100,)),
    ]
    layout = build_fixed_public_layout(
        layer_specs=specs,
        k_global=20,
        rows=5,
        budget_ratio=1.0,
        value_dtype="float16",
        allocation_strategy="topk_count_calibrated",
        min_buckets=1,
    )
    assert "fallback to uniform_param" in layout.fallback_reason
    assert layout.payload_bytes <= layout.budget.target_payload_bytes
