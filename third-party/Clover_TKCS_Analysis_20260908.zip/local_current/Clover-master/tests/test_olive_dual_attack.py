import copy
from pathlib import Path
import sys

import numpy as np
from scipy import sparse
import torch
from torch.nn import functional as F

sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from experiments.adaptive_privacy.olive_dual_attack import (
    multiround_matrix,stream_initialization,DualSourceMLP,fit_dual,
)
from experiments.adaptive_privacy.olive_source_attack import AttackMLP


def test_multiround_matrix_preserves_every_round_and_coordinate():
    x = multiround_matrix([np.array([[0,2],[1,3]]),np.array([[1,3],[1,2]])],4)
    assert x.shape == (2,8) and x.nnz == 8
    assert np.array_equal(x.toarray(),[[1,0,1,0,0,1,0,1],[0,1,0,1,0,1,1,0]])
    assert np.array_equal((x@x.T).toarray(),[[4,1],[1,4]])


def test_stream_projection_is_full_linear_initialization_and_rng_isolated():
    x = sparse.csr_matrix(np.eye(12,dtype=np.float32))
    state = torch.get_rng_state()
    initial = stream_initialization(x,7,3,11,"cpu",block_size=4,retain_weight=True)
    assert torch.equal(state,torch.get_rng_state())
    assert torch.allclose(initial["projection"],torch.from_numpy(x.toarray())@initial["weight"],atol=1e-6)
    assert initial["weight"].abs().max() <= 1/np.sqrt(12)
    again = stream_initialization(x,7,3,11,"cpu",block_size=4)
    assert torch.equal(initial["projection"],again["projection"])


def test_dual_matches_full_dense_sgd_with_momentum_dropout_and_bias():
    rng = np.random.default_rng(17)
    x = torch.tensor(rng.binomial(1,.3,(48,83)),dtype=torch.float32)
    train = torch.arange(32)
    y = torch.tensor(np.arange(48)%3,dtype=torch.long)
    initial = stream_initialization(sparse.csr_matrix(x.numpy()),17,3,11,"cpu",block_size=9,retain_weight=True)
    dual = DualSourceMLP(initial["projection"],x@x[train].T,initial,train)
    dense = AttackMLP(83,17,3)
    with torch.no_grad():
        dense.input.weight.copy_(initial["weight"].T)
        dense.input.bias.copy_(initial["bias"])
        dense.output.weight.copy_(initial["output_weight"])
        dense.output.bias.copy_(initial["output_bias"])
    optimizers = [torch.optim.SGD(model.parameters(),lr=.003,momentum=.5) for model in (dense,dual)]
    for step in range(50):
        selected = train[torch.randperm(len(train),generator=torch.Generator().manual_seed(step))[:8]]
        for model,optimizer in zip((dense,dual),optimizers):
            torch.manual_seed(734+step)
            optimizer.zero_grad(set_to_none=True)
            score = model(x[selected] if model is dense else selected)
            F.nll_loss(score,y[selected]).backward()
            if model is dual:
                model.set_first_layer_gradient(selected)
            optimizer.step()
        reconstructed = initial["weight"]+x[train].T@dual.coefficient
        assert torch.allclose(reconstructed,dense.input.weight.T,atol=2e-6,rtol=1e-5)
        assert torch.allclose(dual.bias,dense.input.bias,atol=2e-6,rtol=1e-5)
        assert torch.allclose(dual.output.weight,dense.output.weight,atol=2e-6,rtol=1e-5)
    dense.eval()
    dual.eval()
    with torch.no_grad():
        assert torch.allclose(dense(x),dual(torch.arange(len(x))),atol=3e-6,rtol=1e-5)


def test_dual_positive_control_learns_and_never_trains_on_observed_labels():
    labels = np.arange(40)%2
    target = np.arange(10)%2
    features = np.tile(np.eye(2,dtype=np.float32)[np.r_[labels,target]],(1,8))
    split = np.array(["train"]*30+["validation"]*10)
    score,history,audit = fit_dual(sparse.csr_matrix(features),labels,split,10,hidden=16,epochs=50,lr=.1,seed=4)
    assert (score.argmax(1) == target).mean() == 1.
    assert history[-1]["public_validation_balanced_accuracy"] == 1.
    assert audit["original_input_dimension"] == 16 and audit["dual_coefficients"] == 30*16
