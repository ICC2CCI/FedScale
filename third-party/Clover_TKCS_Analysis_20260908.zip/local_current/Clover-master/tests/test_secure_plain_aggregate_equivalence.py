from __future__ import annotations

from pathlib import Path
import sys

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from Clover_api.SketchOPA.secure_aggregation import secure_aggregate_sketches


def test_secure_aggregate_matches_plain_sum_for_small_integer_sketch():
    sketches = [np.array([1.0, -2.0, 3.0]), np.array([4.0, 5.0, -6.0])]
    plain = np.sum(np.stack(sketches), axis=0)
    secure, proof, metrics = secure_aggregate_sketches(
        sketches,
        context={"round_id": 3, "model_hash": "m", "sketch_seed": "s"},
        committee_size=7,
        threshold=5,
        shprg_backend="opa_lwr_shprg",
        plain_sum=plain,
        quantization_scale=1.0,
    )
    assert proof.valid
    assert metrics["secure_plain_sketch_linf_error"] == 0.0
    assert np.array_equal(secure, plain)
