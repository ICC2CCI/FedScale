from __future__ import annotations

from copy import deepcopy
from pathlib import Path
import sys

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from Clover_api.SketchOPA.protocol.auditor import OPAAuditor
from Clover_api.SketchOPA.protocol.dropout import build_active_set
from Clover_api.SketchOPA.secure_aggregation import secure_aggregate_sketches


def test_active_set_builder_requires_ciphertext_and_threshold_aux():
    active, dropped = build_active_set(
        selected_client_ids=["c0", "c1", "c2"],
        ciphertext_client_ids=["c0", "c2"],
        aux_client_ids_by_committee={"q0": ["c0", "c1"], "q1": ["c0"], "q2": ["c2"]},
        threshold=2,
    )
    assert active == ["c0"]
    assert dropped["c1"] == "missing_ciphertext"
    assert dropped["c2"] == "insufficient_aux_shares"


def test_active_set_substitution_fails_audit():
    sketches = [np.array([1.0, 0.0]), np.array([0.0, 2.0])]
    plain = np.sum(np.stack(sketches), axis=0)
    _, proof, _ = secure_aggregate_sketches(
        sketches,
        context={"round_id": 2, "model_hash": "m", "sketch_seed": "seed"},
        committee_size=5,
        threshold=3,
        shprg_backend="opa_lwr_shprg",
        plain_sum=plain,
        quantization_scale=1.0,
        protocol_backend="local_exact_debug",
    )
    tampered = deepcopy(proof.transcript)
    tampered.client_ids = tampered.client_ids[:1]
    valid, reason = OPAAuditor(threshold=3).verify(tampered)
    assert not valid
    assert "client" in reason
