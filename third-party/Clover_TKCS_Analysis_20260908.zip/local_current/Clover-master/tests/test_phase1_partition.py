import json
import sys
import tempfile
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from Clover_api.phase1.vision_data import create_or_load_partition


def _run(root: Path, method: str):
    train_labels = np.repeat(np.arange(4, dtype=np.int64), 50)
    test_labels = np.repeat(np.arange(4, dtype=np.int64), 10)
    return create_or_load_partition(
        dataset_name="fixture",
        train_labels=train_labels,
        test_labels=test_labels,
        class_count=4,
        client_count=10,
        partition_method=method,
        beta=1.0,
        seed=1,
        partition_dir=root,
    )


def test_partition_is_immutable_and_shared_across_methods():
    with tempfile.TemporaryDirectory() as tmp:
        root = Path(tmp)
        first, histograms = _run(root, "IID")
        second, second_histograms = _run(root, "IID")
        assert first["partition_sha256"] == second["partition_sha256"]
        assert first["train_indices"] == second["train_indices"]
        assert histograms == second_histograms
        assert (root / "client_class_histogram.csv").is_file()


def test_partition_rejects_configuration_drift():
    with tempfile.TemporaryDirectory() as tmp:
        root = Path(tmp)
        _run(root, "IID")
        path = root / "partition.json"
        value = json.loads(path.read_text(encoding="utf-8"))
        value["seed"] = 2
        path.write_text(json.dumps(value), encoding="utf-8")
        try:
            _run(root, "IID")
        except RuntimeError as exc:
            assert "immutable partition mismatch" in str(exc)
        else:
            raise AssertionError("partition drift was accepted")


def test_dirichlet_partition_has_every_client():
    with tempfile.TemporaryDirectory() as tmp:
        manifest, _ = _run(Path(tmp), "dir")
        assert min(len(values) for values in manifest["train_indices"]) > 0
        assert manifest["dirichlet_beta"] == 1.0


if __name__ == "__main__":
    test_partition_is_immutable_and_shared_across_methods()
    test_partition_rejects_configuration_drift()
    test_dirichlet_partition_has_every_client()
