import copy
from pathlib import Path
import random
import sys
from types import SimpleNamespace

import numpy as np
import torch
from torch_geometric.data import Batch, Data

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from experiments.adaptive_privacy.run_aids import GCNGraphClassifier, GraphTrainer, GraphCloverAPI, graph_dirichlet_partition
from Clover_api.privacy.adaptive_privacy_stripping import AdaptivePrivacyStripper, AdaptivePrivacyStrippingConfig


def graphs():
    return [Data(x=torch.eye(38)[:3].clone(), edge_index=torch.tensor([[0,1,1,2],[1,0,2,1]]),
                 y=torch.tensor([i % 2])) for i in range(8)]


def test_graph_partition_is_complete_reproducible_and_bounded():
    labels = np.repeat([0, 1], [320, 1280])
    for seed in (1, 2, 3):
        parts, audit = graph_dirichlet_partition(labels, 50, seed)
        assert (parts, audit) == graph_dirichlet_partition(labels, 50, seed)
        assert sorted(i for p in parts for i in p) == list(range(1600))
        assert min(map(len, parts)) >= 10 and len(parts) == 50
        assert audit["repair_transfers"] == sum(max(0, 10-n) for n in audit["pre_repair_sizes"])


def test_graph_trainer_matches_native_adam_step():
    torch.manual_seed(2)
    model = GCNGraphClassifier(38, 128, 2, dropout=.5)
    reference = copy.deepcopy(model)
    batch = Batch.from_data_list(graphs())
    args = SimpleNamespace(lr=.001, wd=0., epochs=1)
    state = torch.get_rng_state()
    GraphTrainer(model, args).train([batch], torch.device("cpu"), args, 0)
    torch.set_rng_state(state)
    optimizer = torch.optim.Adam(reference.parameters(), lr=.001, weight_decay=0., amsgrad=True)
    reference.train()
    optimizer.zero_grad()
    torch.nn.functional.cross_entropy(reference(batch), batch.y).backward()
    optimizer.step()
    assert all(torch.equal(v, reference.state_dict()[k]) for k,v in model.state_dict().items())


def test_graph_probe_scope_and_no_training_contamination():
    torch.manual_seed(3)
    model = GCNGraphClassifier(38, 128, 2)
    config = AdaptivePrivacyStrippingConfig(enabled=True)
    stripper = AdaptivePrivacyStripper(model, config, torch.device("cpu"), 2)
    protected = stripper.build_protected_blocks(model)
    names = [name for values in protected.values() for name in values]
    assert any("conv2" in name for name in names) and not any("conv1" in name for name in names)
    assert any("lin.weight" in name for name in names)
    for p in model.parameters():
        p.grad = torch.ones_like(p)
    probe = Batch.from_data_list(graphs())
    before = torch.get_rng_state().clone()
    update = {name: torch.randn_like(p) for name,p in model.named_parameters()}
    rng_after_update = torch.get_rng_state().clone()
    safe, metrics = stripper.strip(update, round_idx=0, probe_batch=(probe, probe.y))
    assert torch.equal(torch.get_rng_state(), rng_after_update)
    assert all(torch.equal(p.grad, torch.ones_like(p)) for p in model.parameters())
    assert metrics["probe_performed"] and metrics["max_rel_dist"] <= .100001
    assert all(torch.isfinite(p).all() for p in safe.values())


def test_graph_client_probe_is_local_and_rng_free():
    api = GraphCloverAPI.__new__(GraphCloverAPI)
    api.args = SimpleNamespace(seed=1)
    api.adaptive_privacy_config = AdaptivePrivacyStrippingConfig(enabled=True, probe_batch_size=4)
    api.adaptive_privacy_probe_batches = {}
    batch = Batch.from_data_list(graphs())
    client = SimpleNamespace(local_training_data=[batch])
    py, np_state, state = random.getstate(), np.random.get_state(), torch.get_rng_state()
    probe, labels = api._adaptive_privacy_probe_batch(0, client)
    assert probe.num_graphs == 4 and torch.equal(probe.y, labels)
    assert random.getstate() == py and np.array_equal(np.random.get_state()[1], np_state[1])
    assert torch.equal(torch.get_rng_state(), state)
    assert batch.num_graphs == 8


def test_goal_dropout_preserves_original_architecture_default_and_initialization():
    from experiments.adaptive_privacy.run_aids_goal import make_goal_model
    torch.manual_seed(79)
    rng = torch.get_rng_state()
    reference = GCNGraphClassifier(38,128,2,dropout=.5)
    after = torch.get_rng_state()
    batch = Batch.from_data_list(graphs())
    for config in ({},{'model_dropout':.5},{'model_dropout':.25},{'model_dropout':0}):
        torch.set_rng_state(rng)
        model = make_goal_model(config)
        assert torch.equal(after,torch.get_rng_state())
        assert sum(p.numel() for p in model.parameters()) == 21762
        assert type(model) is type(reference)
        assert all(torch.equal(p,reference.state_dict()[n]) for n,p in model.state_dict().items())
        model.eval()
        reference.eval()
        torch.testing.assert_close(model(batch),reference(batch),rtol=0.,atol=0.)
        if model.dropout == .5:
            model.train()
            reference.train()
            state = torch.get_rng_state()
            expected = reference(batch)
            torch.set_rng_state(state)
            torch.testing.assert_close(model(batch),expected,rtol=0.,atol=0.)
        elif model.dropout == 0.:
            model.train()
            state = torch.get_rng_state()
            expected = model(batch)
            assert torch.equal(state,torch.get_rng_state())
            torch.testing.assert_close(model(batch),expected,rtol=0.,atol=0.)
    for bad in (-.1,1.,float('nan'),float('inf'),True,'0.5'):
        state = torch.get_rng_state()
        try:
            make_goal_model({'model_dropout':bad})
        except ValueError:
            assert torch.equal(state,torch.get_rng_state())
        else:
            raise AssertionError('invalid dropout accepted')


if __name__ == "__main__":
    torch.set_num_threads(1)
    for name, function in list(globals().items()):
        if name.startswith("test_") and callable(function):
            function()
            print("PASS", name)
