import sys
from pathlib import Path

import torch


ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from Clover_api.Clover.Clover_api import CloverAPI


def test_finite_guard_accepts_finite_metrics_and_tensors():
    assert CloverAPI._require_finite_scalar(1.25, "loss") == 1.25
    CloverAPI._require_finite_tensors(
        {"weight": torch.tensor([1.0, -2.0]), "counter": torch.tensor([1])},
        "global model",
    )


def test_finite_guard_rejects_nonfinite_scalar_with_context():
    try:
        CloverAPI._require_finite_scalar(float("nan"), "round 2 client 7 train_loss")
    except FloatingPointError as exc:
        assert "round 2 client 7 train_loss" in str(exc)
    else:
        raise AssertionError("non-finite scalar was accepted")


def test_finite_guard_rejects_nonfinite_tensor_with_name_and_count():
    try:
        CloverAPI._require_finite_tensors(
            {"fc.weight": torch.tensor([1.0, float("inf"), float("nan")])},
            "round 2 aggregated update",
        )
    except FloatingPointError as exc:
        message = str(exc)
        assert "round 2 aggregated update" in message
        assert "fc.weight" in message
        assert "2 non-finite values" in message
    else:
        raise AssertionError("non-finite tensor was accepted")


if __name__ == "__main__":
    test_finite_guard_accepts_finite_metrics_and_tensors()
    test_finite_guard_rejects_nonfinite_scalar_with_context()
    test_finite_guard_rejects_nonfinite_tensor_with_name_and_count()
