import json
from pathlib import Path
import sys
import tempfile
from types import SimpleNamespace
from unittest.mock import patch

import numpy as np
import torch
from torch import nn

sys.path.insert(0,str(Path(__file__).resolve().parents[1]))


def test_image_teacher_preserves_model_gradients_rng_and_public_partition():
    from experiments.adaptive_privacy.vision_teacher import record_image_teachers
    torch.manual_seed(11)
    model = nn.Sequential(nn.Linear(4,8),nn.Dropout(.5),nn.Linear(8,3)).eval()
    for p in model.parameters():
        p.grad = torch.ones_like(p)
    data = [(torch.randn(24,4),torch.arange(24)%3)]
    state = {k:v.clone() for k,v in model.state_dict().items()}
    rng = torch.get_rng_state()
    args = SimpleNamespace(seed=11,model_class_num=3,batch_size=4,topk_k=2,epochs=1,lr=.01,momentum=.5)
    with tempfile.TemporaryDirectory() as tmp:
        record_image_teachers(model,data,args,0,tmp,torch.device("cpu"))
        record_image_teachers(model,data,args,0,tmp,torch.device("cpu"))
        manifest = json.loads((Path(tmp)/"source_public_manifest.json").read_text())
        train = {i for group,split in zip(manifest["groups"],manifest["splits"]) if split == "train" for i in group}
        val = {i for group,split in zip(manifest["groups"],manifest["splits"]) if split == "validation" for i in group}
        assert not train & val and len(train|val) == 24
    assert not model.training and torch.equal(rng,torch.get_rng_state())
    assert all(torch.equal(state[k],v) for k,v in model.state_dict().items())
    assert all(torch.equal(p.grad,torch.ones_like(p)) for p in model.parameters())


def test_multiclass_labelset_uses_two_means_and_ties_are_not_success():
    from experiments.adaptive_privacy.olive_source_attack import labelset_metrics
    hist = np.array([[2,2,0],[0,2,3],[4,0,0]])
    scores = np.array([[.9,.8,.1],[.1,.8,.9],[.9,.1,.2]])
    result = labelset_metrics(hist,scores)
    assert result["exact_labelset_unknown_count"] == 1.
    assert result["always_all_labels_exact_baseline"] == 0.
    assert labelset_metrics(hist,np.ones((3,3)))["exact_labelset_unknown_count"] == 0.


def test_mnist_cache_only_explicitly_forbids_download():
    from Clover_api.phase1.vision_data import _mnist
    with patch("Clover_api.phase1.vision_data.MNIST") as factory:
        _mnist(Path("unused"),download=False)
        assert factory.call_count == 2
        assert all(call.kwargs["download"] is False for call in factory.call_args_list)


def test_shared_goal_runtime_has_no_graph_import():
    from Clover_api.privacy.goal_runtime import GoalSupportMixin
    from experiments.adaptive_privacy.run_mnist_goal import GoalVisionAPI
    assert issubclass(GoalVisionAPI,GoalSupportMixin)
    assert "torch_geometric" not in Path(sys.modules[GoalSupportMixin.__module__].__file__).read_text()
