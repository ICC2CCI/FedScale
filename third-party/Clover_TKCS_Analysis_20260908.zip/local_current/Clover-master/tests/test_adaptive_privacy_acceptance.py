from __future__ import annotations

import csv
import hashlib
import json
import sys
import tempfile
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from experiments.adaptive_privacy.summarize_acceptance import main, validate_pair


def _write_csv(path: Path, rows):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def _write_run(root: Path, method: str, *, payload_bytes: int, best: float):
    run = (
        root
        / "gates"
        / "adaptive"
        / "mnist"
        / "lenet5"
        / "iid"
        / method
        / "rho_0.01"
        / "seed_1"
    )
    run.mkdir(parents=True)
    adaptive = method == "topk_aps"
    config = {
        "source_snapshot_sha256": "0" * 64,
        "dataset": "mnist",
        "model": "lenet5",
        "distribution": "iid",
        "method": "topk_adaptive" if adaptive else "topk_residual",
        "rho": 0.01,
        "seed": 1,
        "rounds": 2,
        "total_model_params": 100,
        "trainable_params": 100,
        "federated_update_dim": 100,
        "k": 1,
        "k_rule": "ceil(rho*d)",
        "residual": True,
        "residual_location": "client-local",
        "optimizer": "sgd",
        "learning_rate": 0.1,
        "lr_decay": 0.998,
        "momentum": 0.5,
        "weight_decay": 0.0005,
        "local_epochs": 1,
        "batch_size": 8,
        "clients_total": 4,
        "clients_per_round": 2,
        "aggregation_weighting": "local-sample-count",
        "update_transport_dtype": "float16",
        "partition": {"partition_sha256": "partition"},
        "secure_aggregation": False,
        "differential_privacy": False,
        "privacy_protection_mode": (
            "adaptive_privacy_stripping_non_cryptographic" if adaptive else "none"
        ),
        "adaptive_privacy_stripping": {
            "enabled": adaptive,
            "security_guarantee": "empirical_non_cryptographic",
            "changes_topk_payload_length": False,
        },
    }
    (run / "resolved_config.yaml").write_text(json.dumps(config), encoding="utf-8")
    summary = {
        "best_metric": best,
        "best_round": 2,
        "adaptive_privacy_metrics": {
            "mean_risk": 0.5,
            "mean_rho_final": 0.1,
            "min_cosine": 0.99,
            "max_rel_dist": 0.05,
            "mean_probe_time_ms": 2.0,
            "mean_strip_time_ms": 1.0,
        },
    }
    (run / "summary.json").write_text(json.dumps(summary), encoding="utf-8")
    _write_csv(
        run / "metrics.csv",
        [
            {"round": 1, "test_accuracy": best - 0.1, "best_accuracy": best - 0.1},
            {"round": 2, "test_accuracy": best, "best_accuracy": best},
        ],
    )
    _write_csv(
        run / "communication.csv",
        [
            {"round": 1, "actual_payload_bytes": payload_bytes, "total_round_bytes": payload_bytes * 2},
            {"round": 2, "actual_payload_bytes": payload_bytes, "total_round_bytes": payload_bytes * 2},
        ],
    )
    if adaptive:
        _write_csv(
            run / "adaptive_privacy_metrics.csv",
            [
                {"round": round_number, "client_id": client_id, "probe_performed": "True"}
                for round_number in (1, 2)
                for client_id in (0, 1)
            ],
        )
    checkpoint_dir = run / "checkpoint"
    checkpoint_dir.mkdir()
    for name, meta_name in (("latest.pt", "latest_meta.json"), ("best.pt", "best_meta.json")):
        path = checkpoint_dir / name
        path.write_bytes((method + name).encode("ascii"))
        digest = hashlib.sha256(path.read_bytes()).hexdigest()
        (checkpoint_dir / meta_name).write_text(
            json.dumps({"checkpoint_sha256": digest}),
            encoding="utf-8",
        )
    (run / "DONE").write_text("done\n", encoding="utf-8")
    return run


def test_acceptance_summary_passes_matched_pair():
    with tempfile.TemporaryDirectory() as tmp:
        root = Path(tmp) / "runs"
        _write_run(root, "topk_residual", payload_bytes=10, best=0.90)
        _write_run(root, "topk_aps", payload_bytes=10, best=0.87)
        out = Path(tmp) / "summary"
        rc = main(
            [
                "--root", str(root),
                "--out", str(out),
                "--datasets", "mnist",
                "--rounds", "2",
            ]
        )
        assert rc == 0
        assert (out / "GATE_STATUS").read_text(encoding="utf-8").strip() == "PASS"
        payload = json.loads((out / "comparison.json").read_text(encoding="utf-8"))
        assert payload["results"][0]["degradation_pp"] < 5.0


def test_acceptance_rejects_payload_mismatch():
    with tempfile.TemporaryDirectory() as tmp:
        root = Path(tmp) / "runs"
        _write_run(root, "topk_residual", payload_bytes=10, best=0.90)
        _write_run(root, "topk_aps", payload_bytes=11, best=0.87)
        try:
            validate_pair(root, "mnist", "iid", 1, 2, 5.0)
        except RuntimeError as exc:
            assert "payload" in str(exc)
        else:
            raise AssertionError("payload mismatch was accepted")


if __name__ == "__main__":
    test_acceptance_summary_passes_matched_pair()
    test_acceptance_rejects_payload_mismatch()
    print("adaptive privacy acceptance tests passed")
