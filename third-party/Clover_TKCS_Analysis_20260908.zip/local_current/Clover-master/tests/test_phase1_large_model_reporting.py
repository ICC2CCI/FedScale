import json
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from Clover_api.phase1.large_model_reporting import Phase1LargeModelRecorder


def _config(rounds):
    return {
        "schema": "fixture-v1",
        "dataset": "cola",
        "model": "roberta-large-lora",
        "distribution": "native_iid_like",
        "method": "dense",
        "rho": 1.0,
        "seed": 1,
        "rounds": rounds,
        "federated_update_dim": 8,
        "k": 8,
    }


def test_large_model_recorder_writes_partial_block_and_extends_resume_target():
    with tempfile.TemporaryDirectory() as tmp:
        run_dir = Path(tmp) / "run"
        recorder = Phase1LargeModelRecorder(
            run_dir=run_dir,
            resolved_config=_config(2),
            trainable_manifest=["a\tshape=4\tnumel=4", "b\tshape=4\tnumel=4"],
            resume=False,
        )
        recorder.record_round(
            round_number=1,
            metrics={"train_loss": 1.0, "eval_loss": 0.8, "primary_metric": 0.2},
            timing={"train_compute_sec": 1.0, "evaluation_sec": 0.2, "round_wall_sec": 1.4},
            communication={
                "active_client_count": 2,
                "dense_payload_bytes": 16,
                "topk_index_bytes": 8,
                "topk_value_bytes": 2,
                "topk_total_bytes": 10,
                "actual_payload_bytes": 16,
                "total_round_bytes": 32,
                "compression_ratio_vs_dense": 1.0,
                "compression_ratio_vs_plain_topk": 1.6,
                "index_dtype": "none",
                "value_dtype": "float16",
            },
            support={
                "federated_update_dim": 8,
                "k": 8,
                "k_over_d": 1.0,
                "mean_client_support_size": 8,
                "min_client_support_size": 8,
                "max_client_support_size": 8,
                "union_support_size": 8,
                "union_support_density": 1.0,
            },
            sketch=None,
            recovery=None,
        )
        summary = recorder.write_summary(peak_memory_bytes=123)
        assert summary["rounds_completed"] == 1
        assert summary["best_metric"] == 0.2
        assert (run_dir / "time_10rounds.csv").read_text(encoding="utf-8").count("\n") == 2

        Phase1LargeModelRecorder(
            run_dir=run_dir,
            resolved_config=_config(3),
            trainable_manifest=["a\tshape=4\tnumel=4", "b\tshape=4\tnumel=4"],
            resume=True,
        )
        assert json.loads((run_dir / "resolved_config.yaml").read_text(encoding="utf-8"))["rounds"] == 3


if __name__ == "__main__":
    test_large_model_recorder_writes_partial_block_and_extends_resume_target()
