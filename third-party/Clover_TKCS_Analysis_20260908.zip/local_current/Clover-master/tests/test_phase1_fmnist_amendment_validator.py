import csv
import hashlib
import json
import sys
from pathlib import Path
from tempfile import TemporaryDirectory


ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from experiments.phase1 import validate_fmnist_amendment as validator


def _json(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value), encoding="utf-8")


def _csv(path, fieldnames, rows):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)


def _manifest(root):
    value = {
        "schema": "tkcs-phase1-amendment-v1",
        "profile": "fmnist-dirichlet-beta1-lr005",
        "source_snapshot_sha256": validator.SOURCE_SHA256,
        "dataset": "fmnist",
        "model": "lenet5",
        "distribution": "dirichlet_beta1",
        "seed": 1,
        "methods": ["dense", "topk", "tkcs"],
        "rounds": 160,
        "clients": 100,
        "clients_per_round": 10,
        "local_epochs": 5,
        "learning_rate": 0.05,
        "lr_decay": 0.998,
        "momentum": 0.5,
        "weight_decay": 0.0005,
        "update_transport_dtype": "float16",
        "rho": 0.01,
        "tkcs_rows": 5,
        "tkcs_budget_ratio_vs_topk16": 1.0,
        "secure_aggregation": False,
        "differential_privacy": False,
    }
    _json(root / "AMENDMENT_MANIFEST.json", value)
    return value


def _run(root, method):
    spec = validator.METHODS[method]
    run = validator.run_directory(root, method)
    run.mkdir(parents=True)
    config = {
        "dataset": "fmnist",
        "model": "lenet5",
        "distribution": "dirichlet_beta1",
        "seed": 1,
        "rounds": 160,
        "clients_total": 100,
        "clients_per_round": 10,
        "local_epochs": 5,
        "batch_size": 50,
        "learning_rate": 0.05,
        "lr_decay": 0.998,
        "momentum": 0.5,
        "weight_decay": 0.0005,
        "optimizer": "sgd",
        "update_transport_dtype": "float16",
        "source_snapshot_sha256": validator.SOURCE_SHA256,
        "secure_aggregation": False,
        "differential_privacy": False,
        "federated_update_dim": 431080,
        "method": spec["config_method"],
        "rho": spec["rho"],
        "k": spec["k"],
        "partition": {"partition_sha256": validator.PARTITION_SHA256, "seed": 1},
        "residual": method == "tkcs",
        "residual_location": "client-local" if method == "tkcs" else "none",
    }
    if method == "tkcs":
        config.update(
            {
                "sketch_rows": 5,
                "sketch_layout_mode": "fixed_public",
                "sketch_budget_ratio": 1.0,
                "sketch_budget_ref": "topk16",
                "sketch_recover_k_mode": "active_union",
                "sketch_allocation_strategy": "topk_count_calibrated",
                "sketch_recovery_score": "plain_median",
                "sketch_transport_dtype": "float16",
            }
        )
    _json(run / "resolved_config.yaml", config)
    metric_rows = [
        {
            "round": index,
            "train_loss": 1 / index,
            "test_loss": 1 / index,
            "test_accuracy": index / 1000,
            "best_accuracy": index / 1000,
        }
        for index in range(1, 161)
    ]
    _csv(run / "metrics.csv", metric_rows[0].keys(), metric_rows)
    payload = {"dense": 862160, "topk": 43110, "tkcs": 43338}[method]
    communication_rows = []
    for index in range(1, 161):
        communication_rows.append(
            {
                "round": index,
                "actual_payload_bytes": payload,
                "dense_payload_bytes": 862160,
                "topk_total_bytes": 43110,
                "tkcs_total_bytes": 43338,
            }
        )
    _csv(run / "communication.csv", communication_rows[0].keys(), communication_rows)
    summary = dict(config)
    summary.update(
        {
            "rounds_completed": 160,
            "best_metric": 0.16,
            "final_metric": 0.16,
            "mean_payload_bytes_per_client_round": payload,
            "mean_union_support_density": None,
            "mean_collision_rate": None,
            "mean_recall_at_k": None,
            "mean_nmse": None,
            "total_wall_sec": 1.0,
        }
    )
    _json(run / "summary.json", summary)
    checkpoint = run / "checkpoint" / "latest.pt"
    checkpoint.parent.mkdir(parents=True)
    checkpoint.write_bytes(method.encode("ascii"))
    meta = {
        "round": 160,
        "next_round": 161,
        "partition_sha256": validator.PARTITION_SHA256,
        "checkpoint_sha256": hashlib.sha256(method.encode("ascii")).hexdigest(),
    }
    if method == "tkcs":
        meta.update({"residual_kind": "tkcs", "residual_client_count": 100})
    _json(run / "checkpoint" / "latest_meta.json", meta)
    for name in (
        "round_timing.csv",
        "time_10rounds.csv",
        "support_stats.csv",
        "trainable_parameter_manifest.txt",
        "stdout.log",
        "DONE",
    ):
        (run / name).write_text("fixture\n", encoding="utf-8")
    if method == "tkcs":
        for name in ("sketch_stats.csv", "recovery_stats.csv", "per_layer_collision_stats.csv"):
            (run / name).write_text("fixture\n", encoding="utf-8")


def test_complete_amendment_is_validated_and_reported():
    with TemporaryDirectory() as directory:
        root = Path(directory)
        manifest = _manifest(root)
        for method in validator.METHODS:
            _run(root, method)
        results = [validator.validate_run(root, manifest, method) for method in validator.METHODS]
        output = root / "report"
        validator.write_outputs(output, manifest, results)
        report = json.loads((output / "amendment_validation.json").read_text(encoding="utf-8"))
        assert report["status"] == "PASS"
        assert len(report["runs"]) == 3
        assert (output / "accuracy_curves.csv").is_file()


def test_partition_mismatch_is_rejected():
    with TemporaryDirectory() as directory:
        root = Path(directory)
        manifest = _manifest(root)
        _run(root, "dense")
        config_path = validator.run_directory(root, "dense") / "resolved_config.yaml"
        config = json.loads(config_path.read_text(encoding="utf-8"))
        config["partition"]["partition_sha256"] = "0" * 64
        _json(config_path, config)
        try:
            validator.validate_run(root, manifest, "dense")
        except validator.ValidationError as exc:
            assert "partition mismatch" in str(exc)
        else:
            raise AssertionError("partition mismatch was accepted")


if __name__ == "__main__":
    test_complete_amendment_is_validated_and_reported()
    test_partition_mismatch_is_rejected()
