import importlib.util
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
MODULE_PATH = ROOT / "experiments" / "phase1" / "build_summary.py"
SPEC = importlib.util.spec_from_file_location("phase1_build_summary", MODULE_PATH)
MODULE = importlib.util.module_from_spec(SPEC)
assert SPEC.loader is not None
sys.modules[SPEC.name] = MODULE
SPEC.loader.exec_module(MODULE)


def test_frozen_summary_manifest_has_39_unique_formal_paths():
    runs = MODULE.expected_runs()
    assert len(runs) == 39
    assert len({run.relative_dir.as_posix() for run in runs}) == 39
    assert all("gates" not in run.relative_dir.parts for run in runs)
    counts = {}
    for run in runs:
        counts[run.model] = counts.get(run.model, 0) + 1
    assert counts == {
        "lenet5": 12,
        "resnet18": 12,
        "tiny_resnet18": 6,
        "roberta_large_lora": 6,
        "phi4_mini_dora": 3,
    }


def test_table_pivot_never_fills_missing_methods_with_zero():
    rows = [
        {
            "dataset": "cola",
            "model": "roberta_large_lora",
            "distribution": "native_iid_like",
            "method": "dense",
            "best_metric": 0.5,
        }
    ]
    table = MODULE.pivot(rows, "best_metric")
    assert table[0]["Dense"] == 0.5
    assert table[0]["Top-k 1%"] == "NA"
    assert table[0]["TKCS 1%"] == "NA"


if __name__ == "__main__":
    test_frozen_summary_manifest_has_39_unique_formal_paths()
    test_table_pivot_never_fills_missing_methods_with_zero()
