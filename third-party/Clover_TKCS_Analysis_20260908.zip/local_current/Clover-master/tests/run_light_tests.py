from __future__ import annotations

import json
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from Clover_api.SketchOPA.fixed_layout import build_fixed_public_layout, estimate_topk16_payload_bytes
from Clover_api.SketchOPA.model_flatten import LayerSpec
from scripts.collect_clover_sketchopa_results import main as collect_main


def test_fixed_layout_payload():
    specs = [
        LayerSpec("a.weight", 0, 1000, (1000,)),
        LayerSpec("b.weight", 1000, 3000, (2000,)),
        LayerSpec("c.weight", 3000, 4310, (1310,)),
    ]
    layout = build_fixed_public_layout(specs, 431, 5, 1.0, "float16", "uniform_param", 1)
    assert layout.budget.target_payload_bytes == estimate_topk16_payload_bytes(431)
    assert layout.payload_bytes <= layout.budget.target_payload_bytes
    assert layout.payload_bytes == layout.budget.effective_payload_bytes


def test_residual_does_not_change_payload():
    specs = [
        LayerSpec("conv.weight", 0, 2048, (2048,)),
        LayerSpec("fc.weight", 2048, 4096, (2048,)),
    ]
    lhs = build_fixed_public_layout(specs, 40, 5, 1.0, "float16", "uniform_param", 1)
    rhs = build_fixed_public_layout(specs, 40, 5, 1.0, "float16", "uniform_param", 1)
    assert lhs.payload_bytes == rhs.payload_bytes
    assert lhs.layout_hash == rhs.layout_hash


def test_collector_root_argument():
    with tempfile.TemporaryDirectory() as tmp:
        root = Path(tmp) / "runs"
        run = root / "exp1"
        run.mkdir(parents=True)
        (run / "final_summary.json").write_text(
            json.dumps(
                {
                    "dataset": "mnist",
                    "model": "lenet5",
                    "mode": "sketchopa_plain_cs_residual",
                    "rounds": 20,
                    "final_acc": 0.98,
                    "sketch_layout_mode": "fixed_public",
                    "sketch_budget_ratio": 1.0,
                    "sketch_allocation_strategy": "uniform_param",
                }
            ),
            encoding="utf-8",
        )
        (run / "round_metrics.csv").write_text(
            "round,dataset,model,mode,test_acc\n19,mnist,lenet5,sketchopa_plain_cs_residual,0.98\n",
            encoding="utf-8",
        )
        (run / "comm_metrics.csv").write_text(
            "round,dataset,model,method,payload_bytes,payload_over_topk16,payload_over_dense16\n"
            "19,mnist,lenet5,sketchopa_plain_cs_residual,43100,1.0,0.05\n",
            encoding="utf-8",
        )
        (run / "sketch_recovery_metrics.csv").write_text(
            "round,dataset,model,method,sketch_rows,sketch_layout_mode,sketch_budget_ratio,sketch_allocation_strategy,"
            "residual_enabled,payload_bytes,payload_over_topk16,payload_over_dense16,recovery_cosine,recovery_l2_rel\n"
            "19,mnist,lenet5,sketchopa_plain_cs_residual,5,fixed_public,1.0,uniform_param,True,43100,1.0,0.05,0.9,0.1\n",
            encoding="utf-8",
        )
        (run / "per_layer_recovery_metrics.csv").write_text(
            "round,dataset,model,method,layer_name,layer_recovery_cosine\n"
            "19,mnist,lenet5,sketchopa_plain_cs_residual,fc,0.9\n",
            encoding="utf-8",
        )
        (run / "layout.json").write_text("{}", encoding="utf-8")
        out = Path(tmp) / "summary"
        collect_main(["--root", str(root), "--out", str(out)])
        assert (out / "summary_all.csv").exists()
        assert (out / "final_report.md").exists()
        assert (out / "recommended_configs.json").exists()


if __name__ == "__main__":
    test_fixed_layout_payload()
    test_residual_does_not_change_payload()
    test_collector_root_argument()
    print("light tests passed")
