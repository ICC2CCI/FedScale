from __future__ import annotations

import random
import sys
from pathlib import Path
from types import SimpleNamespace

import numpy as np
import torch
from torch import nn
from torch.utils.data import DataLoader, Dataset


ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from Clover_api.Clover.Clover_api import CloverAPI
from Clover_api.privacy.adaptive_privacy_stripping import (
    AdaptivePrivacyStripper,
    AdaptivePrivacyStrippingConfig,
    deterministic_probe_batch,
)


class _ToyClassifier(nn.Module):
    def __init__(self, input_dim: int = 2, classes: int = 2, bias: bool = True):
        super().__init__()
        self.head = nn.Linear(input_dim, classes, bias=bias)

    def forward(self, value):
        return self.head(value)


class _RandomDataset(Dataset):
    def __len__(self):
        return 8

    def __getitem__(self, index):
        value = torch.tensor(
            [float(index), random.random(), float(np.random.random()), float(torch.rand(()))]
        )
        return value, index % 2


def _config(**overrides):
    values = {
        "enabled": True,
        "protected_scope": "head",
        "probe_interval": 100,
        "state_dtype": "float32",
        "rho_max": 0.5,
        "lambda_utility": 0.0,
        "tau_cos": 0.0,
        "tau_dist": 1.0,
    }
    values.update(overrides)
    return AdaptivePrivacyStrippingConfig(**values).validated()


def _manual_state(stripper, directions, risk=1.0, round_idx=0):
    payload = {
        "schema": stripper.STATE_SCHEMA,
        "protected_blocks": stripper.protected_blocks,
        "state_dtype": stripper.config.state_dtype,
        "blocks": {},
    }
    for block_name, spec_directions in directions.items():
        payload["blocks"][block_name] = {
            "direction_ema": [value.clone() for value in spec_directions],
            "risk_ema": float(risk),
            "last_probe_round": int(round_idx),
        }
    stripper.load_state_dict(payload)


def test_disabled_path_is_identity_and_never_probes():
    model = _ToyClassifier()
    config = AdaptivePrivacyStrippingConfig(enabled=False, protected_scope="head")
    stripper = AdaptivePrivacyStripper(model, config, "cpu", 2)
    update = {"head.weight": torch.tensor([[2.0, 1.0], [0.0, 1.0]])}
    safe, metrics = stripper.strip(update, round_idx=0)
    assert torch.equal(safe["head.weight"], update["head.weight"])
    assert safe["head.weight"] is update["head.weight"]
    assert not metrics["probe_performed"]
    assert not stripper.should_probe(0)


def test_softmax_counterfactual_direction_matches_pi_minus_one_hot():
    model = _ToyClassifier(classes=3)
    stripper = AdaptivePrivacyStripper(model, _config(), "cpu", 3)
    x = torch.tensor([[0.2, -0.1], [1.0, 0.5]])
    y = torch.tensor([0, 2])
    directions, _ = stripper.estimate_sensitive_direction(model, (x, y))
    observed = torch.stack(
        [directions[f"classifier:head.bias:class_{index}"][0] for index in range(3)]
    ).reshape(-1)
    expected = torch.tensor([-1.0 / 6.0, 1.0 / 3.0, -1.0 / 6.0])
    assert torch.allclose(observed, expected, atol=1.0e-6)


def test_rho_is_monotone_in_risk_and_utility():
    rho = AdaptivePrivacyStripper.adaptive_rho
    low_risk = rho(0.2, 0.5, rho_max=0.5, lambda_utility=1.0, eps=1.0e-12)
    high_risk = rho(0.8, 0.5, rho_max=0.5, lambda_utility=1.0, eps=1.0e-12)
    high_utility = rho(0.8, 0.9, rho_max=0.5, lambda_utility=1.0, eps=1.0e-12)
    assert high_risk >= low_risk
    assert high_utility <= high_risk
    assert rho(0.0, 0.5, rho_max=0.5, lambda_utility=1.0, eps=1.0e-12) == 0.0


def test_projection_removes_only_aligned_component():
    model = _ToyClassifier(classes=2, bias=False)
    stripper = AdaptivePrivacyStripper(model, _config(), "cpu", 2)
    _manual_state(
        stripper,
        {
            "classifier:head.weight:class_0": (torch.tensor([1.0, 0.0]),),
            "classifier:head.weight:class_1": (torch.tensor([0.0, 0.0]),),
        },
    )
    update = {"head.weight": torch.tensor([[2.0, 1.0], [0.0, 0.0]])}
    safe, metrics = stripper.strip(update, round_idx=1)
    assert torch.allclose(safe["head.weight"][0], torch.tensor([1.0, 1.0]))
    assert torch.equal(safe["head.weight"][1], update["head.weight"][1])
    assert abs(metrics["max_rho_final"] - 0.5) < 1.0e-6
    assert torch.equal(update["head.weight"], torch.tensor([[2.0, 1.0], [0.0, 0.0]]))


def test_orthogonal_direction_leaves_update_unchanged():
    model = _ToyClassifier(classes=2, bias=False)
    stripper = AdaptivePrivacyStripper(model, _config(), "cpu", 2)
    _manual_state(
        stripper,
        {
            "classifier:head.weight:class_0": (torch.tensor([1.0, 0.0]),),
            "classifier:head.weight:class_1": (torch.tensor([0.0, 0.0]),),
        },
    )
    update = {"head.weight": torch.tensor([[0.0, 1.0], [0.0, 0.0]])}
    safe, metrics = stripper.strip(update, round_idx=1)
    assert torch.allclose(safe["head.weight"], update["head.weight"])
    assert metrics["stripped_energy_ratio"] == 0.0


def test_utility_gate_reduces_rho_until_constraints_pass():
    model = _ToyClassifier(classes=2, bias=False)
    stripper = AdaptivePrivacyStripper(
        model,
        _config(rho_max=1.0, tau_cos=0.98, tau_dist=0.10, bisection_steps=18),
        "cpu",
        2,
    )
    _manual_state(
        stripper,
        {
            "classifier:head.weight:class_0": (torch.tensor([1.0, 0.0]),),
            "classifier:head.weight:class_1": (torch.tensor([0.0, 0.0]),),
        },
    )
    update = {"head.weight": torch.tensor([[2.0, 0.0], [0.0, 0.0]])}
    _, metrics = stripper.strip(update, round_idx=1)
    assert metrics["max_rho_final"] < metrics["mean_rho_raw"]
    assert metrics["min_cosine"] >= 0.98 - 1.0e-6
    assert metrics["max_rel_dist"] <= 0.10 + 1.0e-6


def test_probe_does_not_contaminate_existing_optimizer_gradients():
    model = _ToyClassifier(classes=3)
    model.train()
    for parameter in model.parameters():
        parameter.grad = torch.randn_like(parameter)
    before = [parameter.grad.clone() for parameter in model.parameters()]
    stripper = AdaptivePrivacyStripper(model, _config(), "cpu", 3)
    stripper.estimate_sensitive_direction(
        model,
        (torch.randn(4, 2), torch.tensor([0, 1, 2, 1])),
    )
    assert model.training
    for expected, parameter in zip(before, model.parameters()):
        assert torch.equal(expected, parameter.grad)


def test_ema_initializes_directly_updates_and_non_probe_strip_is_read_only():
    model = _ToyClassifier(classes=2, bias=False)
    stripper = AdaptivePrivacyStripper(
        model,
        _config(ema_beta_direction=0.5, ema_beta_risk=0.5),
        "cpu",
        2,
    )
    first = {
        "classifier:head.weight:class_0": (torch.tensor([1.0, 0.0]),),
        "classifier:head.weight:class_1": (torch.tensor([0.0, 1.0]),),
    }
    second = {
        "classifier:head.weight:class_0": (torch.tensor([3.0, 0.0]),),
        "classifier:head.weight:class_1": (torch.tensor([0.0, 3.0]),),
    }
    stripper.update_ema_state(first, {name: 0.2 for name in first}, round_idx=0)
    state = stripper.state_dict()
    assert torch.equal(
        state["blocks"]["classifier:head.weight:class_0"]["direction_ema"][0],
        torch.tensor([1.0, 0.0]),
    )
    stripper.update_ema_state(second, {name: 0.6 for name in second}, round_idx=1)
    state = stripper.state_dict()
    assert torch.equal(
        state["blocks"]["classifier:head.weight:class_0"]["direction_ema"][0],
        torch.tensor([2.0, 0.0]),
    )
    assert abs(state["blocks"]["classifier:head.weight:class_0"]["risk_ema"] - 0.4) < 1.0e-8
    before = stripper.state_dict()
    stripper.strip({"head.weight": torch.ones(2, 2)}, round_idx=2)
    after = stripper.state_dict()
    assert before["blocks"]["classifier:head.weight:class_0"]["last_probe_round"] == 1
    assert after["blocks"]["classifier:head.weight:class_0"]["last_probe_round"] == 1


def test_state_serialization_round_trip():
    model = _ToyClassifier(classes=2, bias=False)
    source = AdaptivePrivacyStripper(model, _config(), "cpu", 2)
    directions = {
        "classifier:head.weight:class_0": (torch.tensor([1.0, 2.0]),),
        "classifier:head.weight:class_1": (torch.tensor([3.0, 4.0]),),
    }
    source.update_ema_state(directions, {name: 0.7 for name in directions}, round_idx=9)
    restored = AdaptivePrivacyStripper(model, _config(), "cpu", 2)
    restored.load_state_dict(source.state_dict())
    lhs = source.state_dict()["blocks"]
    rhs = restored.state_dict()["blocks"]
    assert lhs.keys() == rhs.keys()
    for name in lhs:
        assert lhs[name]["risk_ema"] == rhs[name]["risk_ema"]
        assert lhs[name]["last_probe_round"] == rhs[name]["last_probe_round"]
        assert torch.equal(lhs[name]["direction_ema"][0], rhs[name]["direction_ema"][0])


def test_deterministic_probe_preserves_all_training_rng_states():
    loader = DataLoader(_RandomDataset(), batch_size=2, shuffle=True)
    random.seed(123)
    np.random.seed(123)
    torch.manual_seed(123)
    python_before = random.getstate()
    numpy_before = np.random.get_state()
    torch_before = torch.get_rng_state().clone()
    first = deterministic_probe_batch(loader, 4, 77)
    assert random.getstate() == python_before
    numpy_after = np.random.get_state()
    assert numpy_after[0] == numpy_before[0]
    assert np.array_equal(numpy_after[1], numpy_before[1])
    assert numpy_after[2:] == numpy_before[2:]
    assert torch.equal(torch.get_rng_state(), torch_before)
    second = deterministic_probe_batch(loader, 4, 77)
    assert torch.equal(first[0], second[0])
    assert torch.equal(first[1], second[1])


def test_error_feedback_uses_stripped_update_not_raw_update():
    class _FakeStripper:
        @staticmethod
        def should_probe(round_idx):
            return False

        @staticmethod
        def strip(update, round_idx, probe_batch=None):
            return {"w": torch.tensor([0.5, 1.0])}, {
                "aps_enabled": True,
                "probe_performed": False,
                "probe_time_ms": 0.0,
                "strip_time_ms": 0.0,
                "num_protected_blocks": 1,
                "mean_risk": 1.0,
                "max_risk": 1.0,
                "mean_rho_raw": 0.5,
                "mean_rho_final": 0.5,
                "max_rho_final": 0.5,
                "mean_cosine": 1.0,
                "min_cosine": 1.0,
                "mean_rel_dist": 0.0,
                "max_rel_dist": 0.0,
                "stripped_energy_ratio": 0.0,
            }

    api = object.__new__(CloverAPI)
    api.use_residual_topk = True
    api.adaptive_privacy_enabled = True
    api.topk_residuals = {7: {"w": torch.zeros(2)}}
    api.device = torch.device("cpu")
    api.buffer_names = []
    api.num_of_sparse_params = 1
    api.args = SimpleNamespace(phase1=False)
    api._adaptive_privacy_current_metrics = []
    api.phase1_dirty_adaptive_privacy_clients = set()
    api.phase1_dirty_residual_clients = set()
    api._adaptive_privacy_stripper_for_client = lambda client_id: _FakeStripper()
    sparse = api._topk_update_for_client(
        {"w": torch.tensor([2.0, 1.0])},
        7,
        round_idx=1,
        client=object(),
    )
    assert torch.equal(sparse["w"], torch.tensor([0.0, 1.0]))
    assert torch.equal(api.topk_residuals[7]["w"], torch.tensor([0.5, 0.0]))
    assert 7 in api.phase1_dirty_residual_clients


if __name__ == "__main__":
    test_disabled_path_is_identity_and_never_probes()
    test_softmax_counterfactual_direction_matches_pi_minus_one_hot()
    test_rho_is_monotone_in_risk_and_utility()
    test_projection_removes_only_aligned_component()
    test_orthogonal_direction_leaves_update_unchanged()
    test_utility_gate_reduces_rho_until_constraints_pass()
    test_probe_does_not_contaminate_existing_optimizer_gradients()
    test_ema_initializes_directly_updates_and_non_probe_strip_is_read_only()
    test_state_serialization_round_trip()
    test_deterministic_probe_preserves_all_training_rng_states()
    test_error_feedback_uses_stripped_update_not_raw_update()
    print("adaptive privacy stripping tests passed")
