import copy
from pathlib import Path
import sys

import torch
from torch import nn

sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from Clover_api.privacy.adaptive_privacy_stripping import AdaptivePrivacyStrippingConfig
from Clover_api.privacy.contrast_subspace import ContrastSubspaceStripper,subspace_projection


def setup():
    model = nn.Sequential(nn.Linear(4,3))
    config = AdaptivePrivacyStrippingConfig(enabled=True,protected_scope='head',state_dtype='float32',
        probe_interval=5,ema_beta_direction=.5,rho_max=.5,lambda_utility=0.,tau_cos=0.,tau_dist=1.)
    return model,ContrastSubspaceStripper(model,config,'cpu',3)


def test_subspace_projection_is_orthogonal_rank_aware_and_nonmutating():
    q = torch.tensor([2.,3.,4.])
    rows = torch.tensor([[1.,0.,0.],[2.,0.,0.],[0.,1.,0.]])
    before = rows.clone()
    projection,rank = subspace_projection(q,rows)
    assert rank == 2
    torch.testing.assert_close(projection,torch.tensor([2.,3.,0.]))
    torch.testing.assert_close(rows@(q-projection),torch.zeros(3))
    assert torch.equal(rows,before)
    empty,rank = subspace_projection(q,torch.zeros_like(rows))
    assert rank == 0 and not empty.any()
    rescaled,_ = subspace_projection(q,rows*torch.tensor([[.001],[100.],[2.]]))
    torch.testing.assert_close(projection,rescaled)


def test_subspace_eigensolver_fallback_preserves_matrix_rank_projection_and_rng():
    import warnings
    from unittest.mock import patch
    q = torch.tensor([2.,3.,4.,5.])
    rows = torch.tensor([[1.,0.,0.,0.],[2.,0.,0.,0.],[0.,1.,0.,0.],[0.,0.,0.,0.]])
    expected,rank = subspace_projection(q,rows)
    original = torch.linalg.eigh
    captured = []
    def injected(matrix):
        captured.append(matrix.clone())
        if len(captured) == 1:
            raise torch.linalg.LinAlgError('injected convergence failure')
        assert matrix.device.type == 'cpu' and matrix.dtype == torch.float64
        assert torch.equal(matrix,captured[0].cpu())
        return original(matrix)
    rng = torch.get_rng_state()
    before = rows.clone()
    with patch('torch.linalg.eigh',side_effect=injected),warnings.catch_warnings(record=True) as notes:
        warnings.simplefilter('always')
        actual,observed_rank = subspace_projection(q,rows)
    assert len(captured) == 2 and len(notes) == 1
    assert observed_rank == rank == 2 and torch.equal(actual,expected)
    assert torch.equal(rows,before) and torch.equal(rng,torch.get_rng_state())


def test_subspace_eigensolver_does_not_swallow_other_errors_or_repeated_failure():
    import warnings
    from unittest.mock import patch
    q,rows = torch.ones(3),torch.eye(3)
    for error,calls in ((RuntimeError('unrelated error'),1),(torch.linalg.LinAlgError('solver failure'),2)):
        with patch('torch.linalg.eigh',side_effect=error) as mocked,warnings.catch_warnings():
            warnings.simplefilter('ignore')
            try:
                subspace_projection(q,rows)
            except type(error) as actual:
                assert str(actual) == str(error)
            else:
                raise AssertionError('solver failure was silently ignored')
            assert mocked.call_count == calls


def test_contrast_probe_keeps_model_modes_gradients_rng_and_all_label_directions():
    torch.manual_seed(11)
    model,stripper = setup()
    model.train()
    model[0].eval()
    x,y = torch.randn(7,4),torch.tensor([0,0,1,1,1,2,2])
    for parameter in model.parameters():
        parameter.grad = torch.ones_like(parameter)
    before = copy.deepcopy(model.state_dict())
    rng = torch.get_rng_state()
    directions,risks = stripper.estimate_sensitive_direction(model,(x,y))
    assert model.training and not model[0].training
    assert torch.equal(rng,torch.get_rng_state())
    assert all(torch.equal(before[n],p) for n,p in model.state_dict().items())
    assert all(torch.equal(p.grad,torch.ones_like(p)) for p in model.parameters())
    for name,spec in stripper._block_specs.items():
        assert directions[name][0].shape[0] == 3
        assert 0 <= risks[name] <= 1
        for label in range(2):
            row = spec.parts[0].row_index
            sign = float(row == 2)-float(row == label)
            expected = sign*x.mean(0) if spec.parts[0].parameter_name.endswith('weight') else torch.tensor(sign)
            torch.testing.assert_close(directions[name][0][label+1],expected)


def test_contrast_state_resume_nonprobe_and_gate_preserve_inputs():
    torch.manual_seed(37)
    model,stripper = setup()
    update = {n:torch.randn_like(p) for n,p in model.named_parameters()}
    before = copy.deepcopy(update)
    probe = (torch.randn(8,4),torch.arange(8)%3)
    safe,metrics = stripper.strip(update,0,probe)
    assert metrics['probe_performed'] and metrics['max_projection_rank'] >= 1
    assert metrics['max_rel_dist'] <= .5+1e-5
    assert all(torch.equal(update[n],p) for n,p in before.items())
    state = copy.deepcopy(stripper.state_dict())
    clone = ContrastSubspaceStripper(model,stripper.config,'cpu',3)
    clone.load_state_dict(state)
    expected,m1 = stripper.strip(update,1)
    actual,m2 = clone.strip(update,1)
    assert not m1['probe_performed'] and not m2['probe_performed']
    assert all(torch.equal(expected[n],actual[n]) for n in expected)
    assert all(torch.equal(state['blocks'][n]['direction_ema'][0],clone.state_dict()['blocks'][n]['direction_ema'][0]) for n in state['blocks'])
    bad = copy.deepcopy(state)
    first = next(iter(bad['blocks'].values()))
    first['direction_ema'][0] = first['direction_ema'][0][:-1]
    try:
        clone.load_state_dict(bad)
    except ValueError:
        pass
    else:
        raise AssertionError('truncated contrast family accepted')


def test_contrast_disabled_never_probes_or_changes_update():
    model,stripper = setup()
    stripper.config.enabled = False
    update = {n:torch.randn_like(p) for n,p in model.named_parameters()}
    safe,metrics = stripper.strip(update,0)
    assert not metrics['probe_performed'] and not stripper.has_state
    assert all(safe[n] is update[n] for n in update)


def test_all_scope_covers_root_nested_and_early_parameters_exactly_once():
    class Model(nn.Module):
        def __init__(self):
            super().__init__()
            self.offset = nn.Parameter(torch.ones(4))
            self.early = nn.Sequential(nn.Linear(4,5),nn.ReLU())
            self.middle = nn.Linear(5,5)
            self.late = nn.Linear(5,4)
            self.head = nn.Linear(4,3)
            self.frozen = nn.Parameter(torch.ones(4),requires_grad=False)
        def forward(self,x):
            return self.head(self.late(self.middle(self.early(x+self.offset))))
    torch.manual_seed(73)
    model = Model()
    config = AdaptivePrivacyStrippingConfig(enabled=True,protected_scope='all',state_dtype='float32',
        rho_max=1.,lambda_utility=0.,tau_cos=0.,tau_dist=1.)
    stripper = ContrastSubspaceStripper(model,config.validated(),'cpu',3)
    counts = {n:torch.zeros_like(p,dtype=torch.int64) for n,p in model.named_parameters() if p.requires_grad}
    for spec in stripper._block_specs.values():
        for part in spec.parts:
            stripper._part_view(counts[part.parameter_name],part).add_(1)
    assert all(torch.equal(c,torch.ones_like(c)) for c in counts.values())
    assert 'classifier:head.weight:class_2' in stripper.block_names
    update = {n:torch.randn_like(p) for n,p in model.named_parameters() if p.requires_grad}
    before = copy.deepcopy(model.state_dict())
    probe = (torch.randn(9,4),torch.arange(9)%3)
    stripper.strip(update,0,probe)
    assert all(torch.equal(before[n],p) for n,p in model.state_dict().items())
    assert stripper.has_state
    clone = ContrastSubspaceStripper(model,config,'cpu',3)
    clone.load_state_dict(copy.deepcopy(stripper.state_dict()))
    support = torch.arange(sum(p.numel() for p in update.values()))
    safe,_ = stripper.strip_selected(update,support,rho=1.)
    resumed,_ = clone.strip_selected(update,support,rho=1.)
    assert all(torch.equal(safe[n],resumed[n]) for n in safe)
    for name,spec in stripper._block_specs.items():
        value = torch.cat([stripper._part_view(safe[p.parameter_name],p).flatten() for p in spec.parts])
        rows = torch.cat([p.reshape(3,-1) for p in stripper._state[name].direction_ema],dim=1)
        torch.testing.assert_close(rows@value,torch.zeros(3),atol=2e-5,rtol=0.)


def test_selected_projection_preserves_support_and_private_state():
    torch.manual_seed(59)
    model,stripper = setup()
    update = {n:torch.randn_like(p) for n,p in model.named_parameters()}
    stripper.strip(update,0,(torch.randn(8,4),torch.arange(8)%3))
    state = copy.deepcopy(stripper.state_dict())
    indices = torch.tensor([0,1,2,4,5,6,8,9,10,12,13,14],dtype=torch.long)
    vector = torch.cat([p.flatten() for p in update.values()])
    mask = torch.zeros(vector.numel(),dtype=torch.bool)
    mask[indices] = True
    vector[~mask] = 0.
    sparse,offset = {},0
    for name,value in update.items():
        sparse[name] = vector[offset:offset+value.numel()].reshape(value.shape).clone()
        offset += value.numel()
    before = copy.deepcopy(sparse)
    rng = torch.get_rng_state()
    safe,metrics = stripper.strip_selected(sparse,indices,rho=1.)
    assert torch.equal(rng,torch.get_rng_state())
    after = torch.cat([p.flatten() for p in safe.values()])
    assert not after[~mask].any()
    assert metrics['post_sparse_removed_fraction'] <= 1.+1e-6
    for name,spec in stripper._block_specs.items():
        parts = [stripper._part_view(safe[p.parameter_name],p).reshape(-1) for p in spec.parts]
        value = torch.cat(parts)
        rows = torch.cat([p.reshape(3,-1) for p in stripper._state[name].direction_ema],dim=1)
        torch.testing.assert_close(rows@value,torch.zeros(3),atol=1e-6,rtol=0.)
    assert all(torch.equal(before[n],sparse[n]) for n in sparse)
    for name in state['blocks']:
        for old,new in zip(state['blocks'][name]['direction_ema'],stripper.state_dict()['blocks'][name]['direction_ema']):
            assert torch.equal(old,new)


def test_selected_projection_zero_strength_and_invalid_support():
    model,stripper = setup()
    sparse = {n:torch.zeros_like(p) for n,p in model.named_parameters()}
    indices = torch.tensor([0,2],dtype=torch.long)
    safe,metrics = stripper.strip_selected(sparse,indices,rho=0.)
    assert safe is sparse and metrics['post_sparse_removed_fraction'] == 0.
    for bad in (torch.tensor([-1]),torch.tensor([0,0]),torch.tensor([100]),torch.tensor([0.])):
        try:
            stripper.strip_selected(sparse,bad,rho=0.)
        except ValueError:
            pass
        else:
            raise AssertionError('invalid selected support accepted')


def test_post_sparse_runtime_keeps_removed_components_out_of_error_feedback():
    import tempfile
    from types import SimpleNamespace
    from Clover_api.privacy.goal_runtime import GoalSupportMixin
    class Parent:
        def _topk_update_for_client(self,update,client_id,**kw):
            sparse = {'w':torch.tensor([2.,0.])}
            self.topk_residuals[client_id] = {'w':update['w']-sparse['w']}
            self._phase1_current_supports.append([0])
            return sparse
    class Projector:
        def strip_selected(self,sparse,indices,*,rho):
            assert indices.tolist() == [0] and rho == .5
            return {'w':sparse['w']*.5},{'post_sparse_removed_fraction':.25}
    class Runtime(GoalSupportMixin,Parent):
        def __init__(self,folder):
            self.support_enabled = False
            self.post_sparse_projection,self.post_sparse_strength = True,.5
            self.device,self.result_dir = 'cpu',folder
            self.topk_residuals,self._phase1_current_supports = {},[]
        def _adaptive_privacy_stripper_for_client(self,client_id):
            return Projector()
    with tempfile.TemporaryDirectory() as folder:
        api = Runtime(folder)
        result = api._topk_update_for_client({'w':torch.tensor([2.,3.])},0)
        assert torch.equal(result['w'],torch.tensor([1.,0.]))
        assert torch.equal(api.topk_residuals[0]['w'],torch.tensor([0.,3.]))
        assert api._phase1_current_supports == [[0]]
