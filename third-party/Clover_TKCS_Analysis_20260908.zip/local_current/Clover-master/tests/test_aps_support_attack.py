from __future__ import annotations

import json
import random
from pathlib import Path
import sys
import tempfile
from types import SimpleNamespace

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from Clover_api.privacy.topk_attack_trace import TopkAttackTraceRecorder
from Clover_api.SketchOPA.privacy_trace import project_support
from experiments.adaptive_privacy.evaluate_support_attack import evaluate_features, load_samples
from experiments.adaptive_privacy.run_privacy_evaluation import build


def recorder(root, **overrides):
    args = SimpleNamespace(phase1_run_dir=root, privacy_trace_feature_bins=16, seed=1,
        dataset="mnist", model="lenet5", aggregation_mode="topk_adaptive",
        phase1_partition_manifest={"partition_sha256": "a"*64}, partition_method="dir",
        partition_alpha=.5, phase1_source_sha256="b"*64, privacy_trace_target_class=0,
        update_transport_dtype="float16", topk_k=2, comm_round=1)
    for key, value in overrides.items():
        setattr(args, key, value)
    return TopkAttackTraceRecorder(args, [[10, 0], [0, 10]])


def test_trace_exact_observation_and_rng():
    with tempfile.TemporaryDirectory() as tmp:
        r = recorder(tmp)
        random.seed(31)
        np.random.seed(31)
        py_state, np_state = random.getstate(), np.random.get_state()
        indices, values = np.array([3, 9]), np.array([1., 0.], dtype=np.float16)
        r.record_client(0, indices, values)
        r.record_client(1, indices[::-1], values[::-1])
        r.record_round(0, [0, 1])
        assert random.getstate() == py_state
        assert np.array_equal(np.random.get_state()[1], np_state[1])
        assert np.array_equal(indices, [3, 9]) and np.array_equal(values, [1, 0])
        _, samples, _, _ = load_samples(Path(tmp)/"topk_attack_trace", "support")
        assert np.array_equal(samples[0].features, samples[1].features)
        assert np.array_equal(samples[0].features, project_support(indices, bins=16, seed=r.seed))
        with np.load(Path(tmp)/"topk_attack_trace/round_00001.npz") as data:
            assert not any(name in data for name in ("residual", "labels", "dense", "ema", "indices"))


def test_trace_rejects_conflicts_and_invalid_support():
    with tempfile.TemporaryDirectory() as tmp:
        r = recorder(tmp)
        try:
            r.record_client(0, [1, 1], [1, 2])
            raise AssertionError("accepted duplicate support")
        except ValueError:
            pass
        r.record_client(0, [1, 2], [1, 2])
        r.record_round(0, [0])
        r.record_client(0, [4, 6], [1, 2])
        try:
            r.record_round(0, [0])
            raise AssertionError("accepted conflicting round")
        except ValueError:
            pass


def test_trace_resume_only_allows_round_extension():
    with tempfile.TemporaryDirectory() as tmp:
        recorder(tmp)
        for overrides in ({"comm_round": 2}, {"phase1_resume": True, "comm_round": 0},
                          {"phase1_resume": True, "comm_round": 2, "seed": 2}):
            try:
                recorder(tmp, **overrides)
                raise AssertionError("accepted incompatible trace metadata")
            except ValueError:
                pass
        recorder(tmp, phase1_resume=True, comm_round=2)
        assert json.loads((Path(tmp)/"topk_attack_trace/manifest.json").read_text())["rounds"] == 2


def test_attack_detects_signal_and_splits_clients():
    labels = np.arange(80) % 2
    hist = np.stack([90-80*labels, 10+80*labels], axis=1)
    features = np.eye(2)[labels]
    rows, splits = evaluate_features(features, hist, np.arange(80), seeds=[1])
    for split in splits:
        assert not set(split["train_clients"]) & set(split["test_clients"])
    dominant = {row["control"]: row for row in rows if row["task"] == "dominant_label"}
    assert dominant["observed"]["balanced_accuracy"] == 1
    assert dominant["no_trace"]["balanced_accuracy"] == .5
    assert dominant["observed"]["majority_test_accuracy"] == .5


def test_frozen_pair_launcher():
    args = SimpleNamespace(dataset="cifar10", profile="dir0.5", rounds=20, python=sys.executable,
        data_root=Path("data"), output_root=Path("new_evaluation"), source_sha256="a"*64)
    left, lp = build(args, "topk_residual", 2)
    right, rp = build(args, "topk_aps", 2)
    for key in ("--phase1_partition_dir", "--partition_alpha", "--epochs", "--frac", "--seed"):
        assert left[left.index(key)+1] == right[right.index(key)+1]
    assert left[left.index("--epochs")+1] == "1"
    assert left[left.index("--partition_alpha")+1] == "0.5"
    assert lp != rp and "--topk_attack_trace_eval" in right


if __name__ == "__main__":
    for name, function in list(globals().items()):
        if name.startswith("test_") and callable(function):
            function()
            print("PASS", name)
