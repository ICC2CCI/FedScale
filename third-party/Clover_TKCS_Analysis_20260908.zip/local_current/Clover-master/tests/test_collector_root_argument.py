import json
from pathlib import Path

from scripts.collect_clover_sketchopa_results import main


def test_collector_root_and_out_arguments(tmp_path: Path):
    root = tmp_path / "runs"
    run = root / "exp1"
    run.mkdir(parents=True)
    (run / "final_summary.json").write_text(
        json.dumps(
            {
                "dataset": "mnist",
                "model": "lenet5",
                "mode": "sketchopa_plain_cs_residual",
                "rounds": 20,
                "final_acc": 0.98,
                "sketch_layout_mode": "fixed_public",
                "sketch_budget_ratio": 1.0,
                "sketch_allocation_strategy": "uniform_param",
            }
        ),
        encoding="utf-8",
    )
    (run / "round_metrics.csv").write_text("round,dataset,model,mode,test_acc\n19,mnist,lenet5,sketchopa_plain_cs_residual,0.98\n", encoding="utf-8")
    (run / "comm_metrics.csv").write_text(
        "round,dataset,model,method,payload_bytes,payload_over_topk16,payload_over_dense16\n"
        "19,mnist,lenet5,sketchopa_plain_cs_residual,43100,1.0,0.05\n",
        encoding="utf-8",
    )
    (run / "sketch_recovery_metrics.csv").write_text(
        "round,dataset,model,method,sketch_rows,sketch_layout_mode,sketch_budget_ratio,sketch_allocation_strategy,"
        "residual_enabled,payload_bytes,payload_over_topk16,payload_over_dense16,recovery_cosine,recovery_l2_rel\n"
        "19,mnist,lenet5,sketchopa_plain_cs_residual,5,fixed_public,1.0,uniform_param,True,43100,1.0,0.05,0.9,0.1\n",
        encoding="utf-8",
    )
    (run / "per_layer_recovery_metrics.csv").write_text(
        "round,dataset,model,method,layer_name,layer_recovery_cosine\n19,mnist,lenet5,sketchopa_plain_cs_residual,fc,0.9\n",
        encoding="utf-8",
    )
    (run / "layout.json").write_text("{}", encoding="utf-8")
    out = tmp_path / "summary"
    main(["--root", str(root), "--out", str(out)])
    assert (out / "summary_all.csv").exists()
    assert (out / "final_report.md").exists()
    assert (out / "recommended_configs.json").exists()
