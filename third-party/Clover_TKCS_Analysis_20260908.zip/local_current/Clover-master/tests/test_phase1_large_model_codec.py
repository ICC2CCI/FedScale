import sys
from pathlib import Path

import numpy as np
import torch

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from Clover_api.phase1.large_model_codec import Phase1UpdateCodec


NAMES = ["adapter.a", "adapter.b"]
SHAPES = [(4,), (4,)]
GLOBAL = [np.zeros(4, dtype=np.float32), np.zeros(4, dtype=np.float32)]
CLIENTS = [
    (3, 1, [np.asarray([8, 7, 1, 0], dtype=np.float32), np.zeros(4, dtype=np.float32)]),
    (5, 3, [np.asarray([0, 6, 5, 0], dtype=np.float32), np.zeros(4, dtype=np.float32)]),
]


def _codec(method):
    return Phase1UpdateCodec(
        parameter_names=NAMES,
        parameter_shapes=SHAPES,
        method=method,
        dataset="fixture",
        model="fixture-adapter",
        seed=1,
        device=torch.device("cpu"),
        active_clients=2,
        rho=0.25,
        sketch_rows=3,
    )


def test_dense_and_topk_use_exact_fp16_wire_accounting():
    dense = _codec("dense").aggregate(
        global_arrays=GLOBAL,
        client_deltas=CLIENTS,
        round_index=0,
    )
    assert dense.support["k"] == 8
    assert dense.communication["actual_payload_bytes"] == 16
    assert dense.communication["total_round_bytes"] == 32

    topk = _codec("topk").aggregate(
        global_arrays=GLOBAL,
        client_deltas=CLIENTS,
        round_index=0,
    )
    assert topk.support["k"] == 2
    assert topk.support["mean_client_support_size"] == 2.0
    assert topk.communication["actual_payload_bytes"] == 20
    assert topk.communication["index_dtype"] == "int64"
    assert np.count_nonzero(np.concatenate(_codec("topk").state_to_arrays(topk.delta))) <= 4


def test_tkcs_reuses_countsketch_and_exposes_residual_checkpoint_state():
    codec = _codec("tkcs")
    result = codec.aggregate(
        global_arrays=GLOBAL,
        client_deltas=CLIENTS,
        round_index=0,
    )
    assert result.support["k"] == 2
    assert result.sketch is not None
    assert result.recovery is not None
    assert result.sketch["rows"] == 3
    assert result.communication["actual_payload_bytes"] > 0
    assert result.communication["tkcs_total_bytes"] == result.communication["actual_payload_bytes"]
    assert set(codec.residual_state_dict()) == {3, 5}

    restored = _codec("tkcs")
    restored.load_residual_state_dict(codec.residual_state_dict())
    assert set(restored.residual_state_dict()) == {3, 5}


def test_topk_residual_preserves_wire_bytes_and_survives_checkpoint_restore():
    plain = _codec("topk").aggregate(
        global_arrays=GLOBAL,
        client_deltas=CLIENTS,
        round_index=0,
    )
    codec = _codec("topk_residual")
    first = codec.aggregate(
        global_arrays=GLOBAL,
        client_deltas=CLIENTS,
        round_index=0,
    )
    assert first.communication == plain.communication
    assert first.sketch is None
    assert first.recovery is None
    assert first.communication["index_dtype"] == "int64"
    residuals = codec.residual_state_dict()
    assert set(residuals) == {3, 5}
    assert residuals[3].shape == (8,)
    assert residuals[3][2].item() == 1.0

    restored = _codec("topk_residual")
    restored.load_residual_state_dict(residuals)
    zeros = [np.zeros(4, dtype=np.float32), np.zeros(4, dtype=np.float32)]
    second = restored.aggregate(
        global_arrays=GLOBAL,
        client_deltas=[(3, 1, zeros), (5, 3, zeros)],
        round_index=1,
    )
    flattened = np.concatenate(restored.state_to_arrays(second.delta))
    assert np.isclose(flattened[2], 0.25)
    assert second.communication["actual_payload_bytes"] == plain.communication["actual_payload_bytes"]


if __name__ == "__main__":
    test_dense_and_topk_use_exact_fp16_wire_accounting()
    test_tkcs_reuses_countsketch_and_exposes_residual_checkpoint_state()
    test_topk_residual_preserves_wire_bytes_and_survives_checkpoint_restore()
