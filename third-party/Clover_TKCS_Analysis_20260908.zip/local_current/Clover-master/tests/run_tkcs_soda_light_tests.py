from __future__ import annotations

import importlib
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

MODULES = [
    "tests.test_mixed_precision_layout_offsets",
    "tests.test_hybrid_dense_sketch_no_duplicate",
    "tests.test_flatten_unflatten_consistency",
    "tests.test_quant_dequant_segmented",
    "tests.test_secure_plain_aggregate_equivalence",
    "tests.test_context_binding_consistency",
    "tests.test_active_set_consistency",
    "tests.test_segmented_masking_unmasking",
    "tests.test_seed_share_reconstruction",
    "tests.test_soda_packed_encoding",
    "tests.test_soda_real_protocol_equivalence",
    "tests.test_soda_comm_accounting",
    "tests.test_soda_proof_commitments",
    "tests.test_sp_crypto_suite",
    "tests.test_sp_secure_shamir",
    "tests.test_sp_profile_and_vector_codec",
    "tests.test_sp_messages_and_masks",
    "tests.test_sp_reference_protocol",
    "tests.test_sp_countsketch_recovery",
    "tests.test_sp_wire",
    "tests.test_sp_key_store",
    "tests.test_sp_multiprocess",
    "tests.test_sp_opalwr_backend",
    "tests.test_sp_native_opalwr",
    "tests.test_sp_adversarial_transcript",
    "tests.test_sp_privacy_trace",
    "tests.test_sp_support_inference_attack",
    "tests.test_sp_fetchsgd_baseline",
    "tests.test_sp_baseline_registry",
    "tests.test_sp_malicious_evaluation",
    "tests.test_sp_support_attack_summary",
    "tests.test_sp_evaluation_protocol",
    "tests.test_sp_utility_matrix",
    "tests.test_sp_real_update_bridge",
    "tests.test_sp_system_matrix",
    "tests.test_sp_finalization_recovery",
    "tests.test_sp_comm_reference",
    "tests.test_sp_anonymous_artifact",
]


def main() -> None:
    total = 0
    for module_name in MODULES:
        module = importlib.import_module(module_name)
        for name in sorted(dir(module)):
            if not name.startswith("test_"):
                continue
            getattr(module, name)()
            total += 1
            print(f"ok {module_name}.{name}")
    print(f"tkcs_soda_light_tests: {total} tests passed")


if __name__ == "__main__":
    main()
