from pathlib import Path
import sys

import numpy as np

sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from experiments.adaptive_privacy.ridge_kernel_cache import RidgeKernelCache
from experiments.adaptive_privacy.goal_attacks import evaluate_features,fit_predict


def test_cached_ridge_matches_standardization_clipping_and_refits_without_labels_in_cache():
    rng = np.random.default_rng(732)
    x = rng.normal(size=(40,107))
    x[:,0] = 1.
    x[-1,1:20] = 1e6
    y = np.arange(40)%3
    fit,test,classes = np.arange(30),np.arange(30,40),np.arange(3)
    cache = RidgeKernelCache(x,block_columns=17)
    for labels in (y,y[::-1].copy()):
        for reg in (.01,1.,100.):
            expected = fit_predict(x,labels,fit,test,classes,reg)
            actual = cache.predict(labels,fit,test,classes,reg)
            np.testing.assert_allclose(actual,expected,atol=1e-10,rtol=1e-9)
    assert len(cache.kernels) == 1
    constant = np.ones((40,3))
    c = RidgeKernelCache(constant)
    np.testing.assert_array_equal(c.predict(y,fit,test,classes,.01),fit_predict(constant,y,fit,test,classes,.01))


def test_cached_ridge_retains_attacker_selection_controls_and_client_splits():
    rng = np.random.default_rng(997)
    y = np.arange(60)%2
    hist = np.c_[2+26*y,28-26*y]
    metadata = np.log1p(hist.sum(1)).reshape(-1,1)
    features = {'signal':np.c_[np.eye(2)[y],rng.normal(size=(60,25))*.01]}
    old,a = evaluate_features(features,hist,metadata,np.arange(60),split_seeds=(1,2))
    new,b = evaluate_features(features,hist,metadata,np.arange(60),split_seeds=(1,2),cached_ridge=True)
    assert a == b and len(old) == len(new)
    for left,right in zip(old,new):
        assert left.keys() == right.keys()
        for key in left:
            if isinstance(left[key],float):
                np.testing.assert_allclose(left[key],right[key],atol=1e-10,rtol=1e-9,equal_nan=True)
            else:
                assert left[key] == right[key]
