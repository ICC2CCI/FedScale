from __future__ import annotations

from copy import deepcopy
from pathlib import Path
import sys

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from Clover_api.SketchOPA.protocol.auditor import OPAAuditor
from Clover_api.SketchOPA.secure_aggregation import secure_aggregate_sketches


def test_context_substitution_fails_audit():
    sketches = [np.array([1.0, 2.0]), np.array([3.0, 4.0])]
    plain = np.sum(np.stack(sketches), axis=0)
    _, proof, _ = secure_aggregate_sketches(
        sketches,
        context={"round_id": 1, "model_hash": "m1", "sketch_seed": "seed"},
        committee_size=5,
        threshold=3,
        shprg_backend="opa_lwr_shprg",
        plain_sum=plain,
        quantization_scale=1.0,
        protocol_backend="local_exact_debug",
    )
    tampered = deepcopy(proof.transcript)
    tampered.context["model_hash"] = "m2"
    valid, reason = OPAAuditor(threshold=3).verify(tampered)
    assert not valid
    assert "context" in reason
