from __future__ import annotations

from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from Clover_api.SketchOPA.fixed_layout import build_fixed_public_layout, transport_value_bytes
from Clover_api.SketchOPA.model_flatten import LayerSpec
from Clover_api.SketchOPA.sketch import LayerPartitionedCountSketch


def test_mixed_precision_layout_offsets_are_contiguous():
    specs = [
        LayerSpec("conv1.weight", 0, 128, (128,)),
        LayerSpec("block.weight", 128, 4224, (4096,)),
        LayerSpec("fc.weight", 4224, 4736, (512,)),
    ]
    layout = build_fixed_public_layout(
        specs,
        k_global=128,
        rows=3,
        budget_ratio=2.0,
        value_dtype="float16",
        allocation_strategy="mixed_precision_sensitive",
        min_buckets=1,
        sensitive_layer_rules={"sensitive_layer_dtype": "float32", "sensitive_small_layer_threshold": 256},
    )
    by_name = {layer.layer_name: layer for layer in layout.layers}
    assert by_name["conv1.weight"].transport_dtype == "float32"
    assert by_name["block.weight"].transport_dtype == "float16"
    assert by_name["fc.weight"].transport_dtype == "float32"
    assert layout.payload_bytes <= layout.budget.target_payload_bytes

    sketch = LayerPartitionedCountSketch(rows=3, min_buckets=1)
    offsets = sketch.layout(specs, layout.k_by_layer(), fixed_layout=layout)
    cursor = 0
    for item in offsets:
        assert item.offset == cursor
        fixed = by_name[item.spec.name]
        expected_len = item.length
        expected_payload = expected_len * transport_value_bytes(fixed.transport_dtype)
        assert expected_payload == fixed.payload_bytes
        cursor += item.length
    assert cursor == sketch.sketch_length(specs, layout.k_by_layer(), fixed_layout=layout)
