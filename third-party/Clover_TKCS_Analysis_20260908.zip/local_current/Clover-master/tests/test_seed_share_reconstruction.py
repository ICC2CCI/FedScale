from __future__ import annotations

from pathlib import Path
import sys

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from Clover_api.SketchOPA.crypto.seed_space import shamir_reconstruct_seed, shamir_split_seed
from Clover_api.SketchOPA.protocol.context import DEFAULT_MODULUS


def test_threshold_seed_share_reconstruction():
    seed = np.array([11, 22, 33, 44], dtype=np.int64)
    shares = shamir_split_seed(seed, threshold=3, num_shares=5, seed_modulus=DEFAULT_MODULUS, rng_seed=123)
    reconstructed = shamir_reconstruct_seed(shares[:3], threshold=3, seed_modulus=DEFAULT_MODULUS)
    assert np.array_equal(reconstructed, seed)
