from __future__ import annotations

from pathlib import Path
import sys

import torch

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from Clover_api.SketchOPA.model_flatten import (
    flatten_learnable_params,
    hash_model_state,
    recover_flattened_to_state,
)


def test_flatten_unflatten_preserves_parameter_order_and_buffers():
    state = {
        "conv.weight": torch.arange(6, dtype=torch.float32).reshape(2, 3),
        "conv.bias": torch.tensor([1.0, 2.0]),
        "bn.running_mean": torch.tensor([3.0, 4.0]),
    }
    flat, specs, keys = flatten_learnable_params(state, ["bn.running_mean"], torch.device("cpu"))
    assert keys == ["conv.weight", "conv.bias"]
    assert [(s.name, s.start, s.end) for s in specs] == [("conv.weight", 0, 6), ("conv.bias", 6, 8)]
    recovered = recover_flattened_to_state(flat + 1.0, state, ["bn.running_mean"], buffer_mode="base")
    assert torch.equal(recovered["bn.running_mean"], state["bn.running_mean"])
    assert torch.equal(recovered["conv.weight"], state["conv.weight"] + 1.0)
    assert torch.equal(recovered["conv.bias"], state["conv.bias"] + 1.0)


def test_model_hash_binds_values_names_shapes_dtypes_and_buffers():
    state = {
        "weight": torch.tensor([[1.0, 2.0]], dtype=torch.float32),
        "running": torch.tensor([3], dtype=torch.int64),
    }
    reordered = {"running": state["running"].clone(), "weight": state["weight"].clone()}
    assert hash_model_state(state) == hash_model_state(reordered)

    changed = {name: value.clone() for name, value in state.items()}
    changed["weight"][0, 1] += 1.0
    assert hash_model_state(state) != hash_model_state(changed)

    changed_buffer = {name: value.clone() for name, value in state.items()}
    changed_buffer["running"][0] += 1
    assert hash_model_state(state) != hash_model_state(changed_buffer)
