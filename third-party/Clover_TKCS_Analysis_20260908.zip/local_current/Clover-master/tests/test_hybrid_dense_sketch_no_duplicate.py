from __future__ import annotations

from pathlib import Path
from types import SimpleNamespace
import sys

import numpy as np
import torch

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from Clover_api.SketchOPA.fixed_layout import build_fixed_public_layout
from Clover_api.SketchOPA.model_flatten import LayerSpec
from Clover_api.SketchOPA.sketch import LayerPartitionedCountSketch
from Clover_api.SketchOPA.sketch_recovery import estimate_dense_from_sketch
from Clover_api.SketchOPA.sketchopa_aggregator import SketchOPAAggregator


def test_hybrid_dense_layers_are_not_reselected_for_sketch():
    specs = [
        LayerSpec("small.bias", 0, 4, (4,)),
        LayerSpec("large.weight", 4, 24, (20,)),
    ]
    layout = build_fixed_public_layout(
        specs,
        k_global=3,
        rows=3,
        budget_ratio=4.0,
        value_dtype="float16",
        allocation_strategy="hybrid_dense_small_layers",
        min_buckets=1,
        dense_layer_threshold=4,
    )
    assert layout.layers[0].is_dense_layer
    args = SimpleNamespace(aggregation_mode="sketchopa_plain_cs", C=1e9)
    agg = SketchOPAAggregator(args, [], torch.device("cpu"), logger=None)
    flat = torch.tensor([9.0, 8.0, 7.0, 6.0, 5.0, 4.0] + [0.0] * 18)
    indices, _, sparse = agg._topk_with_fixed_layout(flat, 3, layout)
    dense_indices = set(range(0, 4))
    selected = set(indices.tolist())
    assert dense_indices.issubset(selected)
    assert len(indices.tolist()) == len(selected)
    assert sum(1 for idx in selected if idx >= 4) == 3
    assert torch.count_nonzero(sparse[:4]).item() == 4


def test_hybrid_dense_segment_recovers_exactly_once():
    specs = [
        LayerSpec("small.bias", 0, 4, (4,)),
        LayerSpec("large.weight", 4, 24, (20,)),
    ]
    layout = build_fixed_public_layout(
        specs,
        k_global=3,
        rows=3,
        budget_ratio=4.0,
        value_dtype="float16",
        allocation_strategy="hybrid_dense_small_layers",
        min_buckets=1,
        dense_layer_threshold=4,
    )
    sketch = LayerPartitionedCountSketch(rows=3, min_buckets=1)
    indices = np.array([0, 1, 2, 3, 4, 5, 6], dtype=np.int64)
    values = np.array([1.0, 2.0, 3.0, 4.0, 10.0, 11.0, 12.0], dtype=np.float64)
    context = {"round_id": 0, "model_hash": "toy", "sketch_seed": "seed", "layout_hash": layout.layout_hash}
    encoded = sketch.encode_sparse(indices, values, specs, context, layout.k_by_layer(), fixed_layout=layout)
    estimates, _ = estimate_dense_from_sketch(encoded, 24, specs, sketch, context, layout.k_by_layer(), fixed_layout=layout)
    assert np.allclose(estimates[:4], values[:4])
