#!/usr/bin/env bash
set -euo pipefail

COMMON_ARGS=(
  --dataset mnist
  --model lenet5
  --partition_method IID
  --method FedAvg
  --batch_size 50
  --lr 0.1
  --epochs 30
  --client_num_in_total 100
  --frac 0.1
  --comm_round 5
  --C 1000000000
  --sigma 0
  --alpha 0.01
)

python Clover-main.py "${COMMON_ARGS[@]}" --aggregation_mode dense --alpha 0
python Clover-main.py "${COMMON_ARGS[@]}" --aggregation_mode topk_plain
python Clover-main.py "${COMMON_ARGS[@]}" --aggregation_mode sketchopa_plain_cs \
  --sketch_rows 5 --sketch_bucket_factor 8 --sketch_min_buckets 128 \
  --sketch_recover_k_mode active_union --sketch_bucket_budget_mode active_union \
  --sketch_recovery_score plain_median
python Clover-main.py "${COMMON_ARGS[@]}" --aggregation_mode sketchopa_secure \
  --secure_debug_check \
  --sketch_rows 5 --sketch_bucket_factor 8 --sketch_min_buckets 128 \
  --sketch_recover_k_mode active_union --sketch_bucket_budget_mode active_union \
  --sketch_recovery_score plain_median \
  --committee_size 7 --committee_threshold 5 --shprg_backend opa_lwr_shprg

