import argparse
import logging
import os
import random
import sys
import pdb
import numpy as np
import torch

torch.set_num_threads(1)

sys.path.insert(0, os.path.abspath("./Clover"))

from Clover_api.model.cv.lenet5 import LeNet5
from Clover_api.data_preprocessing.mnist.data_loader import load_partition_data_mnist
from Clover_api.data_preprocessing.fmnist.data_loader import load_partition_data_fmnist
from Clover_api.data_preprocessing.cifar10.data_loader import load_partition_data_cifar10
from Clover_api.data_preprocessing.global_evaluation import build_global_evaluation_loaders
from Clover_api.model.cv.resnet import  customized_resnet18, tiny_resnet18
from Clover_api.Clover.Clover_api import CloverAPI
from Clover_api.Clover.fedavg_trainer import FedAvgTrainer
from Clover_api.phase1.runtime import exact_topk_count
from Clover_api.phase1.vision_data import dataset_spec, load_phase1_vision_data


def logger_config(log_path, logging_name):
    logger = logging.getLogger(logging_name)
    logger.setLevel(level=logging.DEBUG)
    handler = logging.FileHandler(log_path, mode='w',encoding='UTF-8')
    handler.setLevel(level=logging.DEBUG)
    formatter = logging.Formatter('%(message)s')
    handler.setFormatter(formatter)
    logger.addHandler(handler)
    return logger

def add_args(parser):
    """
    parser : argparse.ArgumentParser
    return a parser added with args required by fit
    """
    # Training settings
    parser.add_argument('--model', type=str, default='resnet18', metavar='N',
                        help="network architecture, supporting 'cnn_cifar10', 'cnn_cifar100', 'resnet18', 'vgg11'")

    parser.add_argument('--dataset', type=str, default='cifar10', metavar='N',
                        help='dataset used for training')

    parser.add_argument('--momentum', type=float, default=0.5, metavar='N',
                        help='momentum')

    parser.add_argument('--data_dir', type=str, default='data/data',
                        help='data directory, please feel free to change the directory to the right place')

    parser.add_argument('--partition_method', type=str, default='dir', metavar='N',
                        help="current supporting three types of data partition, one called 'dir' short for Dirichlet"
                             "one called 'n_cls' short for how many classes allocated for each client"
                             "and one called 'my_part' for partitioning all clients into PA shards with default latent Dir=0.3 distribution")

    parser.add_argument('--partition_alpha', type=float, default=0.6, metavar='PA',
                        help='available parameters for data partition method')

    parser.add_argument('--batch_size', type=int, default=50, metavar='N',
                        help='local batch size for training')

    parser.add_argument('--client_optimizer', type=str, default='sgd',
                        help='SGD with momentum; adam')
    
    parser.add_argument('--lr', type=float, default=0.1, metavar='LR',
                        help='learning rate (default: 0.1)')

    parser.add_argument('--lr_decay', type=float, default=0.998, metavar='LR_decay',
                        help='learning rate decay (default: 0.998)')

    parser.add_argument('--wd', help='weight decay parameter;', type=float, default=5e-4)

    parser.add_argument('--epochs', type=int, default=30, metavar='EP',
                        help='local training epochs for each client')
    
    parser.add_argument("--method", default='FedAvg', type=str, help="FedAvg")

    parser.add_argument('--client_num_in_total', type=int, default=500, metavar='NN',
                        help='the number of clients')

    parser.add_argument('--frac', type=float, default=0.1, metavar='NN',
                        help='the selection fraction of total clients in each round')

    parser.add_argument('--comm_round', type=int, default=1,
                        help='how many round of communications we shoud use')

    parser.add_argument('--frequency_of_the_test', type=int, default=1,
                        help='the frequency of the algorithms')

    parser.add_argument('--gpu', type=int, default=0,
                        help='gpu')

    parser.add_argument('--ci', type=int, default=0,
                        help='CI')
    parser.add_argument("--tag", type=str, default="test")

    parser.add_argument("--seed", type=int, default=2)
    parser.add_argument('--sigma', type=float, default=0.95,
                        help='the standard deviation of client-level DP noise')
    parser.add_argument('--C', type=float, default=0.2,
                        help='the threshold of clipping in DP')
    parser.add_argument('--num_experiments', type=int, default=1,
                        help='the number of experiments')
    parser.add_argument('--alpha', type=float, default=0,
                        help='the sparsification ratio')
    parser.add_argument('--update_transport_dtype', type=str, default='float32',
                        choices=['float32', 'float16'],
                        help='transport dtype used to simulate Dense/Top-k update communication')
    parser.add_argument('--comm_reference_topk_ratio', type=float, default=0.01,
                        help='fixed Top-k ratio used only as a communication denominator')
    parser.add_argument('--use_residual_topk', action='store_true',
                        help='enable error-feedback residuals for top-k sparsification')
    parser.add_argument('--aps_enabled', action='store_true',
                        help='enable client-local adaptive privacy stripping (non-cryptographic)')
    parser.add_argument('--aps_probe_batch_size', type=int, default=32)
    parser.add_argument('--aps_probe_interval', type=int, default=5)
    parser.add_argument('--aps_protected_scope', type=str, default='classifier+last_block',
                        choices=['classifier', 'head', 'classifier+last_block', 'head+last1', 'head+last2', 'all'])
    parser.add_argument('--aps_rho_max', type=float, default=0.5)
    parser.add_argument('--aps_lambda_utility', type=float, default=1.0)
    parser.add_argument('--aps_ema_beta_direction', type=float, default=0.9)
    parser.add_argument('--aps_ema_beta_risk', type=float, default=0.9)
    parser.add_argument('--aps_tau_cos', type=float, default=0.98)
    parser.add_argument('--aps_tau_dist', type=float, default=0.10)
    parser.add_argument('--aps_eps', type=float, default=1.0e-12)
    parser.add_argument('--aps_min_direction_norm', type=float, default=1.0e-10)
    parser.add_argument('--aps_state_dtype', type=str, default='float16',
                        choices=['float16', 'bfloat16', 'float32'])
    parser.add_argument('--aps_prior_mode', type=str, default='uniform', choices=['uniform'])
    parser.add_argument('--aps_bisection_steps', type=int, default=10)
    parser.add_argument('--aps_block_granularity', type=str, default='auto',
                        choices=['auto', 'tensor'])
    parser.add_argument('--aggregation_mode', type=str, default='dense',
                        choices=[
                            'dense',
                            'topk_plain',
                            'topk_residual',
                            'topk_adaptive',
                            'fetchsgd_plain',
                            'sketchopa_plain_cs',
                            'sketchopa_plain_cs_residual',
                            'sketchopa_secure',
                            'sketchopa_secure_residual',
                            'soda_tkcs_full',
                        ])
    parser.add_argument('--fetchsgd_rows', type=int, default=3,
                        help='number of rows in the fixed flat FetchSGD CountSketch')
    parser.add_argument('--fetchsgd_budget_ratio', type=float, default=1.0,
                        help='per-client FetchSGD payload relative to the int64-index fp16 Top-k payload')
    parser.add_argument('--fetchsgd_transport_dtype', type=str, default='float16',
                        choices=['float32', 'float16'],
                        help='logical wire dtype for FetchSGD sketch buckets')
    parser.add_argument('--fetchsgd_momentum', type=float, default=0.9,
                        help='server-side FetchSGD momentum coefficient')
    parser.add_argument('--fetchsgd_server_lr', type=float, default=1.0,
                        help='server multiplier for FedAvg model-delta sketches')
    parser.add_argument('--fetchsgd_seed', type=int, default=0,
                        help='fixed CountSketch seed shared by all clients and rounds')
    parser.add_argument('--fetchsgd_chunk_size', type=int, default=262144,
                        help='coordinate chunk size for mapping construction and recovery')
    parser.add_argument('--sketch_rows', type=int, default=5)
    parser.add_argument('--sketch_bucket_factor', type=int, default=8)
    parser.add_argument('--sketch_min_buckets', type=int, default=128)
    parser.add_argument('--sketch_recover_k_mode', type=str, default='active_union',
                        choices=['plain_k', 'active_union', 'fixed_multiplier'])
    parser.add_argument('--sketch_recover_k_multiplier', type=float, default=1.0)
    parser.add_argument('--sketch_bucket_budget_mode', type=str, default='active_union',
                        choices=['single_client', 'active_union'])
    parser.add_argument('--sketch_layout_mode', type=str, default='dynamic_debug',
                        choices=['dynamic_debug', 'fixed_public'])
    parser.add_argument('--sketch_budget_ratio', type=float, default=1.0)
    parser.add_argument('--sketch_budget_ref', type=str, default='topk16',
                        choices=['topk16'])
    parser.add_argument('--sketch_allocation_strategy', type=str, default='uniform_param',
                        choices=[
                            'uniform_param',
                            'topk_count_calibrated',
                            'topk_count_adaptive',
                            'norm_calibrated',
                            'norm_adaptive',
                            'hybrid_dense_small_layers',
                            'mixed_precision_sensitive',
                            'mixed_precision_sensitive_layers',
                        ])
    parser.add_argument('--layout_norm_alpha', type=float, default=0.5)
    parser.add_argument('--layout_calibration_path', type=str, default='')
    parser.add_argument('--dense_layer_threshold', type=int, default=4096)
    parser.add_argument('--sensitive_layer_dtype', type=str, default='float32',
                        choices=['float32', 'float16'])
    parser.add_argument('--default_sketch_dtype', type=str, default='float16',
                        choices=['float32', 'float16'])
    parser.add_argument('--sensitive_small_layer_threshold', type=int, default=4096)
    parser.add_argument('--sketch_recovery_score', type=str, default='plain_median',
                        choices=['plain_median', 'capped_confidence', 'row_agreement'])
    parser.add_argument('--sketch_conf_cap', type=float, default=100.0)
    parser.add_argument('--sketch_recovered_clip_norm', type=float, default=0.0)
    parser.add_argument('--sketch_transport_dtype', type=str, default='float64',
                        choices=['float64', 'float32', 'float16'])
    parser.add_argument('--sketch_value_bytes', type=int, default=8)
    parser.add_argument('--sketchopa_protocol', type=str, default='plain_cs',
                        choices=['plain_cs', 'secure_seed_shprg'])
    parser.add_argument('--committee_size', type=int, default=7)
    parser.add_argument('--committee_threshold', type=int, default=5)
    parser.add_argument('--shprg_backend', type=str, default='opa_lwr_shprg')
    parser.add_argument('--secure_debug_check', action='store_true')
    parser.add_argument('--results_dir', type=str, default='results_sketchopa_clover')
    parser.add_argument('--save_latest_checkpoint', action='store_true',
                        help='save latest global-model checkpoint after every communication round')
    parser.add_argument('--save_full_residual_checkpoint', action='store_true',
                        help='also include client residual buffers in latest_checkpoint.pt; can be very large')
    parser.add_argument('--sketch_quantization_scale', type=float, default=1000000.0)
    parser.add_argument('--secure_exact_max_len', type=int, default=4096)
    parser.add_argument('--secure_protocol_backend', type=str, default='soda_real',
                        choices=['soda_real', 'local_exact_debug'])
    parser.add_argument('--soda_encoding', type=str, default='auto',
                        choices=['auto', 'uint16', 'uint32', 'uint64'])
    parser.add_argument('--soda_block_size', type=int, default=16384)
    parser.add_argument('--soda_audit_mode', type=str, default='commitment_only',
                        choices=['commitment_only', 'full_opening_debug'])
    parser.add_argument('--soda_disable_large_sketch_fallback', action='store_true', default=True)
    parser.add_argument('--soda_seed_dim', type=int, default=16)
    parser.add_argument('--privacy_trace_mode', choices=('off', 'eval'), default='off',
                        help='evaluation-only export of support/sketch observations; never enabled in production')
    parser.add_argument('--privacy_trace_feature_bins', type=int, default=512)
    parser.add_argument('--privacy_trace_target_class', type=int, default=0)
    parser.add_argument('--topk_attack_trace_eval', action='store_true',
                        help='Evaluation-only actual Top-k support/value projections; no protocol changes.')
    parser.add_argument('--secure_bridge_trace_mode', choices=('off', 'private_eval'), default='off',
                        help='evaluation-only export of one private real-update trace for the secure-protocol bridge')
    parser.add_argument('--secure_bridge_trace_round', type=int, default=0,
                        help='zero-based communication round exported by private secure-bridge tracing')
    parser.add_argument('--evaluation_protocol', type=str, default='legacy_client_weighted',
                        choices=['legacy_client_weighted', 'global_official_test_holdout'],
                        help='evaluation protocol; the paper path uses a disjoint global validation/test holdout')
    parser.add_argument('--validation_fraction', type=float, default=0.2,
                        help='fraction of the official test set reserved for validation in the global holdout protocol')
    parser.add_argument('--validation_seed', type=int, default=20260803,
                        help='fixed seed for the stratified global validation/test split')
    parser.add_argument('--global_eval_batch_size', type=int, default=256)
    parser.add_argument('--save_validation_checkpoint', action='store_true',
                        help='save the model selected by validation accuracy without optimizer or residual state')
    parser.add_argument('--phase1', action='store_true',
                        help='enable the isolated TKCS Phase 1 execution contract')
    parser.add_argument('--phase1_run_dir', type=str, default='',
                        help='exact output directory for one Phase 1 run')
    parser.add_argument('--phase1_source_sha256', type=str, default='',
                        help='SHA-256 of the exact deployed Phase 1 source snapshot')
    parser.add_argument('--phase1_partition_dir', type=str, default='',
                        help='immutable partition directory shared by all methods')
    parser.add_argument('--phase1_partition_seed', type=int, default=1)
    parser.add_argument('--phase1_distribution', type=str, default='')
    parser.add_argument('--phase1_strict_k', action='store_true',
                        help='use k=ceil(rho*d) instead of the historical floor behavior')
    parser.add_argument('--phase1_resume', action='store_true')
    parser.add_argument('--phase1_checkpoint_every', type=int, default=10)
    parser.add_argument('--phase1_timing_block_size', type=int, default=10)
    parser.add_argument('--phase1_data_workers', type=int, default=0)
    parser.add_argument('--phase1_pin_memory', action='store_true')
    return parser


def load_data(args, dataset_name):
    if bool(getattr(args, "phase1", False)):
        loaded = load_phase1_vision_data(args, logger=logger)
        train_data_num, test_data_num, train_data_global, test_data_global, \
            train_data_local_num_dict, train_data_local_dict, test_data_local_dict, \
            class_num, client_label_counts, partition_manifest = loaded
        args.phase1_class_num = int(class_num)
        args.phase1_partition_manifest = {
            key: value
            for key, value in partition_manifest.items()
            if key not in {'train_indices', 'test_indices'}
        }
        return [
            train_data_num,
            test_data_num,
            train_data_local_num_dict,
            train_data_local_dict,
            test_data_local_dict,
            client_label_counts,
            None,
            None,
            None,
        ]
    if dataset_name == "cifar10":
        args.data_dir += "cifar10"
        train_data_num, test_data_num, train_data_global, test_data_global, \
        train_data_local_num_dict, train_data_local_dict, test_data_local_dict, \
        class_num = load_partition_data_cifar10(args.data_dir, args.partition_method,
                                args.partition_alpha, args.client_num_in_total, args.batch_size, logger)
    elif dataset_name == "mnist":
        
        args.data_dir += "mnist"
        train_data_num, test_data_num, train_data_global, test_data_global, \
        train_data_local_num_dict, train_data_local_dict, test_data_local_dict, \
        class_num = load_partition_data_mnist(args.data_dir, args.partition_method,
                                args.partition_alpha, args.client_num_in_total, args.batch_size, logger)
    elif dataset_name == "fmnist":
        args.data_dir += "fmnist"
        train_data_num, test_data_num, train_data_global, test_data_global, \
        train_data_local_num_dict, train_data_local_dict, test_data_local_dict, \
        class_num = load_partition_data_fmnist(args.data_dir, args.partition_method,
                                args.partition_alpha, args.client_num_in_total, args.batch_size, logger)
        

    
    validation_global = None
    heldout_test_global = None
    evaluation_manifest = None
    if args.evaluation_protocol == 'global_official_test_holdout':
        validation_global, heldout_test_global, evaluation_manifest = build_global_evaluation_loaders(
            dataset=dataset_name,
            data_dir=args.data_dir,
            batch_size=args.global_eval_batch_size,
            validation_fraction=args.validation_fraction,
            validation_seed=args.validation_seed,
        )
        args.evaluation_manifest = evaluation_manifest
    dataset = [train_data_num, test_data_num,
               train_data_local_num_dict, train_data_local_dict, test_data_local_dict, class_num,
               validation_global, heldout_test_global, evaluation_manifest]
    return dataset



def create_model(args, model_name,class_num,logger):
    # logger.info("create_model. model_name = %s" % (model_name))
    model = None
    if model_name == "lenet5":
        model = LeNet5(class_num)
    elif model_name =="resnet18":
        model = customized_resnet18(class_num=class_num)
    elif model_name == "tiny_resnet18":
        model = tiny_resnet18(class_num=class_num)
    return model


def custom_model_trainer(args, model, logger):
    return FedAvgTrainer(model, args, logger)

def count_parameters(model):
    params = 0
    for p in model.parameters():
        if p.requires_grad:
            params += p.numel()
    return params


def count_all_parameters(model):
    return sum(int(parameter.numel()) for parameter in model.parameters())

def get_buffer_names(model):
    return [name for name, _ in model.named_buffers()]

if __name__ == "__main__":

    parser = add_args(argparse.ArgumentParser(description='FedAvg-standalone'))
    args = parser.parse_args()
    if args.aggregation_mode == 'soda_tkcs_full':
        args.aggregation_mode = 'sketchopa_secure_residual'
    # print("torch version{}".format(torch.__version__))
    if args.aggregation_mode == 'dense' and args.alpha:
        args.aggregation_mode = 'topk_residual' if args.use_residual_topk else 'topk_plain'
    if args.aggregation_mode == 'topk_adaptive':
        args.aps_enabled = True
    elif args.aps_enabled:
        raise RuntimeError('--aps_enabled requires --aggregation_mode topk_adaptive')
    if args.topk_attack_trace_eval and (
        not args.phase1 or args.aggregation_mode not in {'topk_residual', 'topk_adaptive'}
    ):
        raise RuntimeError('Top-k attack traces require Phase1 Top-k+EF or APS evaluation')
    if args.aggregation_mode != 'dense' and args.alpha <= 0:
        args.alpha = 0.01
    if args.aggregation_mode in {'sketchopa_secure', 'sketchopa_secure_residual'} and args.shprg_backend != 'opa_lwr_shprg':
        raise RuntimeError('Main SketchOPA training must use opa_lwr_shprg')
    if args.sketch_layout_mode == 'fixed_public' and args.sketch_value_bytes == 8:
        args.sketch_value_bytes = 2 if args.default_sketch_dtype == 'float16' else 4
    if args.phase1:
        allowed_modes = {
            'dense',
            'topk_plain',
            'topk_residual',
            'topk_adaptive',
            'sketchopa_plain_cs_residual',
        }
        if args.aggregation_mode not in allowed_modes:
            raise RuntimeError(
                'Phase 1 permits dense, Top-k variants, and sketchopa_plain_cs_residual'
            )
        if float(args.sigma) != 0.0:
            raise RuntimeError('Phase 1 forbids DP; set --sigma 0')
        if str(args.privacy_trace_mode) != 'off' or str(args.secure_bridge_trace_mode) != 'off':
            raise RuntimeError('Phase 1 forbids privacy/security trace paths')
        if not args.phase1_strict_k:
            raise RuntimeError('Phase 1 requires --phase1_strict_k')
        if not args.phase1_run_dir or not args.phase1_partition_dir:
            raise RuntimeError('Phase 1 requires explicit run and immutable partition directories')
        source_hash = str(args.phase1_source_sha256).lower()
        if len(source_hash) != 64 or any(ch not in '0123456789abcdef' for ch in source_hash):
            raise RuntimeError('Phase 1 requires a lowercase 64-hex --phase1_source_sha256')
        spec = dataset_spec(args.dataset)
        if args.model != spec.default_model:
            raise RuntimeError(
                f'Phase 1 dataset {args.dataset} requires model {spec.default_model}, got {args.model}'
            )
        if int(args.phase1_checkpoint_every) <= 0 or int(args.phase1_timing_block_size) <= 0:
            raise RuntimeError('Phase 1 checkpoint/timing intervals must be positive')

    data_partition = args.partition_method
    if data_partition != "IID":
        data_partition += str(args.partition_alpha)
    args.identity = args.method+"-"+args.dataset+"-"+ data_partition+"-"
    args. client_num_per_round = int(args.client_num_in_total* args.frac)
    args.identity += args.model
    args.identity += "-C" + str(args.C)
    args.identity += "-round" + str(args.comm_round) + "-num_client" + str(args.client_num_in_total)
    args.identity += "-l_ep"+ str(args.epochs)
    args.identity += "-l_bc"+ str(args.batch_size)
    args.identity += "-alpha"+ str(args.alpha)
    args.identity += "-mode"+ str(args.aggregation_mode)
    if str(getattr(args, "tag", "test")) not in {"", "test"}:
        args.identity += "-tag" + str(args.tag)

    
    cur_dir = os.path.abspath(__file__).rsplit("/", 1)[0]
    os.makedirs('LOG/' + args.dataset, exist_ok=True)
    log_path = os.path.join(cur_dir, 'LOG/' + args.dataset + '/' + args.identity + '.log')
    logger = logger_config(log_path='LOG/' + args.dataset + '/' + args.identity + '.log', logging_name=args.identity)

    logger.info(args)
    device = torch.device("cuda:" + str(args.gpu) )
    logger.info(device)
    logger.info("running at device{}".format(device))

    # Set the random seed. The np.random seed determines the dataset partition.
    # The torch_manual_seed determines the initial weight.
    # We fix these two, so that we can reproduce the result.
    random.seed(args.seed)
    np.random.seed(args.seed)
    torch.manual_seed(args.seed)
    torch.cuda.manual_seed_all(args.seed)
    torch.backends.cudnn.deterministic = True

    for exper_index in range(args.num_experiments):
        # load data
        dataset = load_data(args, args.dataset)
        # print(dataset)
        
        # create model.
        if args.phase1:
            model = create_model(
                args,
                model_name=args.model,
                class_num=int(args.phase1_class_num),
                logger=logger,
            )
            args.model_class_num = int(args.phase1_class_num)
        elif args.dataset == "emnist":
            model = create_model(args, model_name=args.model, class_num= 62, logger = logger)
            args.model_class_num = 62
        else:
            model = create_model(args, model_name=args.model, class_num= 10, logger = logger)
            args.model_class_num = 10

        model_trainer = custom_model_trainer(args, model, logger)
        # logger.info(model)

        num_of_params = count_parameters(model)
        total_model_params = count_all_parameters(model)
        if args.alpha:
            num_of_sparse_params = exact_topk_count(
                args.alpha,
                num_of_params,
                strict_ceil=bool(args.phase1 and args.phase1_strict_k),
            )
        else:
            num_of_sparse_params = 0 # full vector
        args.total_model_params = int(total_model_params)
        args.trainable_params = int(num_of_params)
        args.federated_update_dim = int(num_of_params)
        args.phase1_rho = (
            1.0 if bool(args.phase1 and args.aggregation_mode == 'dense') else float(args.alpha)
        )
        args.topk_k = (
            int(num_of_params)
            if bool(args.phase1 and args.aggregation_mode == 'dense')
            else int(num_of_sparse_params)
        )
        print(
            f'Parameter size --- total={total_model_params}, trainable={num_of_params}, '
            f'd={num_of_params}, rho={args.phase1_rho if args.phase1 else args.alpha}, '
            f'k={args.topk_k if args.phase1 else num_of_sparse_params}')

        buffer_names = get_buffer_names(model)

        CloverAPI = CloverAPI(dataset, device, args, model_trainer, logger, buffer_names, num_of_sparse_params)
        CloverAPI.train(exper_index)
