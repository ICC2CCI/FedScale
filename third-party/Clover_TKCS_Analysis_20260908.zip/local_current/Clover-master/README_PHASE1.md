# TKCS Phase 1 Reproduction Guide

This directory implements the 39-run matrix in
`Codex_TKCS_Phase1_Experiment_Plan.md`. Phase 1 measures ML utility,
compression, recovery quality, and timing only. Secure aggregation, masks,
seed sharing, DP, dropout recovery, and proofs are fail-closed or disabled.

## Frozen Methods

| ID | Update sent per active client | Residual |
|---|---|---|
| `dense` | all federated trainable values as FP16 | none |
| `topk` | global Top-k with int64 indices and FP16 values | none |
| `tkcs` | global Top-k, fixed-public CountSketch, FP16 buckets | client-local error feedback |

For sparse methods, `k = ceil(0.01 * d)`, where `d` is the exact number of
federated trainable elements. For PEFT models, `d` contains only the state
returned by the upstream trainable/PEFT aggregation contract. Dense reports
`rho=1` and `k=d`. The Top-k/TKCS residual asymmetry is inherited from the
existing Clover mainline and is explicitly recorded rather than hidden.

## Data

Set one persistent data/cache root per host. Existing torchvision caches can be
reused with symbolic links; training outputs remain isolated.

Expected vision layouts are:

```text
<data-root>/mnist/MNIST
<data-root>/fmnist/FashionMNIST
<data-root>/cifar10/cifar-10-batches-py
<data-root>/cifar100/cifar-100-python
<data-root>/tiny_imagenet/tiny-imagenet-200/{train,val}
```

MNIST/FMNIST/CIFAR10 call torchvision with `download=True`, so a valid cache is
used without network traffic. CIFAR100 is downloaded only if absent. Tiny
ImageNet must be prepared manually in its standard 200-class, 64x64 layout.
GLUE and model caches are supplied through the RoBERTa `--cache-root` path.
FlowerTune keeps its native `flwrlabs/alpaca-gpt4` partitioning.

Every vision split is written once as `partition.json` plus
`client_class_histogram.csv`. A label, seed, client-count, or distribution
mismatch aborts instead of regenerating the partition.

## Environments

- Vision: CUDA PyTorch plus the dependencies already used by Clover.
- RoBERTa: the pinned FederatedScope `llm` checkout, Transformers, Datasets,
  PEFT, and FederatedScope dependencies.
- Phi: an isolated install of `codes/flowertune-benchmark-main/general_nlp`.
  Keep the upstream 4-bit Phi-4-mini, FlashAttention-2, gradient checkpointing,
  DoRA rank 32/alpha 64, target modules, batch 16, 10 local steps, 20
  supernodes, fraction-fit 0.2, and 15-round configuration unchanged.

The Phi memory smoke runs the original model/training configuration on the
A6000. If it OOMs, retain `FAILED` and `stdout.log`; do not silently lower the
batch, rank, model, or target modules.

## Gate Order

1. Run two-round Dense, Top-k, and TKCS smoke tests for every new task/model.
2. Run the 20-round CIFAR10, CIFAR100, and RoBERTa-CoLA feasibility gates.
3. Inspect loss, utility, recovery, payload, timing, peak memory, and
   checkpoints. A failed or abnormal gate blocks its formal run.
4. Run the formal matrix: 30 vision, 6 RoBERTa, and 3 Phi experiments.
5. Build the final summary from measured formal directories only.

The exact shell commands are in `scripts/phase1_commands.sh`. The launchers
refuse nonempty output directories unless `--resume` is explicit.
Set `PHASE1_SOURCE_SHA256` to the SHA-256 of the exact deployed source archive;
every launcher binds it into `resolved_config.yaml` and rejects a missing or
malformed value.

## Vision Runs

`experiments/phase1/run_vision.py` runs one experiment. The formal host-scoped
matrix is launched with `run_vision_matrix.py`. Formal settings preserve the
existing Clover training configuration: 100 clients, 10 active clients, 30
local epochs, batch 50, SGD, LR 0.1, decay 0.998, momentum 0.5, and weight decay
0.0005. FMNIST Dirichlet beta=1 is the explicit exception: it uses five local
epochs because the original 30-epoch profile diverged for Dense and Top-k as
well as TKCS. Round counts are MNIST 90, FMNIST 160, CIFAR10 200, CIFAR100 500,
and Tiny ImageNet 500. Every dataset runs IID and Dirichlet beta=1.

### Adaptive Privacy Stripping for Top-k

`topk_aps` is an extension experiment and is intentionally not added to the
frozen 30-run Phase 1 matrix. It is a non-cryptographic, client-local
alternative to the separate CountSketch plus secure-aggregation path. Its
runtime order is:

```text
local update + client residual
  -> adaptive privacy stripping
  -> fixed-length Top-k
  -> next residual = stripped update - sparse reconstruction
```

The module uses a private deterministic probe batch and a public uniform label
prior. Probe data, directions, risks, and stripping metrics remain local; the
wire payload is still exactly the same Top-k indices and values as
`topk_residual`. It does not provide cryptographic confidentiality and must not
be reported as secure aggregation.

Run a matched 20-round pair with the same source hash, partition, and seed:

```bash
python experiments/phase1/run_vision.py \
  --dataset mnist --distribution iid --method topk_residual \
  --stage adaptive --rounds 20 --seed 1 --python "$VISION_PYTHON" \
  --data-root "$VISION_DATA" --output-root "$APS_RESULTS" \
  --source-sha256 "$PHASE1_SOURCE_SHA256"

python experiments/phase1/run_vision.py \
  --dataset mnist --distribution iid --method topk_aps \
  --stage adaptive --rounds 20 --seed 1 --python "$VISION_PYTHON" \
  --data-root "$VISION_DATA" --output-root "$APS_RESULTS" \
  --source-sha256 "$PHASE1_SOURCE_SHA256"
```

Replace `mnist` with `cifar10` for the ResNet18 pair. APS parameters can be
overridden with the launcher's `--aps-*` options; defaults match the standalone
implementation plan. Adaptive runs additionally write
`adaptive_privacy_metrics.csv` and hash-bound client EMA state shards. All new
runs write rolling `checkpoint/latest.pt` plus `checkpoint/best.pt`; the latter
is explicitly labeled as diagnostic test-accuracy selection.

### FMNIST Dirichlet LR Amendment

The preregistered five-local-epoch, LR 0.1 TKCS run is retained as a failed
result: it deterministically reaches a non-finite client-local loss at round
103. A bounded replay admitted LR 0.05 as a post-hoc stability profile. This
profile must not be substituted silently for the preregistered run. Apply the
auditable patch to a fresh source tree and rerun all three methods from round 1:

```bash
patch -p1 < experiments/phase1/amendments/fmnist_dirichlet_lr005.patch
export PHASE1_AMENDMENT_RESULTS=/new/empty/result/root
export PHASE1_AMENDMENT_SOURCE_SHA256=<sha256-of-patched-source-archive>
scripts/phase1_fmnist_lr005_amendment.sh
```

The amendment launcher keeps the partition, seed, client sampling, optimizer,
wire dtypes, Top-k ratio, CountSketch layout, and residual semantics fixed. It
runs Dense, Top-k, and TKCS sequentially, then invokes
`validate_fmnist_amendment.py` to check all 160 rounds, configuration equality,
partition identity, payload equations, and final checkpoint hashes.

## RoBERTa Runs

`run_roberta.py` launches a pinned FederatedScope-backed worker. Formal CoLA
and MRPC runs use 500 rounds, 20 clients per round, immutable approximately
30-sample clients, LoRA rank 8/alpha 32, AdamW at `1e-5`, and one seed. CoLA's
primary metric is MCC; MRPC's is F1. See `docs/roberta_source.md` for source and
adaptation provenance.

## Phi Runs

`run_phi.py` invokes the real Flower CLI from the unmodified General NLP app
configuration plus `phase1.enabled=true`. The new strategy operates only on
the PEFT/DoRA state returned by FlowerTune. Native evaluation remains disabled,
so unavailable utility fields are `NA`, not zero; train loss and native
FlowerTune metrics remain in `metrics.csv`.

## Resume

All runners write `checkpoint/latest.pt` after each committed round and retain
versioned checkpoints at the configured interval and final round. Resume:

```bash
<same launcher command> --resume
```

The runner validates the resolved configuration and trainable manifest,
restores global trainable parameters, client residuals, and RNG state, truncates
CSV rows newer than the committed checkpoint, and continues round numbering.
The target round count may increase but cannot decrease.

## Per-Run Artifacts

Every successful run contains:

```text
resolved_config.yaml
metrics.csv
round_timing.csv
time_10rounds.csv
communication.csv
support_stats.csv
trainable_parameter_manifest.txt
checkpoint/latest.pt
checkpoint/latest_meta.json
stdout.log
summary.json
DONE
```

TKCS additionally contains `sketch_stats.csv`, `recovery_stats.csv`, and
`per_layer_collision_stats.csv`. Communication is computed from the serialized
binary dtype contract, never Python object size. CUDA training timers are
synchronized before and after timed regions.

## Final Collection

Pass both host result roots to `build_summary.py`. Without `--allow-partial`,
the collector requires all 39 predeclared formal runs, exact target rounds, and
`DONE` markers. It emits:

```text
summary_all.csv
table_a_utility.{csv,md}
table_b_communication.{csv,md}
table_c_recovery.{csv,md}
table_d_timing.{csv,md}
collection_status.json
```

Use `--allow-partial` only for progress inspection. Partial tables are not
formal Phase 1 results.
