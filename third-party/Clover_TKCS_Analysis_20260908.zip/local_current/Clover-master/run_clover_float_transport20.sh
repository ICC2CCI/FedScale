#!/usr/bin/env bash
set -euo pipefail

DATASETS="${DATASETS:-mnist fmnist cifar10}"
ROUNDS="${ROUNDS:-20}"
RESULTS_DIR="${RESULTS_DIR:-results_float_transport20}"

BASE_ARGS=(
  --partition_method IID
  --method FedAvg
  --batch_size 50
  --lr 0.1
  --epochs 30
  --client_num_in_total 100
  --frac 0.1
  --comm_round "${ROUNDS}"
  --C 1000000000
  --sigma 0
  --gpu 0
  --results_dir "${RESULTS_DIR}"
)

model_for_dataset() {
  case "$1" in
    mnist|fmnist) echo lenet5 ;;
    cifar10) echo resnet18 ;;
    *) echo "unsupported dataset: $1" >&2; exit 2 ;;
  esac
}

run_case() {
  local dataset="$1"
  local model="$2"
  local profile="$3"
  shift 3
  echo "RUN ${dataset} ${model} ${profile}"
  python Clover-main.py \
    "${BASE_ARGS[@]}" \
    --dataset "${dataset}" \
    --model "${model}" \
    --tag "${profile}" \
    "$@"
}

for DATASET in ${DATASETS}; do
  MODEL=$(model_for_dataset "${DATASET}")

  run_case "${DATASET}" "${MODEL}" dense_float16 \
    --aggregation_mode dense \
    --alpha 0 \
    --update_transport_dtype float16

  run_case "${DATASET}" "${MODEL}" topk_float16 \
    --aggregation_mode topk_plain \
    --alpha 0.01 \
    --update_transport_dtype float16

  run_case "${DATASET}" "${MODEL}" near_topk_float32_residual \
    --aggregation_mode sketchopa_plain_cs_residual \
    --alpha 0.01 \
    --sketch_recover_k_mode active_union \
    --sketch_recovery_score plain_median \
    --sketch_rows 3 \
    --sketch_bucket_factor 1 \
    --sketch_min_buckets 8 \
    --sketch_bucket_budget_mode single_client \
    --sketch_transport_dtype float32 \
    --sketch_value_bytes 4
done

RESULTS_DIR="${RESULTS_DIR}" python scripts/collect_clover_sketchopa_results.py
