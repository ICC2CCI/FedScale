from __future__ import annotations

import argparse
import json
from pathlib import Path
import sys

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from Clover_api.SketchOPA.secure_aggregation import secure_aggregate_sketches


def main() -> None:
    parser = argparse.ArgumentParser(description="Run a small SODA real protocol smoke test")
    parser.add_argument("--length", type=int, default=10000)
    parser.add_argument("--active_clients", type=int, default=3)
    parser.add_argument("--encoding", type=str, default="uint16", choices=["auto", "uint16", "uint32", "uint64"])
    parser.add_argument("--block_size", type=int, default=1024)
    parser.add_argument("--out", type=str, default="")
    args = parser.parse_args()

    vectors = []
    for client_idx in range(int(args.active_clients)):
        vec = np.zeros(int(args.length), dtype=np.float64)
        vec[client_idx:: max(1, int(args.length) // 10)] = float(client_idx + 1)
        vectors.append(vec)
    plain = np.sum(np.stack(vectors, axis=0), axis=0)
    secure, proof, metrics = secure_aggregate_sketches(
        vectors,
        context={"round_id": 0, "layout_hash": "smoke-layout", "model_hash": "smoke-model"},
        committee_size=7,
        threshold=5,
        shprg_backend="opa_lwr_shprg",
        plain_sum=plain,
        quantization_scale=1.0,
        protocol_backend="soda_real",
        soda_encoding=str(args.encoding),
        soda_block_size=int(args.block_size),
        topk16_per_client_bytes=int(args.length) * 2,
        dense16_per_client_bytes=int(args.length) * 2,
    )
    diff = secure - plain
    payload = {
        "protocol_path": metrics["protocol_path"],
        "aggregate_correct": bool(np.max(np.abs(diff)) == 0.0 if diff.size else True),
        "audit_valid": bool(proof.valid),
        "soda_encoding": metrics["soda_encoding"],
        "soda_block_size": int(args.block_size),
        "length": int(args.length),
        "active_clients": int(args.active_clients),
        "per_client_client_to_server_bytes": int(metrics["per_client_client_to_server_bytes"]),
        "total_protocol_bytes_per_round": int(metrics["total_protocol_bytes_per_round"]),
        "ratio_over_topk16_total_protocol": float(metrics["ratio_over_topk16_total_protocol"]),
    }
    text = json.dumps(payload, indent=2, sort_keys=True)
    if args.out:
        out = Path(args.out)
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_text(text + "\n", encoding="utf-8")
    print(text)


if __name__ == "__main__":
    main()
