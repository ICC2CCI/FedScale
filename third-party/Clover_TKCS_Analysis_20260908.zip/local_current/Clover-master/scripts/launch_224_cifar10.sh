#!/usr/bin/env bash
set -euo pipefail

ROOT="${1:-results_sketchopa_fixed_budget_224_$(date +%Y%m%d_%H%M%S)}"
DATASETS="${DATASETS:-cifar10}" bash scripts/run_four_rounds_lowcomm_experiments.sh "${ROOT}"
