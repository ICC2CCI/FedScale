#!/usr/bin/env bash
set -euo pipefail

: "${CLOVER_ROOT:?set CLOVER_ROOT}"
: "${PHASE1_RESULTS:?set PHASE1_RESULTS}"
: "${PHASE1_DATA:?set PHASE1_DATA}"
: "${PHASE1_PYTHON:?set PHASE1_PYTHON}"
: "${PHASE1_SOURCE_SHA256:?set PHASE1_SOURCE_SHA256}"

cd "$CLOVER_ROOT"

# Vision smoke on the host assignments frozen in vision_matrix.json.
"$PHASE1_PYTHON" experiments/phase1/run_vision_matrix.py \
  --host 223 --stage smoke --python "$PHASE1_PYTHON" \
  --data-root "$PHASE1_DATA" --output-root "$PHASE1_RESULTS" \
  --source-sha256 "$PHASE1_SOURCE_SHA256"
"$PHASE1_PYTHON" experiments/phase1/run_vision_matrix.py \
  --host 224 --stage smoke --python "$PHASE1_PYTHON" \
  --data-root "$PHASE1_DATA" --output-root "$PHASE1_RESULTS" \
  --source-sha256 "$PHASE1_SOURCE_SHA256"

# Vision feasibility: the matrix runner selects CIFAR10 and CIFAR100 only.
"$PHASE1_PYTHON" experiments/phase1/run_vision_matrix.py \
  --host 224 --stage feasibility --python "$PHASE1_PYTHON" \
  --data-root "$PHASE1_DATA" --output-root "$PHASE1_RESULTS" \
  --source-sha256 "$PHASE1_SOURCE_SHA256"

# Formal host-scoped vision runs. Launch only after the corresponding gates pass.
"$PHASE1_PYTHON" experiments/phase1/run_vision_matrix.py \
  --host 223 --stage formal --python "$PHASE1_PYTHON" \
  --data-root "$PHASE1_DATA" --output-root "$PHASE1_RESULTS" \
  --source-sha256 "$PHASE1_SOURCE_SHA256"
"$PHASE1_PYTHON" experiments/phase1/run_vision_matrix.py \
  --host 224 --stage formal --python "$PHASE1_PYTHON" \
  --data-root "$PHASE1_DATA" --output-root "$PHASE1_RESULTS" \
  --source-sha256 "$PHASE1_SOURCE_SHA256"

# RoBERTa requires the exact pinned FederatedScope checkout.
: "${FEDERATEDSCOPE_ROOT:?set FEDERATEDSCOPE_ROOT}"
: "${HF_CACHE_ROOT:?set HF_CACHE_ROOT}"
for task in cola mrpc; do
  for method in dense topk tkcs; do
    "$PHASE1_PYTHON" experiments/phase1/run_roberta.py \
      --task "$task" --method "$method" --stage smoke \
      --python "$PHASE1_PYTHON" --federatedscope-root "$FEDERATEDSCOPE_ROOT" \
      --cache-root "$HF_CACHE_ROOT" --output-root "$PHASE1_RESULTS" \
      --source-sha256 "$PHASE1_SOURCE_SHA256"
  done
done
for method in dense topk tkcs; do
  "$PHASE1_PYTHON" experiments/phase1/run_roberta.py \
    --task cola --method "$method" --stage feasibility \
    --python "$PHASE1_PYTHON" --federatedscope-root "$FEDERATEDSCOPE_ROOT" \
    --cache-root "$HF_CACHE_ROOT" --output-root "$PHASE1_RESULTS" \
    --source-sha256 "$PHASE1_SOURCE_SHA256"
done
for task in cola mrpc; do
  for method in dense topk tkcs; do
    "$PHASE1_PYTHON" experiments/phase1/run_roberta.py \
      --task "$task" --method "$method" --stage formal \
      --python "$PHASE1_PYTHON" --federatedscope-root "$FEDERATEDSCOPE_ROOT" \
      --cache-root "$HF_CACHE_ROOT" --output-root "$PHASE1_RESULTS" \
      --source-sha256 "$PHASE1_SOURCE_SHA256"
  done
done

# Phi uses the FlowerTune virtual environment and original General NLP app.
: "${FLOWERTUNE_ROOT:?set FLOWERTUNE_ROOT}"
: "${FLOWER_EXECUTABLE:?set FLOWER_EXECUTABLE}"
for method in dense topk tkcs; do
  "$PHASE1_PYTHON" experiments/phase1/run_phi.py \
    --method "$method" --stage smoke --flwr "$FLOWER_EXECUTABLE" \
    --flower-root "$FLOWERTUNE_ROOT" --clover-root "$CLOVER_ROOT" \
    --output-root "$PHASE1_RESULTS" --source-sha256 "$PHASE1_SOURCE_SHA256"
done
for method in dense topk tkcs; do
  "$PHASE1_PYTHON" experiments/phase1/run_phi.py \
    --method "$method" --stage formal --flwr "$FLOWER_EXECUTABLE" \
    --flower-root "$FLOWERTUNE_ROOT" --clover-root "$CLOVER_ROOT" \
    --output-root "$PHASE1_RESULTS" --source-sha256 "$PHASE1_SOURCE_SHA256"
done

# Final collection can consume separate 223 and 224 result roots.
: "${PHASE1_RESULTS_223:?set PHASE1_RESULTS_223}"
: "${PHASE1_RESULTS_224:?set PHASE1_RESULTS_224}"
: "${PHASE1_SUMMARY_ROOT:?set PHASE1_SUMMARY_ROOT}"
"$PHASE1_PYTHON" experiments/phase1/build_summary.py \
  --input-root "$PHASE1_RESULTS_223" \
  --input-root "$PHASE1_RESULTS_224" \
  --output-root "$PHASE1_SUMMARY_ROOT"
