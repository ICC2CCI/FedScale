from __future__ import annotations

import sys
from pathlib import Path
from types import SimpleNamespace

import numpy as np
import torch

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from Clover_api.SketchOPA.metrics import cosine_similarity
from Clover_api.SketchOPA.model_flatten import flatten_learnable_params, recover_flattened_to_state
from Clover_api.SketchOPA.secure_aggregation import secure_aggregate_sketches
from Clover_api.SketchOPA.sketchopa_aggregator import SketchOPAAggregator


def check_flatten_roundtrip() -> None:
    state = {
        "linear.weight": torch.arange(6, dtype=torch.float32).reshape(2, 3),
        "linear.bias": torch.ones(2, dtype=torch.float32),
        "bn.running_mean": torch.zeros(2, dtype=torch.float32),
    }
    flat, specs, keys = flatten_learnable_params(state, ["bn.running_mean"])
    assert [spec.name for spec in specs] == ["linear.weight", "linear.bias"]
    recovered = recover_flattened_to_state(flat + 1, state, ["bn.running_mean"])
    assert torch.equal(recovered["bn.running_mean"], state["bn.running_mean"])
    assert torch.equal(recovered["linear.bias"], torch.ones(2) + 1)


def check_secure_sum() -> None:
    sketches = [np.array([1.0, -2.0, 3.0]), np.array([4.0, 5.0, -6.0])]
    plain = np.sum(np.stack(sketches), axis=0)
    secure, proof, metrics = secure_aggregate_sketches(
        sketches,
        context={"round": 0},
        committee_size=7,
        threshold=5,
        shprg_backend="opa_lwr_shprg",
        plain_sum=plain,
    )
    assert proof.valid
    assert metrics["secure_plain_sketch_linf_error"] == 0.0
    assert np.array_equal(secure, plain)


def check_aggregator_smoke() -> None:
    args = SimpleNamespace(
        aggregation_mode="sketchopa_plain_cs",
        alpha=0.5,
        C=1_000_000_000.0,
        sketch_rows=3,
        sketch_bucket_factor=4,
        sketch_min_buckets=4,
        sketch_recover_k_mode="active_union",
        sketch_recover_k_multiplier=1.0,
        sketch_bucket_budget_mode="active_union",
        sketch_recovery_score="plain_median",
        sketch_conf_cap=100.0,
        sketch_transport_dtype="float32",
        sketch_value_bytes=4,
        committee_size=7,
        committee_threshold=5,
        shprg_backend="opa_lwr_shprg",
        secure_debug_check=False,
        dataset="unit",
        model="toy",
    )
    base = {"w": torch.zeros(8), "buf": torch.zeros(1)}
    diffs = [
        (2, {"w": torch.tensor([5.0, 4.0, 0.0, 0.0, 1.0, 0.0, -3.0, 0.0]), "buf": torch.zeros(1)}),
        (2, {"w": torch.tensor([0.0, 2.0, -6.0, 0.0, 0.0, 0.0, 0.0, 7.0]), "buf": torch.zeros(1)}),
    ]
    agg = SketchOPAAggregator(args, ["buf"], torch.device("cpu"), logger=None)
    delta, metrics = agg.aggregate(diffs, base, round_idx=0, client_ids=[0, 1])
    flat, _, _ = flatten_learnable_params(delta, ["buf"])
    assert flat.numel() == 8
    assert metrics["server_recover_k"] == 8
    assert metrics["sketch_transport_dtype"] == "float32"
    assert metrics["sketch_value_bytes"] == 4
    assert metrics["sketch_vs_dense_client_ratio"] > 0.0
    assert cosine_similarity(flat.numpy(), flat.numpy()) == 1.0


def main() -> None:
    check_flatten_roundtrip()
    check_secure_sum()
    check_aggregator_smoke()
    print("check_sketchopa_clover: ok")


if __name__ == "__main__":
    main()
