#!/usr/bin/env bash
set -euo pipefail

: "${CLOVER_ROOT:?set CLOVER_ROOT to a clean tree with the amendment patch applied}"
: "${PHASE1_DATA:?set PHASE1_DATA}"
: "${PHASE1_PYTHON:?set PHASE1_PYTHON}"
: "${PHASE1_AMENDMENT_RESULTS:?set PHASE1_AMENDMENT_RESULTS to a new empty root}"
: "${PHASE1_AMENDMENT_SOURCE_SHA256:?set PHASE1_AMENDMENT_SOURCE_SHA256}"

cd "$CLOVER_ROOT"
"$PHASE1_PYTHON" tests/test_phase1_vision_matrix.py

for method in dense topk tkcs; do
  "$PHASE1_PYTHON" experiments/phase1/run_vision.py \
    --dataset fmnist --distribution dirichlet_beta1 --method "$method" \
    --stage formal --python "$PHASE1_PYTHON" --gpu 0 \
    --data-root "$PHASE1_DATA" \
    --output-root "$PHASE1_AMENDMENT_RESULTS" \
    --source-sha256 "$PHASE1_AMENDMENT_SOURCE_SHA256"
done

"$PHASE1_PYTHON" experiments/phase1/validate_fmnist_amendment.py \
  --root "$PHASE1_AMENDMENT_RESULTS"
