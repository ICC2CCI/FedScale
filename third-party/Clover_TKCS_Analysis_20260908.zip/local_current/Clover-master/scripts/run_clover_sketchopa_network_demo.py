from __future__ import annotations

import csv
from pathlib import Path

from Clover_api.SketchOPA.protocol.demo import run_demo_round


def main() -> None:
    result = run_demo_round(client_count=6, committee_count=7, threshold=5, dim=128, seed=2)
    out = Path("results_sketchopa_clover") / "network_demo_round_metrics.csv"
    out.parent.mkdir(parents=True, exist_ok=True)
    keys = [
        "proof_valid",
        "aggregate_correct",
        "client_to_server_bytes",
        "client_to_committee_bytes",
        "committee_to_server_bytes",
        "public_proof_bytes",
        "server_reported_bytes",
        "threshold",
        "dim",
    ]
    with out.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=keys)
        writer.writeheader()
        writer.writerow({key: result.get(key) for key in keys})
    print(out)


if __name__ == "__main__":
    main()

