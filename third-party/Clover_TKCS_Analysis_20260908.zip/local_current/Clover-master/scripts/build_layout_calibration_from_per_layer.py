from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path


def main() -> None:
    parser = argparse.ArgumentParser(description="Build public layer calibration stats from per-layer recovery CSV")
    parser.add_argument("--input", required=True)
    parser.add_argument("--out", required=True)
    parser.add_argument("--max-round", type=int, default=0)
    parser.add_argument("--dataset", type=str, default="")
    parser.add_argument("--model", type=str, default="")
    args = parser.parse_args()

    sums = {}
    counts = {}
    with Path(args.input).open("r", newline="", encoding="utf-8") as handle:
        for row in csv.DictReader(handle):
            if args.dataset and str(row.get("dataset", "")).lower() != str(args.dataset).lower():
                continue
            if args.model and str(row.get("model", "")).lower() != str(args.model).lower():
                continue
            try:
                round_idx = int(row.get("round", "0"))
            except ValueError:
                round_idx = 0
            if round_idx > int(args.max_round):
                continue
            name = row["layer_name"]
            value = float(row.get("layer_topk_count_oracle", 0.0) or 0.0)
            sums[name] = sums.get(name, 0.0) + value
            counts[name] = counts.get(name, 0) + 1

    payload = {
        "source": str(args.input),
        "max_round": int(args.max_round),
        "dataset": str(args.dataset),
        "model": str(args.model),
        "layers": {
            name: {"topk_count": sums[name] / max(1, counts[name])}
            for name in sorted(sums)
        },
    }
    out = Path(args.out)
    out.parent.mkdir(parents=True, exist_ok=True)
    with out.open("w", encoding="utf-8") as handle:
        json.dump(payload, handle, indent=2, sort_keys=True)


if __name__ == "__main__":
    main()
