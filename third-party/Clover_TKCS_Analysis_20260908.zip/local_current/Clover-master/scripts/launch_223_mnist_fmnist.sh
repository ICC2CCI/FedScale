#!/usr/bin/env bash
set -euo pipefail

ROOT="${1:-results_sketchopa_fixed_budget_223_$(date +%Y%m%d_%H%M%S)}"
DATASETS="${DATASETS:-mnist fmnist}" bash scripts/run_four_rounds_lowcomm_experiments.sh "${ROOT}"
