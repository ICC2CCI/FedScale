#!/usr/bin/env bash
set -euo pipefail

ROOT="${1:-results_sketchopa_fixed_budget_*}"

for marker in ${ROOT}/_markers/*; do
  [ -d "${marker}" ] || continue
  name="$(basename "${marker}")"
  status="PENDING"
  [ -f "${marker}/DONE" ] && status="DONE"
  [ -f "${marker}/RUNNING" ] && status="RUNNING"
  [ -f "${marker}/FAILED" ] && status="FAILED"
  log="${marker%/_markers/*}/logs/${name}.log"
  last_log_line=""
  if [ -f "${log}" ]; then
    last_log_line="$(tail -n 1 "${log}" | tr ',' ';')"
  fi
  echo "${name},${status},${last_log_line}"
done
