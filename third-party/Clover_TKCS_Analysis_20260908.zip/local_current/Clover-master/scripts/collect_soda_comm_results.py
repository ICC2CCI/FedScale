from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path


def read_csv(path: Path) -> list[dict[str, str]]:
    if not path.exists():
        return []
    with path.open("r", newline="", encoding="utf-8") as handle:
        return list(csv.DictReader(handle))


def write_csv(path: Path, rows: list[dict]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if not rows:
        path.write_text("", encoding="utf-8")
        return
    fieldnames: list[str] = []
    for row in rows:
        for key in row:
            if key not in fieldnames:
                fieldnames.append(key)
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)


def build_report(root: Path, rows: list[dict], smoke: dict) -> str:
    lines = [
        "# SODA Real Protocol Communication Report",
        "",
        "## Smoke",
        "",
        f"- protocol_path: `{smoke.get('protocol_path', '')}`",
        f"- aggregate_correct: `{smoke.get('aggregate_correct', '')}`",
        f"- audit_valid: `{smoke.get('audit_valid', '')}`",
        "",
        "## Communication",
        "",
        "| Dataset | Encoding | Audit | Per-client main | Total protocol | Top-k total ratio | Dense total ratio |",
        "|---|---|---|---:|---:|---:|---:|",
    ]
    for row in rows:
        lines.append(
            "| {dataset} | {encoding} | {audit_mode} | {main} | {total} | {rtopk} | {rdense} |".format(
                dataset=row.get("dataset", ""),
                encoding=row.get("encoding", ""),
                audit_mode=row.get("audit_mode", ""),
                main=row.get("per_client_client_to_server_bytes", ""),
                total=row.get("total_protocol_bytes_per_round", ""),
                rtopk=row.get("ratio_over_topk16_total_protocol", ""),
                rdense=row.get("ratio_over_dense16_total_protocol", ""),
            )
        )
    lines.extend(
        [
            "",
            "## Interpretation",
            "",
            "- `commitment_only` proof accounting excludes full ciphertext, aggregate mask, U, and delta vectors.",
            "- `full_opening_debug` rows are for debugging only and should not be used for low-communication paper claims.",
            "- `total_protocol_bytes_per_round` uses total-round Top-k and Dense denominators for ratios.",
            f"- Source root: `{root}`",
            "",
        ]
    )
    return "\n".join(lines)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", required=True)
    parser.add_argument("--out", required=True)
    args = parser.parse_args()
    root = Path(args.root)
    rows: list[dict] = []
    for path in sorted(root.glob("comm_*.csv")):
        rows.extend(read_csv(path))
    out = Path(args.out)
    write_csv(out, rows)
    smoke_path = root / "smoke_uint16.json"
    smoke = json.loads(smoke_path.read_text(encoding="utf-8")) if smoke_path.exists() else {}
    (root / "final_soda_real_protocol_report.md").write_text(build_report(root, rows, smoke), encoding="utf-8")
    print(f"wrote {out}")


if __name__ == "__main__":
    main()
