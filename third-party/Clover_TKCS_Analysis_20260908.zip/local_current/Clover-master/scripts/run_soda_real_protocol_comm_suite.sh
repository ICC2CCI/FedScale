#!/usr/bin/env bash
set -euo pipefail

ROOT=${1:-results_soda_real_protocol_comm_$(date +%Y%m%d_%H%M%S)}
PYTHON_BIN=${PYTHON_BIN:-python3}
mkdir -p "$ROOT"

"${PYTHON_BIN}" scripts/run_soda_real_protocol_smoke.py \
  --length 10000 --active_clients 3 --encoding uint16 --block_size 1024 \
  --out "$ROOT/smoke_uint16.json"

"${PYTHON_BIN}" scripts/run_soda_comm_eval.py \
  --dataset mnist --model lenet5 --encoding uint16 --active_clients 10 \
  --audit_mode commitment_only \
  --out "$ROOT/comm_mnist_uint16.csv"

"${PYTHON_BIN}" scripts/run_soda_comm_eval.py \
  --dataset fmnist --model lenet5 --encoding uint16 --active_clients 10 \
  --audit_mode commitment_only \
  --out "$ROOT/comm_fmnist_uint16.csv"

"${PYTHON_BIN}" scripts/run_soda_comm_eval.py \
  --dataset cifar10 --model resnet18 --encoding uint16 --active_clients 10 \
  --audit_mode commitment_only \
  --out "$ROOT/comm_cifar10_uint16.csv"

"${PYTHON_BIN}" scripts/run_soda_comm_eval.py \
  --dataset cifar10 --model resnet18 --encoding uint32 --active_clients 10 \
  --audit_mode commitment_only \
  --out "$ROOT/comm_cifar10_uint32.csv"

"${PYTHON_BIN}" scripts/collect_soda_comm_results.py \
  --root "$ROOT" \
  --out "$ROOT/summary_soda_real_comm.csv"

echo "DONE" > "$ROOT/DONE"
