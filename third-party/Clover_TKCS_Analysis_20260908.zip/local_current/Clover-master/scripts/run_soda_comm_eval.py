from __future__ import annotations

import argparse
import csv
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from Clover_api.SketchOPA.soda_comm_metrics import comm_metrics_to_dict, compute_soda_comm_metrics


DATASET_DEFAULTS = {
    "mnist": {"model": "lenet5", "sketch_len": 21546, "topk16": 43100, "dense16": 862160},
    "fmnist": {"model": "lenet5", "sketch_len": 21550, "topk16": 43100, "dense16": 862160},
    "cifar10": {"model": "resnet18", "sketch_len": 558693, "topk16": 1117390, "dense16": 22347924},
}


def bytes_for_encoding(name: str) -> int:
    if name == "uint16":
        return 2
    if name == "uint32":
        return 4
    if name == "uint64":
        return 8
    raise ValueError(f"unsupported encoding: {name}")


def main() -> None:
    parser = argparse.ArgumentParser(description="Evaluate SODA real protocol communication accounting")
    parser.add_argument("--dataset", required=True, choices=sorted(DATASET_DEFAULTS))
    parser.add_argument("--model", default="")
    parser.add_argument("--sketch_len", type=int, default=0)
    parser.add_argument("--active_clients", type=int, default=10)
    parser.add_argument("--topk16_per_client_bytes", type=int, default=0)
    parser.add_argument("--dense16_per_client_bytes", type=int, default=0)
    parser.add_argument("--encoding", default="uint16", choices=["uint16", "uint32", "uint64"])
    parser.add_argument("--block_size", type=int, default=16384)
    parser.add_argument("--committee_size", type=int, default=7)
    parser.add_argument("--threshold", type=int, default=5)
    parser.add_argument("--seed_dim", type=int, default=16)
    parser.add_argument("--audit_mode", default="commitment_only", choices=["commitment_only", "full_opening_debug"])
    parser.add_argument("--out", default="results_soda_comm_eval.csv")
    args = parser.parse_args()

    defaults = DATASET_DEFAULTS[str(args.dataset)]
    sketch_len = int(args.sketch_len or defaults["sketch_len"])
    topk = int(args.topk16_per_client_bytes or defaults["topk16"])
    dense = int(args.dense16_per_client_bytes or defaults["dense16"])
    proof_bytes = 11 * 32 + int(args.threshold) * 64 + 64
    if args.audit_mode == "full_opening_debug":
        proof_bytes += sketch_len * bytes_for_encoding(str(args.encoding)) * 4
    metrics = compute_soda_comm_metrics(
        active_clients=int(args.active_clients),
        sketch_length=sketch_len,
        block_size=int(args.block_size),
        bytes_per_bucket=bytes_for_encoding(str(args.encoding)),
        committee_size=int(args.committee_size),
        threshold=int(args.threshold),
        seed_dim=int(args.seed_dim),
        proof_or_audit_bytes=int(proof_bytes),
        topk16_per_client_bytes=topk,
        dense16_per_client_bytes=dense,
    )
    row = {
        "dataset": str(args.dataset),
        "model": str(args.model or defaults["model"]),
        "encoding": str(args.encoding),
        "audit_mode": str(args.audit_mode),
        "committee_size": int(args.committee_size),
        "threshold": int(args.threshold),
        "seed_dim": int(args.seed_dim),
        **comm_metrics_to_dict(metrics),
    }
    out = Path(args.out)
    out.parent.mkdir(parents=True, exist_ok=True)
    with out.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(row.keys()))
        writer.writeheader()
        writer.writerow(row)
    print(f"wrote {out}")


if __name__ == "__main__":
    main()
