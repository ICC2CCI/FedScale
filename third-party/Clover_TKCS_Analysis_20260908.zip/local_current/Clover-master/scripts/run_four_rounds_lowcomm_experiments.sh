#!/usr/bin/env bash
set -euo pipefail

ROOT="${1:-results_sketchopa_fixed_budget_$(date +%Y%m%d_%H%M%S)}"
DATASETS="${DATASETS:-mnist fmnist cifar10}"
ROUNDS="${ROUNDS:-20}"
PYTHON_BIN="${PYTHON:-python3}"
GPU="${GPU:-0}"
STOP_ON_FAIL="${STOP_ON_FAIL:-0}"
mkdir -p "${ROOT}/logs" "${ROOT}/_markers"

model_for_dataset() {
  case "$1" in
    mnist|fmnist) echo lenet5 ;;
    cifar10) echo resnet18 ;;
    *) echo "unsupported dataset: $1" >&2; exit 2 ;;
  esac
}

base_args=(
  --partition_method IID
  --method FedAvg
  --batch_size 50
  --lr 0.1
  --epochs 30
  --client_num_in_total 100
  --frac 0.1
  --comm_round "${ROUNDS}"
  --C 1000000000
  --sigma 0
  --alpha 0.01
  --sketch_recover_k_mode active_union
  --sketch_recovery_score plain_median
  --sketch_layout_mode fixed_public
  --sketch_budget_ref topk16
  --sketch_transport_dtype float16
  --sketch_value_bytes 2
  --default_sketch_dtype float16
  --sketch_min_buckets 8
  --sketch_recovered_clip_norm "${RECOVERED_CLIP_NORM:-10}"
  --gpu "${GPU}"
  --results_dir "${ROOT}"
)

run_exp() {
  local name="$1"
  local dataset="$2"
  local model="$3"
  shift 3
  local marker="${ROOT}/_markers/${name}"
  mkdir -p "${marker}"
  if [ -f "${marker}/DONE" ]; then
    echo "[SKIP] ${name}"
    return 0
  fi
  rm -f "${marker}/FAILED"
  touch "${marker}/RUNNING"
  echo "[RUN] ${name}"
  if "${PYTHON_BIN}" Clover-main.py "${base_args[@]}" --dataset "${dataset}" --model "${model}" --tag "${name}" "$@" > "${ROOT}/logs/${name}.log" 2>&1; then
    rm -f "${marker}/RUNNING"
    touch "${marker}/DONE"
  else
    rm -f "${marker}/RUNNING"
    touch "${marker}/FAILED"
    echo "[FAILED] ${name}" >&2
    if [ "${STOP_ON_FAIL}" = "1" ]; then
      exit 1
    fi
  fi
}

collect_now() {
  "${PYTHON_BIN}" scripts/collect_clover_sketchopa_results.py --root "${ROOT}" --out "${ROOT}/summary"
}

run_dataset() {
  local dataset="$1"
  local model
  model="$(model_for_dataset "${dataset}")"
  local calibration_path="calibrations/${dataset}_${model}_topk_count.json"
  local default_strategy="${LAYOUT_STRATEGY:-topk_count_calibrated}"

  run_exp "round1_${dataset}_fixed_budget_float16_no_residual_1.0x" "${dataset}" "${model}" \
    --aggregation_mode sketchopa_plain_cs \
    --sketch_rows 5 \
    --sketch_budget_ratio 1.0 \
    --sketch_allocation_strategy "${default_strategy}" \
    --layout_calibration_path "${calibration_path}"

  run_exp "round1_${dataset}_fixed_budget_float16_residual_1.0x" "${dataset}" "${model}" \
    --aggregation_mode sketchopa_plain_cs_residual \
    --sketch_rows 5 \
    --sketch_budget_ratio 1.0 \
    --sketch_allocation_strategy "${default_strategy}" \
    --layout_calibration_path "${calibration_path}"

  collect_now

  for ratio in 0.6 0.8 1.0 1.2; do
    run_exp "round2_${dataset}_fixed_budget_float16_residual_${ratio}x" "${dataset}" "${model}" \
      --aggregation_mode sketchopa_plain_cs_residual \
      --sketch_rows 5 \
      --sketch_budget_ratio "${ratio}" \
      --sketch_allocation_strategy "${default_strategy}" \
      --layout_calibration_path "${calibration_path}"
  done

  if [ "${dataset}" = "cifar10" ]; then
    for strategy in uniform_param topk_count_calibrated norm_calibrated hybrid_dense_small_layers mixed_precision_sensitive; do
      run_exp "round3_cifar10_${strategy}_1.0x" "${dataset}" "${model}" \
        --aggregation_mode sketchopa_plain_cs_residual \
        --sketch_rows 5 \
        --sketch_budget_ratio 1.0 \
        --sketch_allocation_strategy "${strategy}" \
        --layout_calibration_path "${calibration_path}"
    done
  fi

  for rows in 3 5 7; do
    run_exp "round4_${dataset}_rows${rows}_fixed_budget_1.0x" "${dataset}" "${model}" \
      --aggregation_mode sketchopa_plain_cs_residual \
      --sketch_rows "${rows}" \
      --sketch_budget_ratio 1.0 \
      --sketch_allocation_strategy "${ROW_STRATEGY:-${default_strategy}}" \
      --layout_calibration_path "${calibration_path}"
  done
}

for dataset in ${DATASETS}; do
  run_dataset "${dataset}"
  collect_now
done

collect_now
echo "ALL_DONE"
