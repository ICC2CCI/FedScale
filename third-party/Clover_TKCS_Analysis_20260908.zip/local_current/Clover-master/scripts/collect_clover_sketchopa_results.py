from __future__ import annotations

import argparse
import csv
import json
import os
from pathlib import Path
from statistics import mean


BASELINES = {
    "mnist": {"dense16_acc": 0.987127, "dense16_bytes": 862160, "topk16_acc": 0.981566, "topk16_bytes": 43100},
    "fmnist": {"dense16_acc": 0.886726, "dense16_bytes": 862160, "topk16_acc": 0.871536, "topk16_bytes": 43100},
    "cifar10": {"dense16_acc": 0.622392, "dense16_bytes": 22347924, "topk16_acc": 0.530695, "topk16_bytes": 1117390},
}


def read_csv(path: Path) -> list[dict[str, str]]:
    if not path.exists():
        return []
    with path.open("r", newline="", encoding="utf-8") as handle:
        return list(csv.DictReader(handle))


def write_csv(path: Path, rows: list[dict]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fields: list[str] = []
    for row in rows:
        for key in row:
            if key not in fields:
                fields.append(key)
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)


def write_json(path: Path, payload: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as handle:
        json.dump(payload, handle, indent=2, sort_keys=True)


def as_float(value, default=0.0) -> float:
    try:
        if value in {"", None}:
            return default
        return float(value)
    except Exception:
        return default


def as_int(value, default=0) -> int:
    try:
        if value in {"", None}:
            return default
        return int(float(value))
    except Exception:
        return default


def mean_field(rows: list[dict], field: str):
    values = [as_float(row.get(field), None) for row in rows if row.get(field, "") != ""]
    values = [value for value in values if value is not None]
    return mean(values) if values else ""


def discover_run_dirs(root: Path) -> list[Path]:
    dirs = {path.parent for path in root.rglob("final_summary.json")}
    dirs.update(path.parent for path in root.rglob("round_metrics.csv"))
    return sorted(path for path in dirs if path.is_dir())


def tag_from_run_dir(run_dir: Path) -> str:
    marker = "-tag"
    name = run_dir.name
    if marker not in name:
        return ""
    return name.split(marker, 1)[1]


def run_status(root: Path, run_dir: Path) -> str:
    tag = tag_from_run_dir(run_dir)
    marker_dir = root / "_markers" / tag if tag else None
    if marker_dir and marker_dir.exists():
        if (marker_dir / "RUNNING").exists():
            return "running"
        if (marker_dir / "FAILED").exists():
            return "failed"
        if (marker_dir / "DONE").exists():
            return "done"
    if (run_dir / "RUNNING").exists():
        return "running"
    if (run_dir / "FAILED").exists():
        return "failed"
    if (run_dir / "DONE").exists():
        return "done"
    return "unknown"


def load_summary(path: Path) -> dict:
    summary_path = path / "final_summary.json"
    if not summary_path.exists():
        return {}
    with summary_path.open("r", encoding="utf-8") as handle:
        return json.load(handle)


def latest(rows: list[dict]) -> dict:
    return dict(rows[-1]) if rows else {}


def collect(root: Path, out: Path) -> dict[str, list[dict]]:
    run_dirs = discover_run_dirs(root)
    missing = []
    accuracy = []
    recovery = []
    per_layer = []
    comm = []
    all_rows = []

    for run_dir in run_dirs:
        rel = str(run_dir.relative_to(root))
        status = run_status(root, run_dir)
        if status != "done":
            missing.append({"run_dir": rel, "missing_file": f"run_status:{status}"})
            continue
        summary = load_summary(run_dir)
        round_rows = read_csv(run_dir / "round_metrics.csv")
        recovery_rows = read_csv(run_dir / "sketch_recovery_metrics.csv")
        per_layer_rows = read_csv(run_dir / "per_layer_recovery_metrics.csv")
        comm_rows = read_csv(run_dir / "comm_metrics.csv")
        expected = ["final_summary.json", "round_metrics.csv", "comm_metrics.csv"]
        mode = str(summary.get("mode", latest(round_rows).get("mode", "")))
        if mode.startswith("sketchopa_"):
            expected.extend(["sketch_recovery_metrics.csv", "per_layer_recovery_metrics.csv", "layout.json"])
        for name in expected:
            if not (run_dir / name).exists():
                missing.append({"run_dir": rel, "missing_file": name})

        round_last = latest(round_rows)
        comm_last = latest(comm_rows)
        recovery_last = latest(recovery_rows)
        dataset = str(summary.get("dataset", round_last.get("dataset", recovery_last.get("dataset", ""))).lower())
        base = BASELINES.get(dataset, {})
        final_acc = as_float(summary.get("final_acc", round_last.get("test_acc", "")))
        accuracy_row = {
            "dataset": dataset,
            "model": summary.get("model", round_last.get("model", recovery_last.get("model", ""))),
            "rounds": summary.get("rounds", ""),
            "mode": mode,
            "final_acc": final_acc,
            "best_acc": summary.get("best_acc", ""),
            "last5_acc": summary.get("last5_acc", ""),
            "dense16_acc_ref": base.get("dense16_acc", ""),
            "topk16_acc_ref": base.get("topk16_acc", ""),
            "drop_vs_dense16_pp": (base["dense16_acc"] - final_acc) * 100 if base and final_acc else "",
            "drop_vs_topk16_pp": (base["topk16_acc"] - final_acc) * 100 if base and final_acc else "",
            "run_dir": rel,
        }
        accuracy.append(accuracy_row)

        if recovery_rows:
            first = recovery_rows[0]
            recovery_row = {
                "dataset": dataset,
                "model": first.get("model", ""),
                "mode": first.get("method", mode),
                "rows": first.get("sketch_rows", ""),
                "layout_mode": first.get("sketch_layout_mode", ""),
                "budget_ratio": first.get("sketch_budget_ratio", ""),
                "allocation_strategy": first.get("sketch_allocation_strategy", ""),
                "residual_enabled": first.get("residual_enabled", ""),
                "payload_bytes": recovery_rows[-1].get("payload_bytes", ""),
                "payload_over_topk16": recovery_rows[-1].get("payload_over_topk16", ""),
                "payload_over_dense16": recovery_rows[-1].get("payload_over_dense16", ""),
                "layout_hash": first.get("layout_hash", ""),
                "recovery_cosine_avg": mean_field(recovery_rows, "recovery_cosine"),
                "recovery_l2_rel_avg": mean_field(recovery_rows, "recovery_l2_rel"),
                "support_precision_avg": mean_field(recovery_rows, "support_precision_vs_union"),
                "support_recall_avg": mean_field(recovery_rows, "support_recall_vs_union"),
                "run_dir": rel,
            }
            recovery.append(recovery_row)
        else:
            recovery_row = {}

        for row in per_layer_rows:
            merged = dict(row)
            merged["run_dir"] = rel
            per_layer.append(merged)

        if comm_rows:
            comm_row = dict(comm_last)
            comm_row["run_dir"] = rel
            comm.append(comm_row)
        else:
            comm_row = {}

        all_row = {
            **summary,
            **accuracy_row,
            **{f"comm_{key}": value for key, value in comm_row.items() if key != "run_dir"},
            **{f"recovery_{key}": value for key, value in recovery_row.items() if key != "run_dir"},
            "run_dir": rel,
        }
        all_rows.append(all_row)

    round1 = [
        row for row in all_rows
        if "round1_" in str(row.get("run_dir", ""))
        and str(row.get("sketch_layout_mode", row.get("recovery_layout_mode", ""))) == "fixed_public"
    ]
    round2 = [
        row for row in all_rows
        if "round2_" in str(row.get("run_dir", ""))
        and str(row.get("recovery_residual_enabled", row.get("residual_enabled", ""))).lower() in {"true", "1"}
        and str(row.get("sketch_layout_mode", row.get("recovery_layout_mode", ""))) == "fixed_public"
        and as_float(row.get("sketch_budget_ratio", row.get("recovery_budget_ratio", ""))) in {0.6, 0.8, 1.0, 1.2}
    ]
    round3 = [
        row for row in all_rows
        if "round3_" in str(row.get("run_dir", ""))
        and row.get("dataset") == "cifar10"
        and str(row.get("sketch_layout_mode", row.get("recovery_layout_mode", ""))) == "fixed_public"
    ]
    round4 = [
        row for row in all_rows
        if "round4_" in str(row.get("run_dir", ""))
        and str(row.get("sketch_layout_mode", row.get("recovery_layout_mode", ""))) == "fixed_public"
        and as_int(row.get("sketch_rows", row.get("recovery_rows", ""))) in {3, 5, 7}
        and as_float(row.get("sketch_budget_ratio", row.get("recovery_budget_ratio", ""))) == 1.0
    ]

    return {
        "accuracy": accuracy,
        "comm": comm,
        "recovery": recovery,
        "per_layer": per_layer,
        "all": all_rows,
        "missing": missing,
        "round1": round1,
        "round2": round2,
        "round3": round3,
        "round4": round4,
    }


def pick_recommendations(all_rows: list[dict]) -> dict:
    out = {}
    for dataset in sorted({str(row.get("dataset", "")).lower() for row in all_rows if row.get("dataset")}):
        rows = [
            row for row in all_rows
            if str(row.get("dataset", "")).lower() == dataset
            and str(row.get("mode", "")).startswith("sketchopa_")
        ]
        def pick(predicate):
            candidates = [row for row in rows if predicate(row)]
            if not candidates:
                return {}
            return max(candidates, key=lambda row: as_float(row.get("final_acc")))
        out[dataset] = {
            "low_comm": pick(lambda row: as_float(row.get("recovery_payload_over_topk16", row.get("payload_over_topk16", "")), 999.0) <= 0.8),
            "balanced": pick(lambda row: as_float(row.get("recovery_payload_over_topk16", row.get("payload_over_topk16", "")), 999.0) <= 1.0),
            "high_accuracy": pick(lambda row: as_float(row.get("recovery_payload_over_dense16", row.get("payload_over_dense16", "")), 999.0) <= 0.1),
        }
    return out


def write_report(root: Path, out: Path, tables: dict[str, list[dict]], recommendations: dict) -> None:
    report = out / "final_report.md"
    report.parent.mkdir(parents=True, exist_ok=True)
    with report.open("w", encoding="utf-8") as handle:
        handle.write("# Clover SketchOPA Fixed-Budget Report\n\n")
        handle.write(f"- results root: `{root}`\n")
        handle.write(f"- runs discovered: {len(tables['all'])}\n")
        handle.write(f"- missing file rows: {len(tables['missing'])}\n\n")
        handle.write("## Baseline References\n\n")
        handle.write("| Dataset | Dense16 Acc/Bytes | Top-k16 Acc/Bytes |\n")
        handle.write("|---|---:|---:|\n")
        for dataset, row in BASELINES.items():
            handle.write(
                f"| {dataset} | {row['dense16_acc']:.4%} / {row['dense16_bytes']} | "
                f"{row['topk16_acc']:.4%} / {row['topk16_bytes']} |\n"
            )
        handle.write("\n## Tables\n\n")
        handle.write("- accuracy: `summary_accuracy.csv`\n")
        handle.write("- communication: `summary_comm.csv`\n")
        handle.write("- recovery: `summary_recovery.csv`\n")
        handle.write("- per-layer recovery: `summary_per_layer.csv`\n")
        handle.write("- all merged rows: `summary_all.csv`\n")
        handle.write("- missing files: `missing_files.csv`\n")
        handle.write("\n## Round Coverage\n\n")
        handle.write(f"- round1 fixed residual communication rows: {len(tables['round1'])}\n")
        handle.write(f"- round2 Pareto rows: {len(tables['round2'])}\n")
        handle.write(f"- round3 CIFAR10 strategy rows: {len(tables['round3'])}\n")
        handle.write(f"- round4 rows ablation rows: {len(tables['round4'])}\n")
        handle.write("\n## Recommendations\n\n")
        for dataset, picks in recommendations.items():
            handle.write(f"### {dataset}\n")
            for name, row in picks.items():
                if not row:
                    handle.write(f"- {name}: unavailable\n")
                    continue
                handle.write(
                    f"- {name}: `{row.get('run_dir')}`, acc={as_float(row.get('final_acc')):.4%}, "
                    f"payload/topk16={as_float(row.get('recovery_payload_over_topk16', row.get('payload_over_topk16', ''))):.3f}\n"
                )
        handle.write("\n## Notes\n\n")
        handle.write("- Fixed-budget rows should have identical `payload_bytes` for residual and no-residual when dataset/model/ratio/rows/strategy match.\n")
        handle.write("- If accuracy misses target, inspect `summary_per_layer.csv` for low cosine or high relative L2 layers.\n")


def main(argv: list[str] | None = None) -> None:
    parser = argparse.ArgumentParser(description="Collect Clover SketchOPA experiment results")
    parser.add_argument("--root", type=str, default=os.environ.get("RESULTS_DIR", "results_sketchopa_clover"))
    parser.add_argument("--out", type=str, default="")
    args = parser.parse_args(argv)
    root = Path(args.root).resolve()
    out = Path(args.out).resolve() if args.out else root / "summary"
    tables = collect(root, out)
    write_csv(out / "summary_accuracy.csv", tables["accuracy"])
    write_csv(out / "summary_comm.csv", tables["comm"])
    write_csv(out / "summary_recovery.csv", tables["recovery"])
    write_csv(out / "summary_per_layer.csv", tables["per_layer"])
    write_csv(out / "summary_all.csv", tables["all"])
    write_csv(out / "missing_files.csv", tables["missing"])
    write_csv(out / "round1_fixed_budget_residual_comm.csv", tables["round1"])
    write_csv(out / "round2_pareto.csv", tables["round2"])
    write_csv(out / "round3_cifar10_layer_adaptive.csv", tables["round3"])
    write_csv(out / "round4_rows_ablation.csv", tables["round4"])
    recommendations = pick_recommendations(tables["all"])
    write_json(out / "recommended_configs.json", recommendations)
    write_report(root, out, tables, recommendations)


if __name__ == "__main__":
    main()
