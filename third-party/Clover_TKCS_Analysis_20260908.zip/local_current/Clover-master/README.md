# Harnessing Sparsification in Federated Learning: A Secure, Efficient, and Differentially Private Realization

This implementation accompanies our paper by Shuangqing Xu, Yifeng Zheng and Zhongyun Hua at ACM CCS'25.

## Usage

Download the repository and install all required packages as listed in requirements.txt.

#### Federated Differentially Private Model Training on MNIST

To evaluate the model utility on MNIST, run the following command

``` shell
python Clover-main.py --model 'lenet5' --dataset 'mnist' --partition_method 'IID' --method='FedAvg' --batch_size 50 --lr 0.1 --epochs 30 --client_num_in_total 100 --frac 0.1 --comm_round 120 --C 0.1 --sigma 0.95 --gpu 1 --alpha 0.01
```
#### Federated Differentially Private Model Training on CIFAR-10

    To evaluate the model utility on CIFAR-10, run the following command

``` shell
python Clover-main.py --model 'resnet18' --dataset 'cifar10' --partition_method 'IID' --method='FedAvg' --batch_size 50 --lr 0.1 --epochs 30 --client_num_in_total 100 --frac 0.1 --comm_round 300 --C 0.2 --sigma 0.95 --gpu 0 --alpha 0.01
```

#### Federated Differentially Private Model Training on FashionMNIST

To evaluate the model utility on FashionMNIST, run the following command

``` shell
python Clover-main.py --model 'lenet5' --dataset 'fmnist' --partition_method 'IID' --method='FedAvg' --batch_size 50 --lr 0.1 --epochs 30 --client_num_in_total 100 --frac 0.1 --comm_round 300 --C 0.1 --sigma 0.95 --gpu 1 --alpha 0.01
```

#### Maliciously Security

To run the maliciously secure secret-shared shuffle, run the following command

``` shell
cd MaliciouslySecurity
python rss_shuffle_mali.py
```

**WARNING**: This is an academic proof-of-concept prototype and has not received careful code review. This implementation is NOT ready for production use.

## Acknowledgments

- Part of our federated differentially private model training implementation is based on the public implementation in Shi et al.'s [paper](https://arxiv.org/abs/2303.11242) with code repo [here](https://github.com/YMJS-Irfan/DP-FedSAM)

## IEEE S&P 2027 Artifact Path

The authenticated SketchOPA/TKCS implementation is kept separate from the
legacy DP entry points above. From this directory, create an environment with
the training dependencies and then install the protocol dependency:

``` shell
python -m pip install -r requirements.txt
python -m pip install -r requirements-ieee-sp.txt
```

The protocol path requires `cryptography==49.0.0`. Do not silently substitute
the legacy `pycryptodome` package for this dependency. The production path is
fail-closed when the declared cryptography package is unavailable.

Check the environment before launching a production experiment:

``` shell
python experiments/ieee_sp/check_environment.py --json environment_check.json
```

The isolated Top-k implementation check can be run on a Torch host with:

```bash
python experiments/ieee_sp/benchmark_topk_equivalence.py
```

It verifies elementwise equality between the legacy mask implementation and
the GPU scatter implementation before any performance comparison is used in
an experiment. This check is diagnostic and does not replace the frozen
utility matrix.

The command exits nonzero on a missing or mismatched protocol dependency.

Run the deterministic protocol and attack regression suite with:

``` shell
PYTHONPATH=. python tests/run_tkcs_soda_light_tests.py
```

The suite covers the fixed-layout codec, CountSketch recovery, authenticated
messages, Shamir threshold reconstruction, replay and context checks,
multi-process TCP execution, support-inference evaluation, malicious semantic
substitutions, and the FetchSGD adapter. A green regression suite is necessary
but is not a substitute for the real multi-process experiment manifests.

Utility and system experiments are launched through the scripts under
`experiments/ieee_sp/`. Every run writes a configuration, command, per-round
metrics, latest checkpoint, validation checkpoint, and result manifest. Model
selection is validation-only; the official test/reporting split is not used to
choose a checkpoint. Use the corresponding `summarize_*_matrix.py` script only
after all manifest entries are complete and have zero failed runs.

To build the anonymous artifact after supplying complete, audited result
summaries:

``` shell
python experiments/ieee_sp/build_anonymous_artifact.py \
  --output-dir ../SketchOPA_artifact \
  --repo-root . \
  --paper-root ../../SketchOPA_IEEE_SP_2027_source \
  --security-docs ../../docs/security \
  --verify-only
```

`--verify-only` checks hashes and forbidden identity patterns without inventing
missing result files. The final artifact must also include a valid distribution
license/notice and the complete result manifest before it is treated as a
submission package.
